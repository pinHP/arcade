#!/bin/bash

# Grep variables from main script
running_version=$(grep "VERSION=" "/root/autostart.sh" | awk -F= '{print $2}' | grep -m 1 -o "[0-9]\+")
connection_timeout=$(grep "CURL_TIMEOUT=" "/root/autostart.sh" | awk -F= '{print $2}' | grep -m 1 -o "[0-9]\+")

# 1: Google Drive
# 2: GitHub
UPDATE_SERVER=1
# Update server URL should have been already passed to tmp file by main script
touch /tmp/update_server_url
if grep -q "github" /tmp/update_server_url; then
  UPDATE_SERVER=2
fi

# patch_12APR21
if [ "$running_version" -lt 20210412 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 12APR21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_12APR21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1NXZ8kA_ajMI9b8GSqxU3rGEDViFEyva9"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_12APR21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  if [ -e /mnt/data/rpi2jamma ]; then
    cp -rn /tmp/buttons /mnt/data/rpi2jamma
  fi
  if [ -e /mnt/usb/rpi2jamma ]; then
    cp -rn /tmp/buttons /mnt/usb/rpi2jamma
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DISPLAY_BUTTON_LAYOUT" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 12APR21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_DISPLAY_BUTTON_LAYOUT=\"Display Button Layout\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DISPLAY_BUTTON_LAYOUT" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 12APR21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_DISPLAY_BUTTON_LAYOUT=\"Display Button Layout\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  timings_old_jamma="hdmi_timings=320 1 32 38 17 240 1 2 6 8 0 0 0 60 0 6400000 1 #240p #H-Rate 15.72kHz #V-Rate 61.43Hz #Pi2Jamma"
  timings_new_jamma="hdmi_timings=320 1 24 38 25 240 1 2 6 8 0 0 0 60 0 6400000 1 #240p #H-Rate 15.72kHz #V-Rate 61.43Hz #Pi2Jamma"
  sed -i -e "s/$timings_old_jamma/$timings_new_jamma/" /boot/config.txt
  sed -i -e "s/$timings_old_jamma/$timings_new_jamma/" /boot/config_pi2jamma.txt
  sed -i -e "s/$timings_old_jamma/$timings_new_jamma/" /boot/config_pi2scart.txt
fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
# patch_18APR21
#if [ "$running_version" -lt 20210418 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 18APR21   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_18APR21.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1F9qOYaWxj32dT9QwtgrE-j1OLrVbiKtC"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_18APR21.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_22APR21
if [ "$running_version" -lt 20210422 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 22APR21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_22APR21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1HYnnY3Bx1qodD1t40hoAeNQh9_IA5SSz"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_22APR21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  sed -i -e 's/#SystemMaxUse=.*/SystemMaxUse=50/' /etc/systemd/journald.conf
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SET_TIME_ZONE" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 22APR21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_SET_TIME_ZONE=\"Set Time Zone\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SET_TIME_ZONE" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 22APR21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_SET_TIME_ZONE=\"Set Time Zone\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
fi

# patch_04MAY21
if [ "$running_version" -lt 20210504 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 04MAY21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_04MAY21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1LiiuMf5Cn_Mn99UZLagjzyUcVxrvvyqQ"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_04MAY21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_15MAY21
#if [ "$running_version" -lt 20210515 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 15MAY21   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_15MAY21.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1F9NZ-dSubvAuYfbBCVrQD6r2mme79I5n"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_15MAY21.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_19MAY21
if [ "$running_version" -lt 20210519 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 19MAY21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_19MAY21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=198rjSTcZFH0GiSJCchO8adW4PI8VeIc1"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_19MAY21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CUSTOM_FOLDERS" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 19MAY21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_CUSTOM_FOLDERS=\"Custom Folders\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CUSTOM_FOLDERS" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 19MAY21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_CUSTOM_FOLDERS=\"Custom Folders\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
fi

# patch_02JUN21
if [ "$running_version" -lt 20210602 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 02JUN21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_02JUN21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1mjNppqshNt5hCcLxrZPAFR6xgrnypypu"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_02JUN21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CUSTOM_FAVMENU" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 02JUN21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_CUSTOM_FAVMENU=\"Show Fav. Menu\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CUSTOM_FAVMENU" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 02JUN21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_CUSTOM_FAVMENU=\"Show Fav. Menu\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
fi

# patch_07JUN21
if [ "$running_version" -lt 20210607 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 07JUN21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_07JUN21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=16t_Icte-a0PPQ3sXPswaiQIy9FC9uwN4"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_07JUN21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_12JUN21
#if [ "$running_version" -lt 20210612 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 12JUN21   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_12JUN21.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=14oVN3oCC2D8TLY5tT3r8JpT4_1IU7Tm8"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_12JUN21.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_26JUN21
if [ "$running_version" -lt 20210626 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 26JUN21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_26JUN21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1TmClsWrOJor4lx-JHz2-i3COGPIxkO_b"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_26JUN21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

# patch_08JUL21
if [ "$running_version" -lt 20210708 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 08JUL21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_08JUL21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1BrsSvuCN9JLiIs-TMlioE8-M1LTtzVGa"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_08JUL21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_ENABLE_SERVOSTIK" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_ENABLE_SERVOSTIK=\"Enable ServoStik\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SERVOSTIK_DEFAULT" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_SERVOSTIK_DEFAULT=\"ServoStik Default: \"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FAVBUTTON_BEHAVIOUR" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_FAVBUTTON_BEHAVIOUR=\"P2-Start Button\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_TOGGLE_SERVOSTIK" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_TOGGLE_SERVOSTIK=\"Toggle ServoStik\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
fi

# patch_21JUL21
if [ "$running_version" -lt 20210721 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 21JUL21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_21JUL21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1qRPUdlzTccjwVCdd6oaR6iSXSfrmFzDB"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_21JUL21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On USB stick, should have been added with previous update already
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_ENABLE_SERVOSTIK" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_ENABLE_SERVOSTIK=\"Enable ServoStik\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SERVOSTIK_DEFAULT" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_SERVOSTIK_DEFAULT=\"ServoStik Default: \"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FAVBUTTON_BEHAVIOUR" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_FAVBUTTON_BEHAVIOUR=\"P2-Start Button\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_TOGGLE_SERVOSTIK" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 08JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_TOGGLE_SERVOSTIK=\"Toggle ServoStik\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  
  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_TEXT_COLOR" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 21JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_MENU_TEXT_COLOR=\"Text Color: \"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_TOGGLE_SERVOSTIK_OPTION" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 21JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_TOGGLE_SERVOSTIK_OPTION=\"Toggle ServoStik Option\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SET_4_8_WAY_GAMES" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 21JUL21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_SET_4_8_WAY_GAMES=\"Set Games 4-8-Way\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_TEXT_COLOR" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 21JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_MENU_TEXT_COLOR=\"Text Color: \"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_TOGGLE_SERVOSTIK_OPTION" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 21JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_TOGGLE_SERVOSTIK_OPTION=\"Toggle ServoStik Option\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SET_4_8_WAY_GAMES" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 21JUL21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_SET_4_8_WAY_GAMES=\"Set Games 4-8-Way\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_01SEP21
if [ "$running_version" -lt 20210901 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 01SEP21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_01SEP21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1oSVPOCX705sTd_U7tatEeb0UTBNtupPy"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_01SEP21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  if [ -e /mnt/data/rpi2jamma ]; then
    cp -rn /tmp/logos /mnt/data/rpi2jamma
  fi
  if [ -e /mnt/usb/rpi2jamma ]; then
    cp -rn /tmp/logos /mnt/usb/rpi2jamma
  fi
  
  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_GAME_PREVIEW_LOGOS" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_GAME_PREVIEW_LOGOS=\"Game Preview Logos\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_HIGHLIGHT_COLOR" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_MENU_HIGHLIGHT_COLOR=\"Highlight Color: \"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_TEXT_SIZE" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_MENU_TEXT_SIZE=\"Text Size: \"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_NORMAL" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_NORMAL=\"Normal\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SMALL" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_SMALL=\"Small\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_TEXT_JUSTIFY" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_MENU_TEXT_JUSTIFY=\"Text Align: \"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_GAME_PREVIEW_LOGOS" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_GAME_PREVIEW_LOGOS=\"Game Preview Logos\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_HIGHLIGHT_COLOR" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_MENU_HIGHLIGHT_COLOR=\"Highlight Color: \"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_TEXT_SIZE" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_MENU_TEXT_SIZE=\"Text Size: \"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_NORMAL" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_NORMAL=\"Normal\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SMALL" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_SMALL=\"Small\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_MENU_TEXT_JUSTIFY" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_MENU_TEXT_JUSTIFY=\"Text Align: \"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_24SEP21
if [ "$running_version" -lt 20210924 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 24SEP21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_24SEP21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=19AsF416evx5GI3mknctWBo1sWUhBzznH"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_24SEP21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  
  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FAVGAMES_BACKUP" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 24SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_FAVGAMES_BACKUP=\"Backup Fav. Settings\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FAVGAMES_RESTORE" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 24SEP21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_FAVGAMES_RESTORE=\"Restore Fav. Settings\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FAVGAMES_BACKUP" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 24SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_FAVGAMES_BACKUP=\"Backup Fav. Settings\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FAVGAMES_RESTORE" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 24SEP21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_FAVGAMES_RESTORE=\"Restore Fav. Settings\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_27SEP21
if [ "$running_version" -lt 20210927 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 27SEP21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_27SEP21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1pMw3ZOagTguFfMRncolvVynTneKakRfH"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_27SEP21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

fi

# patch_04OCT21
if [ "$running_version" -lt 20211004 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 04OCT21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_04OCT21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1sRDqfR2owmryMM1gYL8pToHMiw6A5r9C"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_04OCT21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

fi

# patch_20OCT21
if [ "$running_version" -lt 20211020 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 20OCT21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_20OCT21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1qGyDbc0RKCECmqbczcqAESKk81HK2um8"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_20OCT21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
  
  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CONTROL_SETTINGS" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_CONTROL_SETTINGS=\"Control Settings\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_BACKUP_RESTORE" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_BACKUP_RESTORE=\"Backup/Restore\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_HIDE_MATURE" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_HIDE_MATURE=\"Hide Mature Games\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SCREENSAVER_OPTION" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_SCREENSAVER_OPTION=\"Screensaver Option\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FILTER_GAMES_OPTION" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_FILTER_GAMES_OPTION=\"Filter Games Option\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_GROUP_GAMES_OPTION" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_GROUP_GAMES_OPTION=\"Group Games Option\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    cat /tmp/language_filter_settings >> /mnt/data/rpi2jamma/language.ini
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CONTROL_SETTINGS" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_CONTROL_SETTINGS=\"Control Settings\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_BACKUP_RESTORE" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_BACKUP_RESTORE=\"Backup/Restore\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_HIDE_MATURE" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_HIDE_MATURE=\"Hide Mature Games\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_SCREENSAVER_OPTION" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_SCREENSAVER_OPTION=\"Screensaver Option\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_FILTER_GAMES_OPTION" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_FILTER_GAMES_OPTION=\"Filter Games Option\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_GROUP_GAMES_OPTION" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 20OCT21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_GROUP_GAMES_OPTION=\"Group Games Option\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    cat /tmp/language_filter_settings >> /mnt/usb/rpi2jamma/language.ini
  fi

fi

# patch_26OCT21
if [ "$running_version" -lt 20211026 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 26OCT21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_26OCT21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1C9MScIbhiYAlorN01HeYuE9jLyL7WvSH"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_26OCT21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

fi

# patch_06DEC21
if [ "$running_version" -lt 20211206 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 06DEC21   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_06DEC21.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1bAuAKxmO0X4mxHNbAR7d7_ONTER2w7fF"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_06DEC21.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_AUTOSTART_LAST_GAME" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 06DEC21" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_AUTOSTART_LAST_GAME=\"Autostart Last Game\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_AUTOSTART_LAST_GAME" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 06DEC21" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_AUTOSTART_LAST_GAME=\"Autostart Last Game\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_26DEC21
#if [ "$running_version" -lt 20211226 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 26DEC21   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_26DEC21.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1nfwN07VT-7OGwpGblWkwLAUaDN_oe-oV"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_26DEC21.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

# patch_27JAN22
if [ "$running_version" -lt 20220127 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 27JAN22   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_27JAN22.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1V1At9Hxy_M90r1aIQJZByGal9d75PQw_"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_27JAN22.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

fi

# patch_26MAR22
if [ "$running_version" -lt 20220326 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 26MAR22   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_26MAR22.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1jieebAvWuWBHpZST-OK0MHjosTxk98B6"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_26MAR22.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition (should have been added with 27JAN22 update already)
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_ADVMENU" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_ADVMENU=\"AdvanceMENU Frontend\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_AUTOSTART_ADVMENU" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_AUTOSTART_ADVMENU=\"Boot into AdvanceMENU\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick (should have been added with 27JAN22 update already)
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_ADVMENU" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_ADVMENU=\"AdvanceMENU Frontend\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_AUTOSTART_ADVMENU" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_AUTOSTART_ADVMENU=\"Boot into AdvanceMENU\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_GROUP_GAMES_ORIENTATION" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 26MAR22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_GROUP_GAMES_ORIENTATION=\"Group by Orientation\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_HORIZONTAL_FILTER" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 26MAR22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_HORIZONTAL_FILTER=\"Horizontal Games Only\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_VERTICAL_FILTER" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 26MAR22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_VERTICAL_FILTER=\"Vertical Games Only\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_GROUP_GAMES_ORIENTATION" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 26MAR22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_GROUP_GAMES_ORIENTATION=\"Group by Orientation\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_HORIZONTAL_FILTER" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 26MAR22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_HORIZONTAL_FILTER=\"Horizontal Games Only\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_VERTICAL_FILTER" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 26MAR22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_VERTICAL_FILTER=\"Vertical Games Only\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_22APR22
if [ "$running_version" -lt 20220422 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 22APR22   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_22APR22.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1yzut8-8bdJialG6jpQOQlZKMdnref9Ap"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_22APR22.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

# patch_07MAY22
if [ "$running_version" -lt 20220507 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 07MAY22   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_07MAY22.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1BRs9SABPLEWL7dCt1O_h4fTgF0_5anf5"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_07MAY22.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DELETED" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 07MAY22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_DELETED=\"#DELETED# \"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DELETED_GAMES" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 07MAY22" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_DELETED_GAMES=\"Show Deleted Games\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DELETED" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 07MAY22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_DELETED=\"#DELETED# \"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DELETED_GAMES" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 07MAY22" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_DELETED_GAMES=\"Show Deleted Games\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_18MAY22
if [ "$running_version" -lt 20220518 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 18MAY22   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_18MAY22.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1cjIUEMdu6IyFx7nNfivh8chZ-mBJnVj8"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_18MAY22.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_15SEP22
#if [ "$running_version" -lt 20220915 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 15SEP22   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_15SEP22.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1p7EMvtp4XJfmE_5_vyyoPs1JDkj-0ae5"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_15SEP22.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_27JAN23
if [ "$running_version" -lt 20230127 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 27JAN23   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_27JAN23.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1AFq3Oa39YCmF4LawlqutlHaRlAxt_Bl2"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_27JAN23.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CLONE_JOYSTICKS" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN23" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_CLONE_JOYSTICKS=\"Clone Joysticks\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CLONE_BUTTONS" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN23" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_CLONE_BUTTONS=\"Clone Buttons\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CLONE_JOYSTICKS" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN23" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_CLONE_JOYSTICKS=\"Clone Joysticks\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_CLONE_BUTTONS" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 27JAN23" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_CLONE_BUTTONS=\"Clone Buttons\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_19FEB23
if [ "$running_version" -lt 20230219 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 19FEB23   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_19FEB23.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1jJK27C4zbHkQHuN_NZF1MfHLBhPM1Ny5"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_19FEB23.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

# patch_16MAR23
if [ "$running_version" -lt 20230316 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 16MAR23   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_16MAR23.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1XILsZvTBPck0rQ6ylqsTLNVYyMnR6AEP"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_16MAR23.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DIAL_FILTER" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 16MAR23" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_DIAL_FILTER=\"Dial Control Games\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_AUTO_INSERT_COIN" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 16MAR23" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_AUTO_INSERT_COIN=\"Auto Insert Coin\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_BOOT_INTO_GAMELIST" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 16MAR23" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_BOOT_INTO_GAMELIST=\"Boot into Game List\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_DIAL_FILTER" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 16MAR23" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_DIAL_FILTER=\"Dial Control Games\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_AUTO_INSERT_COIN" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 16MAR23" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_AUTO_INSERT_COIN=\"Auto Insert Coin\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_BOOT_INTO_GAMELIST" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 16MAR23" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_BOOT_INTO_GAMELIST=\"Boot into Game List\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_29MAR23
#if [ "$running_version" -lt 20230329 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 29MAR23   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_29MAR23.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1o_0I07k9V5weQRyePyPHx7aO0quHZxE9"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_29MAR23.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
# patch_16OCT23
#if [ "$running_version" -lt 20231016 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 16OCT23   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_16OCT23.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1KRdRNb0JgPKhhGM4_MN-9N6dxZpJKm-M"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_16OCT23.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_05NOV23
if [ "$running_version" -lt 20231105 ] || [ ! -e "/root/pikeyd165_escapekey.conf" ]; then
  # patch_16OCT23 (should not have been disabled as 'obsolete' before, some file would be missing)
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 16OCT23   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_16OCT23.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1KRdRNb0JgPKhhGM4_MN-9N6dxZpJKm-M"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_16OCT23.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 05NOV23   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_05NOV23.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1nehlj-QrL3V2lYRGLCOSZIMbrX_SpNFr"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_05NOV23.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

# patch_09FEB24
if [ "$running_version" -lt 20240209 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 09FEB24   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_09FEB24.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1IEKNeXoR5KYCgYNxF3GPEZ7Eis0W7sCZ"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_09FEB24.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  ln -sf /usr/lib/libusbrelay.so.1.2 /usr/lib/libusbrelay.so.1
  ln -sf /usr/lib/libusbrelay.so.1.2 /usr/lib/libusbrelay.so

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_BUTTONS_456" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 09FEB24" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_BUTTONS_456=\"Enable Buttons 4-6\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_JAMMA_SWITCH_TEST" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 09FEB24" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_JAMMA_SWITCH_TEST=\"Jamma Switch Test\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_BUTTONS_456" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 09FEB24" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_BUTTONS_456=\"Enable Buttons 4-6\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_JAMMA_SWITCH_TEST" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 09FEB24" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_JAMMA_SWITCH_TEST=\"Jamma Switch Test\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_14FEB24
if [ "$running_version" -lt 20240214 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 14FEB24   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_14FEB24.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1ByUbj2qq5CWai_LAuedzEOqehBcv0RBD"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_14FEB24.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi


# patch_25JUL24
if [ "$running_version" -lt 20240725 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 25JUL24   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_25JUL24.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1HC1guT-t5yMPhFNK4BQpNgHCtz8Egw_r"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_25JUL24.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_VIDEO_LOOP" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 25JUL24" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_VIDEO_LOOP=\"Loop Videos\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_VIDEO_LOOP" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 25JUL24" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_VIDEO_LOOP=\"Loop Videos\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_31OCT24
#if [ "$running_version" -lt 20241031 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 31OCT24   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_31OCT24.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1QbwhHYEGboY2sCHQeQhQYrGKubAj7PJ-"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_31OCT24.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi
#
# patch_24NOV24
#if [ "$running_version" -lt 20241124 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 24NOV24   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_24NOV24.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1enzjhO4LW6R3VNW0o8u6piakozv7oh6J"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_24NOV24.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_01NOV25
if [ "$running_version" -lt 20251101 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 01NOV25   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_01NOV25.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=17iGX6mrTFj82G6Gl7YNk-vnVzgwUzHT-"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_01NOV25.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )

  # On DATA partition
  if [ -e /mnt/data/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_COCKTAIL" /mnt/data/rpi2jamma/language.ini; then
      echo >> /mnt/data/rpi2jamma/language.ini
      echo "# Added by patch update 01NOV25" >> /mnt/data/rpi2jamma/language.ini
      echo "TEXT_COCKTAIL=\"Cocktail Mode\"" >> /mnt/data/rpi2jamma/language.ini
    fi
  fi

  # On USB stick
  if [ -e /mnt/usb/rpi2jamma/language.ini ]; then
    if ! grep -q "TEXT_COCKTAIL" /mnt/usb/rpi2jamma/language.ini; then
      echo >> /mnt/usb/rpi2jamma/language.ini
      echo "# Added by patch update 01NOV25" >> /mnt/usb/rpi2jamma/language.ini
      echo "TEXT_COCKTAIL=\"Cocktail Mode\"" >> /mnt/usb/rpi2jamma/language.ini
    fi
  fi

fi

# patch_04NOV25
if [ "$running_version" -lt 20251104 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 04NOV25   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_04NOV25.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1V96F8UXEYSQbvMkBfZ0OCpod2U6Xp1cz"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_04NOV25.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi

### Obsolete: All updated files will be overwriten by following patch(es) ###
## patch_25DEC25
#if [ "$running_version" -lt 20251225 ]; then
#  echo
#  echo
#  echo "########################################"
#  echo "#                                      #"
#  echo "#    download/install patch: 25DEC25   #"
#  echo "#                                      #"
#  echo "########################################"
#  echo
#
#  downloadfile="/tmp/patch_pinhp_25DEC25.tgz"
#  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1wrzxzUPBWdEg-UbBEcAWjzPfvodU2UYa"
#  fi
#  # Test if download is valid, otherwise download from alternative server
#  gunzip -t "$downloadfile" &> /dev/null
#  response=$?
#  if [ "$response" != "0" ]; then
#    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_25DEC25.tgz"  
#  fi
#  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
#fi

# patch_14FEB26
if [ "$running_version" -lt 20260214 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 14FEB26   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_14FEB26.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=1ar_Tj6r8et-iVXCcmmuDa9LxIQUIJbef"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_14FEB26.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi
cd /root

# patch_12MAR26
if [ "$running_version" -lt 20260312 ]; then
  echo
  echo
  echo "########################################"
  echo "#                                      #"
  echo "#    download/install patch: 12MAR26   #"
  echo "#                                      #"
  echo "########################################"
  echo

  downloadfile="/tmp/patch_pinhp_12MAR26.tgz"
  if [ ! -e "$downloadfile" ] && [ "$UPDATE_SERVER" = "1" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://drive.google.com/uc?export=download&id=10h8gE6uKAtrX-JOavVk8nwOSwwo_59R6"
  fi
  # Test if download is valid, otherwise download from alternative server
  gunzip -t "$downloadfile" &> /dev/null
  response=$?
  if [ "$response" != "0" ]; then
    curl --connect-timeout $connection_timeout -k -L -o "$downloadfile" "https://github.com/pinHP/arcade/raw/main/patchfiles/patch_pinhp_12MAR26.tgz"  
  fi
  ( cd / ; tar -xzvf "$downloadfile" --warning=no-timestamp )
fi
cd /root


