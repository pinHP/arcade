# Control Settings sub menu

rm $CFGMENUTMP &> /dev/null
touch $CFGMENUTMP
hash_return_title="$TEXT_CONTROL_SETTINGS"
hash_return_par="enter_control_settings_menu"

echo "menu \"$TEXT_BACK\" {" >> $CFGMENUTMP
echo "sorted = false" >> $CFGMENUTMP
echo "game { rom =\"back\" title =\"$TEXT_BACK_TO_MAIN_MENU\" params =\"exit_settings_menu\" orientation =\"a\" }" >> $CFGMENUTMP
echo "}" >>$CFGMENUTMP

echo "menu \"$TEXT_CONTROL_SETTINGS\" {" >>$CFGMENUTMP
echo "sorted = false" >>$CFGMENUTMP
echo "game { rom =\"back\" title =\"$TEXT_BACK\" params =\"exit_settings_menu\" orientation =\"a\" } " >>$CFGMENUTMP
echo "game { rom =\"back\" title =\"---\" params =\"exit_settings_menu\" orientation =\"a\" } " >>$CFGMENUTMP
echo "game { rom =\"pinhp\" title =\"\xB7${TEXT_HARDWARE_MODE}Pi2${hardwaremode_current}\" params =\"hardwaremode\" orientation =\"a\" } " >>$CFGMENUTMP
echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_USB_GAMEPAD$gamepad_current\" params =\"select_usb_gamepad\" orientation =\"a\" } " >>$CFGMENUTMP
if [ "$servostik" = "Y" ]; then
  echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_ENABLE_SERVOSTIK\" params =\"enable_servostik\" orientation =\"a\" } " >>$CFGMENUTMP
  echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_SERVOSTIK_DEFAULT$servostik_default\" params =\"servostik_default\" orientation =\"a\" } " >>$CFGMENUTMP
else
  echo "game { rom =\"pinhp\" title =\"$TEXT_ENABLE_SERVOSTIK\" params =\"enable_servostik\" orientation =\"a\" } " >>$CFGMENUTMP
fi
if [ "$servostik" = "Y" ] ; then
  if [ "$set_4_8_way_flag" = "1" ]; then
    echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_SET_4_8_WAY_GAMES\" params =\"set_4_8_way_games\" orientation =\"a\" } " >>$CFGMENUTMP
  else
    echo "game { rom =\"pinhp\" title =\"$TEXT_SET_4_8_WAY_GAMES\" params =\"set_4_8_way_games\" orientation =\"a\" } " >>$CFGMENUTMP
  fi    
fi
echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_FAVBUTTON_BEHAVIOUR\" params =\"favbutton_behaviour\" orientation =\"a\" } " >>$CFGMENUTMP
if [ "$hardwaremode_current" = "Jamma" ]; then
  if [ "$buttons_456" != "0" ]; then
    echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_BUTTONS_456\" params =\"buttons_456\" orientation =\"a\" } " >>$CFGMENUTMP
  else
    echo "game { rom =\"pinhp\" title =\"$TEXT_BUTTONS_456\" params =\"buttons_456\" orientation =\"a\" } " >>$CFGMENUTMP  
  fi
  if [ "$clone_buttons" = "Y" ]; then
    echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_CLONE_BUTTONS\" params =\"clone_buttons\" orientation =\"a\" } " >>$CFGMENUTMP
  else
    echo "game { rom =\"pinhp\" title =\"$TEXT_CLONE_BUTTONS\" params =\"clone_buttons\" orientation =\"a\" } " >>$CFGMENUTMP  
  fi
  if [ "$clone_joysticks" = "Y" ]; then
    echo "game { rom =\"pinhp\" title =\"\xB7$TEXT_CLONE_JOYSTICKS\" params =\"clone_joysticks\" orientation =\"a\" } " >>$CFGMENUTMP
  else
    echo "game { rom =\"pinhp\" title =\"$TEXT_CLONE_JOYSTICKS\" params =\"clone_joysticks\" orientation =\"a\" } " >>$CFGMENUTMP  
  fi
  echo "game { rom =\"pinhp\" title =\"$TEXT_JAMMA_SWITCH_TEST\" params =\"jamma_switch_test\" orientation =\"a\" } " >>$CFGMENUTMP
fi
echo "}" >>$CFGMENUTMP
