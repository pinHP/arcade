#!/bin/bash

### pinHP Arcade image ###
### 12 MAR 2026 ###

### Static variables BEGIN ###

VERSION=20260312    
ABOUTDIALOG_DATE="\n(12MAR26)"
ABOUTDIALOG_TEXT="\n\nBrought to you by pinHP\n\nSpecial thanks to:\n\n- Mr.Do: Original concept\n- Freaktech, AndyHazz\n  and Brik: Support\n- ArcadeForge:\n  Pi2Jamma / Pi2SCART\\n\nwww.pinhp-image.com"
ADVMHOME="/root/.advance"
MAMECONFIG="$ADVMHOME/advmame.rc"
MAX_MAMECONFIG="3"
DIR_SD="/mnt/data"
DIR_USB="/mnt/usb"
# Default roms dir, will be updated after USB stick detection
RPI2JAMMA="$DIR_SD/rpi2jamma"
CONFIGFILE="$RPI2JAMMA/config.ini"
LANGUAGEFILE="$RPI2JAMMA/language.ini"
LLCONFH="/root/.lemonlauncherH/lemonlauncher.conf"
LLCONFV="/root/.lemonlauncherV/lemonlauncher.conf"
GENERATFLAG=0
SECONDS=0
SYSTEMMENU=0
# As sed delimiter, use the character that has the octal value 001 - in ASCII it's the SOH character (start of heading)
DELIM=$(echo -en "\001")
# Delimiter, framing custom folder names in Lemonlauncher's games.conf
DLM=":::DELIM:::"
INTERNAL_THEMES=16
UPDATE_SERVER="https://drive.google.com/uc?export=download&id=1k5TDVGDbYeM2t7z8oMW31tnuXD4h_OMd"
UPDATE_SERVER_2="https://github.com/pinHP/arcade/raw/main/patch-update/update_server"
# UPDATE_SERVER=https://tinyurl.com/yce2lcmd
CURL_TIMEOUT=30
HIDEDIR="#"
FAVMARK="  (+) "
MENUMARK="(+) "
MENUMARKCOLOR="0x66ccff"
AUTOSTART_GAME_NETWORK_TIMEOUT=20
AUTOROTATE_DEFAULT="H"

### Static variables BEGIN ###

### Text variables BEGIN ###

#
# Menu text definitions, will be overridden by language.ini file
#

# Main screen
TEXT_SYSTEM_SETTINGS_MENU="System Settings Menu"
TEXT_MONITOR_TEST_CARD="Monitor Test Card"
TEXT_UPTIME="Uptime: "
TEXT_QUICK_EDIT_MODE="Quick Edit Mode"
TEXT_SELECT_FAV_GAMES="Select Fav. Games"
TEXT_DESELECT_FAV_GAMES="Deselect Fav. Games"
TEXT_SELECT_2ND_MENU_GAMES="Select 2nd Menu Games"
TEXT_DESELECT_2ND_MENU_GAMES="Deselect 2nd Menu Games"
TEXT_SET_4_8_WAY_GAMES="Set Games 4-8-Way" 
TEXT_SELECT_AUTOSTART_GAME="Select Autostart Game"
TEXT_AUTOSTART_GAME="Autostart Game"
TEXT_AUTOSTART="Autostart"
TEXT_NO_AUTOSTART="No Autostart"
TEXT_BOOT_INTO_SCREENSAVER="Boot into Screensaver"
TEXT_CLEAR_ALL_HISCORES="Clear ALL Hiscores"
TEXT_UNDO_CLEAR_ALL_HISCORES="UNDO Clear Hiscores"
TEXT_HIDE_SETTINGS_MENU="* HIDE SETTINGS MENU *"
TEXT_TO_DISPLAY_THIS_MENU="To display this menu"
TEXT_AGAIN_CLICK_EMPTY_LINES="again, click empty lines"
TEXT_IN_OPTIONS_MENU="in 'Options' menu"
TEXT_3_TIMES_SLOWLY="3 times slowly"

# Filter menu
TEXT_FILTER_GAMES="Filter Games"
TEXT_GROUP_GAMES="Group Games"
TEXT_CLEAR_ALL_FILTERS="Clear all Filters"
TEXT_GENRE_FILTER_INCLUDE="Genre Include"
TEXT_GENRE_FILTER_EXCLUDE="Genre Exclude"
TEXT_BUTTONS_FILTER="Buttons Filter"
TEXT_CLONE_FILTER="Clone Filter"
TEXT_DECADE_FILTER="Decade Filter"
TEXT_MANUFACTURER_FILTER_INCLUDE="Manufacturer Include"
TEXT_MANUFACTURER_FILTER_EXCLUDE="Manufacturer Exclude"
TEXT_MATURE_FILTER="Mature Filter"
TEXT_PLAYERS_FILTER="Players Filter"
TEXT_RECOMMENDED_FILTER="Recommended Filter"
TEXT_SYSTEM_FILTER_INCLUDE="Game System Include"
TEXT_SYSTEM_FILTER_EXCLUDE="Game System Exclude"
TEXT_SLOW_FILTER="Slow Games Filter"
TEXT_HORIZONTAL_FILTER="Horizontal Games Only"
TEXT_VERTICAL_FILTER="Vertical Games Only"
TEXT_DIAL_FILTER="Dial Control Games"
TEXT_GROUP_GAMES_SYSTEM="Group by Game System"
TEXT_GROUP_GAMES_GENRE="Group by Genre"
TEXT_GROUP_GAMES_MANUFACTURER="Group by Manufacturer"
TEXT_GROUP_GAMES_YEAR="Group by Decade"
TEXT_GROUP_GAMES_ORIENTATION="Group by Orientation"
TEXT_OTHER="Other"
TEXT_SHOW_OTHER="Show 'Other' Menu"
TEXT_ADD_MANUFACTURER="List Manufacturer"
TEXT_REMOVE_MANUFACTURER="Unlist Manufacturer"
TEXT_ADD_GENRE="List Genre"
TEXT_REMOVE_GENRE="Unlist Genre"
TEXT_ADD_SYSTEM="List Game System"
TEXT_REMOVE_SYSTEM="Unlist Game System"
TEXT_RESET_LISTS="Reset All"

# System settings menu - categories
TEXT_GAME_MENU_SETTINGS="Game Menu Settings"
TEXT_OPTIONS_MENU_SETTINGS="Options Menu Settings"
TEXT_LANGUAGE_SETTINGS="Language Settings"
TEXT_MAME_SETTINGS="Mame Settings"
TEXT_SCREEN_SETTINGS="Screen Settings"
TEXT_SYSTEM_SETTINGS="System Settings"
TEXT_ONLINE_TOOLS="Online Tools"
TEXT_EXIT_INTO_SHELL="Exit into Shell"
TEXT_BACK="Back"
TEXT_BACK_TO_MAIN_MENU="Back to Main Menu"
TEXT_CONTROL_SETTINGS="Control Settings"
TEXT_BACKUP_RESTORE="Backup/Restore"
TEXT_FILTER_MENU_SETTINGS="Filter Settings"

# Game menu settings
TEXT_1_LINE_GAME_MENU="1 Line Game Menu"
TEXT_2_LINE_GAME_MENU="2 Line Game Menu"
TEXT_3_LINE_GAME_MENU="3 Line Game Menu"
TEXT_FAV_GAMES_MENU_ONLY="Fav. Games Menu Only"
TEXT_FAV_AND_SECOND_MENU_ONLY="Fav. & 2nd Menu Only"
TEXT_CUSTOM_FOLDERS="Custom Folders"
TEXT_CUSTOM_FAVMENU="Show Fav. Menu"
TEXT_GAME_COUNT="Game Count"
TEXT_GAME_PREVIEW_IMAGES="Game Preview Images"
TEXT_GAME_PREVIEW_VIDEOS="Game Preview Videos"
TEXT_VIDEO_LOOP="Loop Videos"
TEXT_VIDEO_VOLUME="Video Volume: "
TEXT_LOW="LOW"
TEXT_MID="MID"
TEXT_HIGH="HIGH"
TEXT_OFF="OFF"
TEXT_ON="ON"
TEXT_AUTO="Auto"
TEXT_GAME_PREVIEW_MARQUEES="Game Preview Marquees"
TEXT_GAME_PREVIEW_LOGOS="Game Preview Logos"
TEXT_DISPLAY_FRIENDLY_NAMES="Display Friendly Names"
TEXT_ORIENTATIONFILTER="Orientationfilter: "
TEXT_NO_GAMES_FOUND="--- No games found ---"
TEXT_APPLY_CHANGES="APPLY CHANGES"
TEXT_FAVGAMES_BACKUP="Backup Fav. Settings"
TEXT_FAVGAMES_RESTORE="Restore Fav. Settings"
TEXT_HIDE_MATURE="Hide Mature Games"
TEXT_DELETED="#DELETED# "
TEXT_DELETED_GAMES="Show Deleted Games"

# Options menu settings
TEXT_REBOOT_OPTION="Reboot Option"
TEXT_SHUTDOWN_OPTION="Shutdown Option"
TEXT_BACKUP_OPTION="Backup Option"
TEXT_RESTORE_OPTION="Restore Option"
TEXT_TOGGLE_SERVOSTIK="Toggle ServoStik"
TEXT_TOGGLE_SERVOSTIK_OPTION="Toggle ServoStik Option"
TEXT_SCREENSAVER_OPTION="Screensaver Option"
TEXT_FILTER_GAMES_OPTION="Filter Games Option"
TEXT_GROUP_GAMES_OPTION="Group Games Option"

# Mame settings
TEXT_ACTIVE_MAME_CONFIG="Active Mame Config: "
TEXT_ARTWORK_BACKDROP="Artwork Backdrop"
TEXT_ARTWORK_OVERLAY="Artwork Overlay"
TEXT_BRIGHTNESS="Brightness: "
TEXT_GAMMA="Gamma: "
TEXT_VECTOR_ANTIALIAS="Vector Antialias"
TEXT_VSYNC="Vsync"
TEXT_ENABLE_CHEATS="Enable Cheats"
TEXT_FREE_PLAY="Free Play"
TEXT_IDLE_EXIT="Idle Exit: "
TEXT_1_MIN="1:00 min"
TEXT_5_MIN="5:00 min"
TEXT_10_MIN="10:00 min"
TEXT_20_MIN="20:00 min"
TEXT_CUSTOM_IDLE_EXIT_TIME="Custom Idle Exit Time"
TEXT_PAUSE_DIM_SCREEN="Pause Dim Screen"
TEXT_SOUND_NORMALIZE="Sound Normalize"
TEXT_MONO_STEREO="Mono/Stereo: "
TEXT_MONO="Mono"
TEXT_STEREO="Stereo"
TEXT_SURROUND="Surround"
TEXT_H_GAMES_ROTATE_L="H-Games rotate L"
TEXT_V_GAMES_ROTATE_L="V-Games rotate L"
TEXT_DISPLAY_BUTTON_LAYOUT="Display Button Layout"
TEXT_AUTO_INSERT_COIN="Auto Insert Coin"
TEXT_COCKTAIL="Cocktail Mode"

# Screen settings
TEXT_ORIENTATION_H="Orientation H"
TEXT_ORIENTATION_V="Orientation V"
TEXT_ORIENTATION_A="Orientation A"
TEXT_MENU_SIZE="Menu Size: "
TEXT_MIDI="Midi"
TEXT_MAXI="Maxi"
TEXT_COLOR="Color: "
TEXT_YELLOW=" Yellow"
TEXT_SILVER=" Silver"
TEXT_RAINBOW="Rainbow"
TEXT_VIVID="  Vivid"
TEXT_MENU_TEXT_COLOR="Text Color: "
TEXT_MENU_HIGHLIGHT_COLOR="Highlight Color: "
TEXT_MENU_TEXT_SIZE="Text Size: "
TEXT_NORMAL="Normal"
TEXT_SMALL="Small"
TEXT_MENU_TEXT_JUSTIFY="Text Align: "
TEXT_SCREEN_UPSIDE_DOWN="Screen Upside Down"

# System settings
TEXT_HARDWARE_MODE="Hardware Mode: "
TEXT_USB_GAMEPAD="USB Gamepad: "
TEXT_SCREENSAVER="Screensaver: "
TEXT_IDLE_SCREENSAVER="Idle Screensaver: "
TEXT_CUSTOM_SCREENSAVER_TIME="Custom Screensaver Time"
TEXT_SCREENSAVER_TYPE="Screensaver Type: "
TEXT_STATUS_MESSAGES="Status Messages"
TEXT_GAME_VOLUME="Game Volume"
TEXT_SYSTEM_BOOT_DATE="System Boot Date"
TEXT_SET_TIME_ZONE="Set Time Zone"
TEXT_MAX_DATA_PARTITION="Max. Data Partition"
TEXT_COPY_GAMES_FROM_SD_TO_USB="Copy Games from SD to USB"
TEXT_COPY_GAMES_FROM_USB_TO_SD="Copy Games from USB to SD"
TEXT_RUN_EXTERNAL_FILE="Run External File"
TEXT_ENABLE_SERVOSTIK="Enable ServoStik"
TEXT_SERVOSTIK_DEFAULT="ServoStik Default: "
TEXT_FAVBUTTON_BEHAVIOUR="P2-Start Button"
TEXT_AUTOSTART_LAST_GAME="Autostart Last Game"
TEXT_ADVMENU="AdvanceMENU Frontend"
TEXT_AUTOSTART_ADVMENU="Boot into AdvanceMENU"
TEXT_CLONE_JOYSTICKS="Clone Joysticks"
TEXT_CLONE_BUTTONS="Clone Buttons"
TEXT_BOOT_INTO_GAMELIST="Boot into Game List"
TEXT_BUTTONS_456="Enable Buttons 4-6"
TEXT_JAMMA_SWITCH_TEST="Jamma Switch Test"

# Online tools
TEXT_WIFI_SETUP="Wi-Fi Setup"
TEXT_QUICK_CONNECT="Connect now: "
TEXT_AUTO_CONNECT="Auto Connect: "
TEXT_ACTIVE_PROFILE="Active Profile: "
TEXT_SHOW_IP_ADDRESS="Show IP Address"
TEXT_DISCONNECT_WIFI="Disconnect Wi-Fi"
TEXT_REMOVE_WIFI_PROFILES="Remove Wi-Fi Profiles"
TEXT_MAIL_ALARM="Uptime Alarm by Mail"
TEXT_TEST_ALARM_MAIL="Send Test Mail"
TEXT_CHECK_FOR_UPDATES="Check for Update"

# Language settings
TEXT_KEYBOARD="Keyboard: "

#
# Entries in config.ini will override the following default definitions
# They are as well acessible from the pinHP menu
# 

single_menu_title="Arcade Games"
menu_title_1_of_2="Fav. Games"
menu_title_2_of_2="All Games"
menu_title_1_of_3="Fav. Games"
menu_title_2_of_3="More Games"
menu_title_3_of_3="All Games"
menu_options="Options"
menu_back="Back"
menu_screensaver="Screensaver"
menu_reboot="Reboot"
menu_shutdown="Shutdown"
menu_backup="Backup Settings"
menu_restore="Restore Settings"
menu_about="About"

### Text variables END ###

### Functions BEGIN ###

pikeyd165_start ()
{
  if [ $1 != "$pikeyd_current" ] && [ "$pi2scartmode_current" != "Y" ] && [ "$disable_pikeyd165" != "Y" ]; then
    pikeyd165_stop
    pikeyd_current=$1
    if [ ! -f "/etc/pikeyd165.conf" ]; then
    ln -sf /tmp/pikeyd165.conf /etc/pikeyd165.conf
    fi

    case $1 in
      anykey )
        cp /root/pikeyd165_anykey.conf /tmp/pikeyd165.conf
      ;;
      default )
        cp /root/pikeyd165_default.conf /tmp/pikeyd165.conf
      ;;
      enterkey )
        cp /root/pikeyd165_enterkey.conf /tmp/pikeyd165.conf
      ;; 
      escapekey )
        cp /root/pikeyd165_escapekey.conf /tmp/pikeyd165.conf
      ;; 
      updown )
        cp /root/pikeyd165_updown.conf /tmp/pikeyd165.conf
        if [ "$clone_joysticks" = "Y" ]; then
          echo "KEY_UP    14" >> "/tmp/pikeyd165.conf"
          echo "KEY_DOWN  15" >> "/tmp/pikeyd165.conf"
          echo "KEY_DOWN  20" >> "/tmp/pikeyd165.conf"
          echo "KEY_UP    21" >> "/tmp/pikeyd165.conf"
        fi
        if [ "$clone_buttons" = "Y" ]; then
          echo "KEY_ESC  13" >> "/tmp/pikeyd165.conf"
        fi
      ;;  
      updowntabenter )
        cp /root/pikeyd165_updowntabenter.conf /tmp/pikeyd165.conf        
        if [ "$clone_joysticks" = "Y" ]; then
          echo "KEY_TAB   14" >> "/tmp/pikeyd165.conf"
          echo "KEY_TAB   15" >> "/tmp/pikeyd165.conf"
          echo "KEY_DOWN  20" >> "/tmp/pikeyd165.conf"
          echo "KEY_UP    21" >> "/tmp/pikeyd165.conf"
        fi
        if [ "$clone_buttons" = "Y" ]; then
          echo "KEY_ENTER  13" >> "/tmp/pikeyd165.conf"
        fi
      ;;
      yesno )
        cp /root/pikeyd165_yesno.conf /tmp/pikeyd165.conf
        if [ "$clone_joysticks" = "Y" ]; then
          echo "KEY_TAB  14" >> "/tmp/pikeyd165.conf"
          echo "KEY_TAB  15" >> "/tmp/pikeyd165.conf"
          echo "KEY_TAB  20" >> "/tmp/pikeyd165.conf"
          echo "KEY_TAB  21" >> "/tmp/pikeyd165.conf"
        fi
        if [ "$clone_buttons" = "Y" ]; then
          echo "KEY_SPACE  13" >> "/tmp/pikeyd165.conf"
        fi
      ;;
      spacequit )
        cp /root/pikeyd165_spacequit.conf /tmp/pikeyd165.conf
      ;;
      advmenu )
        cp /root/pikeyd165_advmenu.conf /tmp/pikeyd165.conf
      ;;
      switchtest )
        cp /root/pikeyd165_switchtest.conf /tmp/pikeyd165.conf
      ;;
      * )
        cp /root/pikeyd165_default.conf /tmp/pikeyd165.conf       
      ;;
    esac

    if [ $1 != "switchtest" ]; then
      if [ "$clone_joysticks" = "Y" ]; then
        sed -i -e 's/KEY_G /KEY_RIGHT /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_D /KEY_LEFT /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_F /KEY_DOWN /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_R /KEY_UP /' "/tmp/pikeyd165.conf"
      fi
  
      if [ "$clone_buttons" = "Y" ] && [ "$1" != "spacequit" ]; then
        sed -i -e 's/KEY_A /KEY_LEFTCTRL /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_S /KEY_LEFTALT /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_Q /KEY_SPACE /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_W /KEY_LEFTSHIFT /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_K /KEY_Z /' "/tmp/pikeyd165.conf"
        sed -i -e 's/KEY_I /KEY_X /' "/tmp/pikeyd165.conf"
      fi

      if [ "$SYSTEMMENU" = "1" ]; then
        sed -i -e 's/KEY_LEFTALT.*11/KEY_2   11/' "/tmp/pikeyd165.conf"
      fi

      # Disable Jamma buttons 4-6
      case $buttons_456 in
        0 ) # Disable buttons 4/5/6
          sed -i '/\b1\b/d' "/tmp/pikeyd165.conf" # P1 B4
          sed -i '/\b2\b/d' "/tmp/pikeyd165.conf" # P1 B5
          sed -i '/\b3\b/d' "/tmp/pikeyd165.conf" # P1 B6
          sed -i '/\b4\b/d' "/tmp/pikeyd165.conf" # P2 B6
          sed -i '/\b5\b/d' "/tmp/pikeyd165.conf" # P2 B5
          sed -i '/\b6\b/d' "/tmp/pikeyd165.conf" # P2 B4
        ;;
        4 ) # Enable button 4 (= disable 5/6)
          sed -i '/\b2\b/d' "/tmp/pikeyd165.conf" # P1 B5
          sed -i '/\b3\b/d' "/tmp/pikeyd165.conf" # P1 B6
          sed -i '/\b4\b/d' "/tmp/pikeyd165.conf" # P2 B6
          sed -i '/\b5\b/d' "/tmp/pikeyd165.conf" # P2 B5
        ;;
        5 ) # Enable buttons 4/5 (= disable 6)
          sed -i '/\b2\b/d' "/tmp/pikeyd165.conf" # P1 B5
          sed -i '/\b5\b/d' "/tmp/pikeyd165.conf" # P2 B5
        ;;
        6 )
          : # Enable buttons 4/5/6 (do nothing)
        ;;
      esac

    fi

    /usr/bin/taskset -c 2 /root/pikeyd165 -ndb -d &> /dev/null
    if [ ! -z $2 ]; then
      sleep $2
    fi

  fi
}

pikeyd165_stop ()
{
    /root/pikeyd165 -k &> /dev/null
    killall pikeyd165 &> /dev/null
}

joy2key_start ()
{
  case $1 in
    anykey )
      joy2key -config anykey &> /dev/null &
    ;;
    enterkey )
      joy2key -config enterkey &> /dev/null &
    ;;
    yesno )
      joy2key -config yesno &> /dev/null &
    ;;
    noaxis )
      joy2key -config noaxis &> /dev/null &
    ;;
    escape )
      joy2key -config escape &> /dev/null &
    ;;
    updown )
      joy2key -config updown &> /dev/null &
    ;;
    updowntabenter )
      joy2key -config updowntabenter &> /dev/null &
    ;;
    spacequit )
      joy2key -config spacequit &> /dev/null &
    ;;
  esac
}

joy2key_stop ()
{
  pkill joy2key &> /dev/null
}

check_pi2scart ()
{
  # Detect hardware mode
    
  if [ "$force_hardwaremode" != "Y" ]; then
    if [ "$pi2scartmode_current" = "N" ] && [ "$PI2SCART_MODE_DETECTED" = "Y" ]; then
          pikeyd165_stop
          dialog --timeout 5 --title "pinHP Arcade Classics" --msgbox "\nPi2SCART detected, but\nthe system is set to\nJamma hardware mode.\n\nChecking ...\n\n" 0 0
          check_hardwaremode
    fi
    if  [ "$pi2scartmode_current" = "Y" ] && [ "$PI2SCART_MODE_DETECTED" = "N" ]; then
          dialog --timeout 5 --title "pinHP Arcade Classics" --msgbox "\nPi2Jamma detected, but\nthe system is set to\nSCART hardware mode.\n\nChecking ...\n\n" 0 0
          check_hardwaremode
    fi
  fi

  pikeyd165_start "force"

  # Create default Mame config file, according to hardware mode, in case it is missing
  if grep -q "Pi2Jamma mode" "$ADVMHOME/advmame.rc"; then
    if [ ! -e "$ADVMHOME/advmame_pi2jamma.rc" ] ; then
      cp "$ADVMHOME/advmame.rc" "$ADVMHOME/advmame_pi2jamma.rc"
    fi
  fi
  if grep -q "Pi2Scart mode" "$ADVMHOME/advmame.rc"; then
    if [ ! -e "$ADVMHOME/advmame_pi2scart.rc" ]; then
      cp "$ADVMHOME/advmame.rc" "$ADVMHOME/advmame_pi2scart.rc"
    fi
  fi
  
  # Set screen resolutions according to hardware mode
  case "$pi2scartmode_current" in

    Y )
      hardwaremode_current="SCART"
      if ! grep -q "Pi2Scart mode" "$ADVMHOME/advmame.rc"; then
        if grep -q "Pi2Jamma mode" "$ADVMHOME/advmame.rc"; then
          cp "$ADVMHOME/advmame.rc" "$ADVMHOME/advmame.rc"_"$current_mameconfig"_Jamma
        fi
        if [ -e "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"SCART" ]; then
          cp "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"SCART" "$ADVMHOME/advmame.rc"
        else
          cp "$ADVMHOME/advmame_pi2scart.rc" "$ADVMHOME/advmame.rc"
        fi
      fi

      if ! grep -q "Pi2Scart mode" "/boot/config.txt"; then
        if grep -q "Pi2Jamma mode" "/boot/config.txt"; then
          cp "/boot/config.txt" "/boot/config_pi2jamma.txt"
        fi
        cp "/boot/config_pi2scart.txt" "/boot/config.txt"
        grep hdmi_timings /boot/config.txt > /tmp/hdmi_timing.txt
        sed -i "/^#/d" /tmp/hdmi_timing.txt
        ll_res_tmp=$(grep -w -i "hdmi_timings" /tmp/hdmi_timing.txt | cut -d"#" -f1 |cut -d "=" -f2) &> /dev/null
        /opt/vc/bin/vcgencmd hdmi_timings $ll_res_tmp &> /dev/null
      fi
    ;;

    N )
      hardwaremode_current="Jamma"
      if ! grep -q "Pi2Jamma mode" "$ADVMHOME/advmame.rc"; then
        if grep -q "Pi2Scart mode" "$ADVMHOME/advmame.rc"; then
          cp "$ADVMHOME/advmame.rc" "$ADVMHOME/advmame.rc"_"$current_mameconfig"_SCART
        fi
        if [ -e "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"Jamma" ]; then
          cp "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"Jamma" "$ADVMHOME/advmame.rc"
        else
          cp "$ADVMHOME/advmame_pi2jamma.rc" "$ADVMHOME/advmame.rc"
        fi
      fi

      if ! grep -q "Pi2Jamma mode" "/boot/config.txt"; then
        if grep -q "Pi2Scart mode" "/boot/config.txt"; then
          cp "/boot/config.txt" "/boot/config_pi2scart.txt"
        fi
        cp "/boot/config_pi2jamma.txt" "/boot/config.txt"
        grep hdmi_timings /boot/config.txt > /tmp/hdmi_timing.txt
        sed -i "/^#/d" /tmp/hdmi_timing.txt
        ll_res_tmp=$(grep -w -i "hdmi_timings" /tmp/hdmi_timing.txt | cut -d"#" -f1 |cut -d "=" -f2) &> /dev/null
        /opt/vc/bin/vcgencmd hdmi_timings $ll_res_tmp &> /dev/null
      fi
    ;;

  esac
}

reboot_system ()
{
  clear
  echo
  echo
  echo "... Reboot"
  mkdir -p  "$RPI2JAMMA/autobackup/favgames"
  grep -E "(1TWO|1FAV)" $TEMPLATEFILE | grep -v "_DUMMY" > "$RPI2JAMMA/autobackup/favgames/favgames.template"
  cp -r $ADVMHOME/advmame.rc $RPI2JAMMA/autobackup/mame_config/ &> /dev/null
  cp  $RPI2JAMMA/config.ini $RPI2JAMMA/autobackup/rpi2jamma/  &>/dev/null
  cp  $RPI2JAMMA/language.ini $RPI2JAMMA/autobackup/rpi2jamma/  &>/dev/null
  cp  $ROMS_ADVM/_games.template $RPI2JAMMA/autobackup/rpi2jamma/roms_advmame/  &>/dev/null
  cleanup_all
  [ $MOUNTED_USB ] && umount $MOUNTED_USB >& /dev/null
  if [ "$RUN_WITHOUT_USB" != "Y" ]; then
    [ $MOUNTED_USB ] && umount $MOUNTED_USB >& /dev/null
  fi
  umount -l /dev/mmcblk0p3
  date > "$DEFAULT/last_shutdown_date.txt"
  sync
  sleep 1
  systemctl reboot
}

shutdown_system ()
{
  response=0
  if [ "$shutdown_dialog" = "Y" ]; then
    cp /root/default/dialogrc_shutdown /tmp/.dialogrc
    export DIALOGRC=/tmp/.dialogrc
    pikeyd165_start "escapekey" 0.5
    joy2key_start "escape"
    dialog --no-ok --title "pinHP Arcade Classics" --pause "\nSystem shutdown ...\n\n" 10 25 5
    response=$?
    joy2key_stop
    unset DIALOGRC
  fi
  setterm -cursor off
  clear
  if [ "$response" != "255" ]; then
    sync
    echo
    echo
    echo "... System shutdown"
    mkdir -p  "$RPI2JAMMA/autobackup/favgames"
    grep -E "(1TWO|1FAV)" $TEMPLATEFILE | grep -v "_DUMMY" > "$RPI2JAMMA/autobackup/favgames/favgames.template"
    cp -r $ADVMHOME/advmame.rc $RPI2JAMMA/autobackup/mame_config/ &> /dev/null
    cp  $RPI2JAMMA/config.ini $RPI2JAMMA/autobackup/rpi2jamma/  &>/dev/null
    cp  $RPI2JAMMA/language.ini $RPI2JAMMA/autobackup/rpi2jamma/  &>/dev/null
    cp  $ROMS_ADVM/_games.template $RPI2JAMMA/autobackup/rpi2jamma/roms_advmame/  &>/dev/null
    [ "$show_deleted_games" = "Y" ] && cleanup_all
    [ $MOUNTED_USB ] && umount $MOUNTED_USB >& /dev/null
    umount /dev/mmcblk0p3
    date > "$DEFAULT/last_shutdown_date.txt"
    sync
    sleep 1
    if [ -e "$SCRIPTS/custom/runscript-shutdown.sh" ]; then
      chmod +x "$SCRIPTS/custom/runscript-shutdown.sh"
      declare -p > /tmp/pinhp_variables
      bash "$SCRIPTS/custom/runscript-shutdown.sh"
      cd /root
      setterm -cursor off
      if [ -e "/tmp/external_vars" ]; then
        source /tmp/external_vars
        rm /tmp/external_vars
      fi
    else
      systemctl poweroff
    fi
  fi
}

# Set lemonlauncher directory according to $ORIENTATION
set_lemon_configdir ()
{
  cd /root
  if [ -e "/root/rpi2jamma/systemsnaps" ]; then
    rm -r /root/rpi2jamma/systemsnaps
  fi     
  if [ "$ORIENTATION" = "H" ]; then	
    ln -sfn .lemonlauncherH .lemonlauncher
    ln -sfn "/root/rpi2jamma/systemsnapsH" /root/rpi2jamma/systemsnaps
  else
  	ln -sfn .lemonlauncherV .lemonlauncher
    ln -sfn "/root/rpi2jamma/systemsnapsV" /root/rpi2jamma/systemsnaps
  fi
}

set_screen_theme ()
{
  case $screen_theme in
    1 )
      case $menu_text_size in
        1 )
          case $color_mode in
            1 )
              internal_screen_theme=1
            ;;
            2 )
              internal_screen_theme=3
            ;;
            3 )
              internal_screen_theme=5
            ;;
            4 )
              internal_screen_theme=7
            ;;
          esac
        ;;
        2 )
          case $color_mode in
            1 )
              internal_screen_theme=9
            ;;
            2 )
              internal_screen_theme=11
            ;;
            3 )
              internal_screen_theme=13
            ;;
            4 )
              internal_screen_theme=15
            ;;
          esac
        ;;
      esac
    ;;
    2)
      case $menu_text_size in
        1 )
          case $color_mode in
            1 )
              internal_screen_theme=2
            ;;
            2 )
              internal_screen_theme=4
            ;;
            3 )
              internal_screen_theme=6
            ;;
            4 )
              internal_screen_theme=8
            ;;
          esac
        ;;
        2 )
          case $color_mode in
            1 )
              internal_screen_theme=10
            ;;
            2 )
              internal_screen_theme=12
            ;;
            3 )
              internal_screen_theme=14
            ;;
            4 )
              internal_screen_theme=16
            ;;
          esac
        ;;
      esac
    ;;       
  esac
  ln -sfn "/root/.lemonlauncherH/bg$internal_screen_theme" /root/.lemonlauncherH/bg
  ln -sfn "/root/.lemonlauncherV/bg$internal_screen_theme" /root/.lemonlauncherV/bg
  ln -sf "/root/.lemonlauncherH/bg$internal_screen_theme/theme.conf" /root/.lemonlauncherH/theme.conf
  ln -sf "/root/.lemonlauncherV/bg$internal_screen_theme/theme.conf" /root/.lemonlauncherV/theme.conf
}

set_video_options ()
{
  if [ "$preview_videos" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/videos" /root/.lemonlauncher_common/lemonvideos
  else
    ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonvideos
  fi

  # Volume
  for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
    do
      sed -i -e "s/video_volume =.*/video_volume = $video_volume/" "/root/.lemonlauncherH/bg$theme/theme_main.conf"
      sed -i -e "s/video_volume =.*/video_volume = $video_volume/" "/root/.lemonlauncherV/bg$theme/theme_main.conf"
      sed -i -e "s/video_volume =.*/video_volume = $video_volume/" "/root/.lemonlauncherH/bg$theme/theme_system.conf"
      sed -i -e "s/video_volume =.*/video_volume = $video_volume/" "/root/.lemonlauncherV/bg$theme/theme_system.conf"
    done
  sync
}

# Delete md5sum files to force new menu generation
cleanup_all ()
{
  if [ -e "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_" ]; then
    rm "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_"
  fi
  if [ -e "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_" ]; then
    rm "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_"
  fi
  if [ -e "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_config_" ]; then
    rm "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_config_"
  fi
  if [ -e "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_config_" ]; then
    rm "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_config_"
  fi
  if [ -e "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_template_" ]; then
    rm "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_template_"
  fi
  if [ -e "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_template_" ]; then
    rm "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_template_"
  fi
  if [ -e "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_language_" ]; then
    rm "$DIR_USB/rpi2jamma/roms_advmame/_md5sum_language_"
  fi
  if [ -e "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_language_" ]; then
    rm "$DIR_SD/rpi2jamma/roms_advmame/_md5sum_language_"
  fi
  # Remove duplicate lines from config.ini, keep blank lines and comments. Remove blank lines from end of file
  awk '/^[[:blank:]#]*$/ { print; next; }; !seen[$0]++' $CONFIGFILE > /tmp/config.tmp && sed -i ':a;/^[ \n]*$/{$d;N;ba}' /tmp/config.tmp && mv /tmp/config.tmp $CONFIGFILE
  sync
}

backup_advmame ()
{
  joy2key_start "yesno"
  pikeyd165_start "yesno" "0.5"
  dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nBackup settings to\nrpi2jamma/backup" 8 26
  response=$?
  joy2key_stop
  clear
  if [ "$response" = "0" ]; then
    joy2key_start "anykey"
    pikeyd165_start "anykey"
    if [ -e "$RPI2JAMMA/backup.bak" ]; then
      rm -rf "$RPI2JAMMA/backup.bak"
    fi
    if [ -e "$RPI2JAMMA/backup" ]; then
      mv "$RPI2JAMMA/backup" "$RPI2JAMMA/backup.bak"
    fi
    mkdir -p $RPI2JAMMA/backup/
    mkdir -p $RPI2JAMMA/backup/hi
    mkdir -p $RPI2JAMMA/backup/mame_config/
    mkdir -p $RPI2JAMMA/backup/nvram
    mkdir -p $RPI2JAMMA/backup/netctl
    mkdir -p $RPI2JAMMA/backup/rpi2jamma
    mkdir -p $RPI2JAMMA/backup/rpi2jamma/roms_advmame
    mkdir -p $RPI2JAMMA/backup/settings

    copycount=0
    unset array
    declare -a array
    cp -r $ADVMHOME/advmame.rc $RPI2JAMMA/backup/mame_config/
    ((copycount++))
    array+=(advmame.rc)
    cp -r $ADVMHOME/advmenu.rc $RPI2JAMMA/backup/mame_config/
    ((copycount++))
    array+=(advmenu.rc)
    cp -r $ADVMHOME/advmess.rc $RPI2JAMMA/backup/mame_config/
    ((copycount++))
    array+=(advmess.rc)
    for (( i = 1; i <= 3; i++ ))
    do
    	if [ -e "$ADVMHOME/advmame.rc"_"$i"_"$hardwaremode_current" ]; then
        cp -r "$ADVMHOME/advmame.rc"_"$i"_"$hardwaremode_current" $RPI2JAMMA/backup/mame_config/
        ((copycount++))
         array+=(advmame.rc)
      fi
    done
    cp -v /etc/netctl/* $RPI2JAMMA/backup/netctl 2>/dev/null | awk -F'netctl' '{print $2}' | awk -F\' '{print $1}' > /tmp/netctl_copy
    netctl_count=$(cat /tmp/netctl_copy | wc -l)
    rm /tmp/netctl_copy
    copycount=$((copycount + netctl_count))
    for (( i=0; i<$netctl_count; ++i)); do
       array+=(netctl)
    done
    cp  $ROMS_ADVM/_games.template $RPI2JAMMA/backup/rpi2jamma/roms_advmame/  2>/dev/null
    ((copycount++))
    array+=(_games.template)
    cp  $RPI2JAMMA/language.ini $RPI2JAMMA/backup/rpi2jamma/  2>/dev/null
    ((copycount++))
    array+=(language.ini)
    cp  $RPI2JAMMA/config.ini $RPI2JAMMA/backup/rpi2jamma/  2>/dev/null
    ((copycount++))
    array+=(config.ini)
    echo $copycount >/tmp/copycount
    cp  /root/settings/_database.csv $RPI2JAMMA/backup/settings/  2>/dev/null
    ((copycount++))
    array+=(_database.csv)
    echo $copycount >/tmp/copycount

counter=0
steps=$(( 100 / copycount ))
i=0
(
# Set while loop until 100 %, simulation copy progress 
while :
do
cat <<EOF
XXX
$counter
\nBackup system: $i copied\n\n${array[$i]}
XXX
EOF
(( counter+=steps ))
[ $counter -gt 100 ] && break
((i++))
sleep 0.1
done
) |
dialog --title "pinHP Arcade Classics" --gauge "\nBackup system: $copycount copied\n\n${array[-1]}" 10 32
setterm -cursor off

# 100% dialog
dialog --title "pinHP Arcade Classics" --gauge "\nBackup system: $copycount copied\n\n${array[-1]}" 10 32 < <(
percent=100
cat <<EOF
XXX
$percent
\nBackup system: $copycount copied\n\n${array[-1]}
XXX
EOF
)
setterm -cursor off
sleep 2 
    
    copy_dirsource="$ADVMHOME/hi"
    copy_dirdest="$RPI2JAMMA/backup/hi"
    copy_info="Backup hiscore:"
    copy_filter="\.hi"
    copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
    copycount_tmp=$( cat /tmp/copycount )
    copycount=$(( copycount + copycount_tmp ))
    
    copy_dirsource="$ADVMHOME/nvram"
    copy_dirdest="$RPI2JAMMA/backup/nvram"
    copy_info="Backup nvram:"
    copy_filter="\.nv"
    copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
    copycount_tmp=$( cat /tmp/copycount )
    copycount=$(( copycount + copycount_tmp ))

    dialog --timeout 4 --title "pinHP Arcade Classics" --msgbox "\nBackup complete\n\nTotal files copied: $copycount" 10 32

    joy2key_stop
  fi
}

restore_advmame ()
{
  joy2key_start "yesno"
  pikeyd165_start "yesno"
  restorecount=$(find "$RPI2JAMMA/backup" -type f | wc -l)
  dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nRestore $restorecount files\nfrom 'Backup' folder\n\nOverwrite current settings?" 11 26
  response=$?
  joy2key_stop
  clear
  if [ "$response" = "0" ]; then
    joy2key_start "anykey"
    pikeyd165_start "anykey"
    if [ ! -e "$RPI2JAMMA/backup/" ]; then
      mkdir $RPI2JAMMA/backup/
    fi
    copycount=0
    unset array
    declare -a array
    if [ -e "$RPI2JAMMA/backup" ]; then

      if [ -e "$RPI2JAMMA/backup/mame_config/advmame.rc" ]; then
        cp $RPI2JAMMA/backup/mame_config/advmame.rc $ADVMHOME/
        ((copycount++))
        array+=(advmame.rc)
        read_mame_config
      fi
      if [ -e "$RPI2JAMMA/backup/mame_config/advmenu.rc" ]; then
        cp $RPI2JAMMA/backup/mame_config/advmenu.rc $ADVMHOME/
        ((copycount++))
        array+=(advmenu.rc)
      fi
      if [ -e "$RPI2JAMMA/backup/mame_config/advmess.rc" ]; then
        cp $RPI2JAMMA/backup/mame_config/advmess.rc $ADVMHOME/
        ((copycount++))
        array+=(advmess.rc)
      fi
      for (( i = 1; i <= 3; i++ ))
      do
      	if [ -e "$RPI2JAMMA/backup/mame_config/advmame.rc"_"$i"_"SCART" ]; then
          cp -r "$RPI2JAMMA/backup/mame_config/advmame.rc"_"$i"_"SCART" $ADVMHOME/
          ((copycount++))
          array+=(advmame.rc)
        fi
       	if [ -e "$RPI2JAMMA/backup/mame_config/advmame.rc"_"$i"_"Jamma" ]; then
          cp -r "$RPI2JAMMA/backup/mame_config/advmame.rc"_"$i"_"Jamma" $ADVMHOME/
          ((copycount++))
          array+=(advmame.rc)
        fi
      done
      if [ -e "$RPI2JAMMA/backup/advmame.rc" ]; then
        cp $RPI2JAMMA/backup/advmame.rc $ADVMHOME/
        ((copycount++))
        array+=(advmame.rc)
        read_mame_config
      fi
      if [ -e "$RPI2JAMMA/backup/advmenu.rc" ]; then
        cp $RPI2JAMMA/backup/advmenu.rc $ADVMHOME/
        ((copycount++))
        array+=(advmenu.rc)
      fi
      if [ -e "$RPI2JAMMA/backup/advmess.rc" ]; then
        cp $RPI2JAMMA/backup/advmess.rc $ADVMHOME/
        ((copycount++))
        array+=(advmess.rc)
      fi
      for (( i = 1; i <= 3; i++ ))
      do
      	if [ -e "$RPI2JAMMA/backup/advmame.rc"_"$i"_"SCART" ]; then
          cp -r "$RPI2JAMMA/backup/advmame.rc"_"$i"_"SCART" $ADVMHOME/
          ((copycount++))
          array+=(advmame.rc)
        fi
       	if [ -e "$RPI2JAMMA/backup/advmame.rc"_"$i"_"Jamma" ]; then
          cp -r "$RPI2JAMMA/backup/advmame.rc"_"$i"_"Jamma" $ADVMHOME/
          ((copycount++))
          array+=(advmame.rc)
        fi
      done
      if [ -e "$RPI2JAMMA/backup/netctl" ]; then
        cp -v $RPI2JAMMA/backup/netctl/* /etc/netctl 2>/dev/null | awk -F'netctl' '{print $2}' | awk -F\' '{print $1}' > /tmp/restore_copy
        restore_count_tmp=$(cat /tmp/restore_copy | wc -l)
        copycount=$(( copycount + restore_count_tmp))
        for (( i=0; i<$restore_count_tmp; ++i)); do
           array+=(netctl)
        done
      fi
      if [ -e "$RPI2JAMMA/backup/rpi2jamma" ]; then
        cp -vr $RPI2JAMMA/backup/rpi2jamma/* $RPI2JAMMA 2>/dev/null | awk -F'rpi2jamma' '{print $2}' | awk -F\' '{print $1}' > /tmp/restore_copy
        restore_count_tmp=$(cat /tmp/restore_copy | wc -l)
        copycount=$(( copycount + restore_count_tmp))
        for (( i=0; i<$restore_count_tmp; ++i)); do
           array+=(config.ini)
        done
      fi
      if [ -e "$RPI2JAMMA/backup/settings/_database.csv" ]; then
        cp $RPI2JAMMA/backup/settings/_database.csv /root/settings/
        ((copycount++))
        array+=(_database.csv)
      fi
      echo $copycount >/tmp/copycount

if [ $copycount -ne 0 ]; then

counter=0
steps=$(( 100 / copycount ))
i=0
(
# Set while loop until 100 %, simulation copy progress 
while :
do
cat <<EOF
XXX
$counter
\nRestore system: $i copied\n\n${array[$i]}
XXX
EOF
(( counter+=steps ))
[ $counter -gt 100 ] && break
((i++))
sleep 0.1
done
) |
dialog --title "pinHP Arcade Classics" --gauge "\nRestore system: $copycount copied\n\n${array[-1]}" 10 32
setterm -cursor off

# 100% dialog
dialog --title "pinHP Arcade Classics" --gauge "\nRestore system: $copycount copied\n\n${array[-1]}" 10 32 < <(
percent=100
cat <<EOF
XXX
$percent
\nRestore system: $copycount copied\n\n${array[-1]}
XXX
EOF
)
setterm -cursor off
sleep 2

fi

      if [ -e "$RPI2JAMMA/backup/hi" ]; then
        copy_dirsource="$RPI2JAMMA/backup/hi"
        copy_dirdest="$ADVMHOME/hi"
        copy_info="Restore hiscore:"
        copy_filter="\.hi"
        copy_gauge_dialog_overwrite "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
        copycount_tmp=$( cat /tmp/copycount )
        copycount=$(( copycount + copycount_tmp ))
      fi
      
      if [ -e "$RPI2JAMMA/backup/nvram" ]; then
        copy_dirsource="$RPI2JAMMA/backup/nvram"
        copy_dirdest="$ADVMHOME/nvram"
        copy_info="Restore nvram:"
        copy_filter="\.nv"
        copy_gauge_dialog_overwrite "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
        copycount_tmp=$( cat /tmp/copycount )
        copycount=$(( copycount + copycount_tmp ))
      fi
  
      dialog --timeout 4 --title "pinHP Arcade Classics" --msgbox "\nRestore complete\n\nTotal files copied: $copycount" 10 32
      sync

    fi
    joy2key_stop
    read_ll_config
    set_video_options
    [ $SYSTEMMENU = "1" ] && generate_submenu "$SCRIPTS/generate_backup_restore_menu.sh"
    cleanup_all
  fi
}

clear_hiscores ()
{
  if [ -e "$RPI2JAMMA/cleared_hiscores" ]; then
    rm -r $RPI2JAMMA/cleared_hiscores
  fi
  mkdir $RPI2JAMMA/cleared_hiscores/
  mv $ADVMHOME/hi/*.hi $RPI2JAMMA/cleared_hiscores/ &> /dev/null
  mv $ADVMHOME/nvram/*.nv $RPI2JAMMA/cleared_hiscores/ &> /dev/null
  sync
}

restore_hiscores ()
{
  if [ -e "$RPI2JAMMA/cleared_hiscores" ]; then
    mv $RPI2JAMMA/cleared_hiscores/*.hi $ADVMHOME/hi/ &> /dev/null
    mv $RPI2JAMMA/cleared_hiscores/*.nv $ADVMHOME/nvram/ &> /dev/null
    rm -r $RPI2JAMMA/cleared_hiscores
    sync
  fi
}

get_random_game ()
{
  if [ ! -z $1 ]; then
    last_random_game=$1
  fi
  max_loop=30
  count=0
  while [ "$random_game" = "$last_random_game" ] && [ $count -lt $max_loop ]
  do
    if [ "$orientation_filter" = "Y" ]; then
      ori_filter=$(echo "$ORIENTATION" | tr '[:upper:]' '[:lower:]')
      random_game=$(cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*FAV.*\"[a|$ori_filter]" | shuf -n1 | awk -F'"' '{print $2}')
    else
      random_game=$(cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*FAV.*" | shuf -n1 | awk -F'"' '{print $2}')
    fi
    (( count++ ))
  done
}

get_random_game_favgames ()
{
  if [ ! -z $1 ]; then
    last_random_game=$1
  fi
  max_loop=30
  count=0
  while [ "$random_game" = "$last_random_game" ] && [ $count -lt $max_loop ]
  do
    if [ "$orientation_filter" = "Y" ]; then
      ori_filter=$(echo "$ORIENTATION" | tr '[:upper:]' '[:lower:]')
      random_game=$(cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*1FAV.*\"[a|$ori_filter]" | shuf -n1 | awk -F'"' '{print $2}')
    else
      random_game=$(cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*1FAV.*" | shuf -n1 | awk -F'"' '{print $2}')
    fi
    (( count++ ))
  done
}

get_random_videolist ()
{
  rm /tmp/random_videolist &> /dev/null
  touch /tmp/random_videolist
  if [ "$orientation_filter" = "Y" ]; then
    ori_filter=$(echo "$ORIENTATION" | tr '[:upper:]' '[:lower:]')
    cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*FAV.*\"[a|$ori_filter]" | awk -F'"' '{print $2}' > /tmp/gamelist
  else
    cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*FAV.*" | awk -F'"' '{print $2}' > /tmp/gamelist
  fi
  awk -v INPUTFILE="/tmp/gamelist" -v COMPAREFILE="/tmp/videolist" -v OUTFILE="/tmp/random_videolist" -f "$SCRIPTS/random_videos.awk"
}

get_random_videolist_favgames ()
{
  rm /tmp/random_videolist &> /dev/null
  touch /tmp/random_videolist
  if [ "$orientation_filter" = "Y" ]; then
    ori_filter=$(echo "$ORIENTATION" | tr '[:upper:]' '[:lower:]')
    cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*1FAV.*\"[a|$ori_filter]" | awk -F'"' '{print $2}' > /tmp/gamelist
  else
    cat "/root/.lemonlauncher_common/menu_main.conf" | grep "game.*MENU.*1FAV.*" | awk -F'"' '{print $2}' > /tmp/gamelist
  fi
  awk -v INPUTFILE="/tmp/gamelist" -v COMPAREFILE="/tmp/videolist" -v OUTFILE="/tmp/random_videolist" -f "$SCRIPTS/random_videos.awk"
}

get_random_video ()
{
  last_random_video=""
  if [ ! -z $1 ]; then
    last_random_video=$1
  fi
  max_loop=30
  count=0
  random_video=$last_random_video
  while [ "$random_video" = "$last_random_video" ] && [ $count -lt $max_loop ]
  do
    random_video=$( cat "/tmp/random_videolist" | shuf -n1 )
    random_game=$( echo "$random_video" | awk -F"." '{print $1}' )
    random_video="$RPI2JAMMA/videos/$random_video"
    (( count++ ))
  done
}

screen_saver ()
{
  
  joy2key_start "anykey"
  pikeyd165_start "anykey" "0.8"
  if [ "$mail_alarm" = "Y" ]; then
    (bash "$SCRIPTS/mail_alarm.sh" "$MAIL_DIR" "$MAIL_PERMLOG" "$MAIL_TEMPLOG" &> /dev/null) &
  fi

  # For some unknown reason, the pipes script will quit immediately if run for the first time after boot.
  # Pi4 only, it is OK with Pi3.
  # Workaround: Check for Raspberry hardware, run script again if it has not run before.

  case "$screensaver_type" in

    # Straight dots
    1 )
      bash "$SCRIPTS/pipes.sh" -t0 -p2 -f20 -r1000 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipes.sh" -t0 -p2 -f20 -r1000 -R
      fi
      PIPESRUN="Y"                  
    ;;

    # Diagonal dots
    2 )
      bash "$SCRIPTS/pipesX.sh" -t0 -r500 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipesX.sh" -t0 -r500 -R
      fi                  
      PIPESRUN="Y"                  
    ;;

    # Small dots
    3 )
      bash "$SCRIPTS/pipes.sh" -t6 -p2 -f20 -r1000 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipes.sh" -t6 -p2 -f20 -r1000 -R
      fi                  
      PIPESRUN="Y"                  
    ;;

    # Line plus
    4 )
      bash "$SCRIPTS/pipes.sh" -t4 -p2 -f20 -r1000 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipes.sh" -t4 -p2 -f20 -r1000 -R
      fi                  
      PIPESRUN="Y"                  
    ;;

    # Line slash
    5 )
      bash "$SCRIPTS/pipes.sh" -t5 -p2 -f20 -r1000 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipes.sh" -t5 -p2 -f20 -r1000 -R
      fi                  
      PIPESRUN="Y"                  
    ;;

    # Dot zero
    6 )
      bash "$SCRIPTS/pipes.sh" -t7 -p2 -f20 -r1000 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipes.sh" -t7 -p2 -f20 -r1000 -R
      fi                  
      PIPESRUN="Y"                  
    ;;

    # Zebra
    7 )
      bash "$SCRIPTS/pipes.sh" -t8 -p2 -f20 -r1000 -R
      if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$PIPESRUN" != "Y" ]; then
        bash "$SCRIPTS/pipes.sh" -t8 -p2 -f20 -r1000 -R
      fi                  
      PIPESRUN="Y"                  
    ;;

    # Random game
    8 )
      joy2key_stop
      get_random_game $random_game
      cd $ADVMHOME > /dev/null
      pikeyd165_start "default"

      if [ "$screensaver_from_autostart" = "Y" ];then
        screensaver_from_autostart="N"
        # Wait for network, autostart game would exit if network connects during game
        if [ -n "$autoconnect_wifi" ]; then
    
          # Wait quietly max. 5 seconds
          secs=0
          no_internet=true
          clear
          current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
          while [ "$current_ip" = "" ];
          do
            sleep 1
            ((secs++))
            echo -n "."
            current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
            if [ "$secs" -gt "5" ]; then
              current_ip=false
            fi
          done
          clear
    
          # Wait max. 20 (default) more seconds for network
          secs=0
          no_internet=true
          clear
          current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
          if [ "$current_ip" = "" ]; then
            echo
            echo
            echo "... Waiting for network"
          fi
          while [ "$current_ip" = "" ];
          do
            sleep 1
            ((secs++))
            echo -n "."
            current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
            if [ "$secs" -gt "$AUTOSTART_GAME_NETWORK_TIMEOUT" ]; then
              current_ip=false
            fi
          done
          clear
        fi        
      fi

      rom="$random_game"

      # Custom folders
      gameline_local=$( cat "$CFGGAMES" | grep -m 1 "\"$rom"\" )
      gameline_par_local=$( echo "$gameline_local" | awk -F"\"" '{print $6}' )
      advmrom_symlink=$( readlink -f $ADVMHOME/rom )
      if [[ "$gameline_par_local" =~ .*MENUSUBDIR.* ]]; then
        subdir=$( echo "$gameline_par_local" | awk -F"$DLM" '{print $2}')
        if [ "$advmrom_symlink" != "$ROMS_ADVM/$subdir" ]; then
          ln -sfn "$ROMS_ADVM/$subdir" $ADVMHOME/rom
        fi
      else
        if [ "$advmrom_symlink" != "$ROMS_ADVM" ]; then
          ln -sfn "$ROMS_ADVM" $ADVMHOME/rom
        fi
      fi

      customscript_autostart_flag="Y"
      run_mame

      # Jump to last last played game in menu list
      if [ "$SYSTEMMENU" -ne 1 ]; then
        last_game_menu=$( grep -B 6200 -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | grep "#MENU" | tail -1 | awk -F'"' '{print $2}' )
        last_game_title=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $4}' )
        last_game_par=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $6}' )
        last_game_rom=$random_game
        hash_menu="$last_game_menu"
        hash_mark=""
        hash_title="$last_game_title"
        hash_par="$last_game_par"
        hash_rom="$last_game_rom"
        ll_hash
      fi
    ;;

    # Videos
    9 )
      joy2key_stop
      joy2key_start "noaxis"
      # List available videos
      ls "$RPI2JAMMA/videos" | grep "\.mp4" > /tmp/videolist
      video_count=$(cat /tmp/videolist | grep "\.mp4" | wc -l )
      if [ "$video_count" -lt 1 ]; then
        remain=1
        dialog --timeout 15 --begin 11 8 --title "pinHP Arcade Classics" --msgbox "\n* No video found *" 7 22
      else
        remain=0
      fi

      random_h_last=0
      random_v_last=0
      
      # Go into random video loop until video is interrupted by user (= exit screensaver)
      get_random_videolist
      if ! grep "mp4" "/tmp/random_videolist" &> /dev/null; then
        remain=1
      fi
      while [ "$remain" -le 0 ]
      do

        get_random_video $random_video
        
        # Calculate screen position, random, but not too close to position of last played video
        random_h_diff=40
        random_v_diff=30
        count=0
        while [ "$random_h_diff" -le 40 ]  && [ "$count" -lt 100 ] || [ "$random_v_diff" -le 30 ] && [ "$count" -lt 100 ]
        do

          random_h=$( shuf -i 0-200 -n1 )
          random_v=$( shuf -i 0-120 -n1 )
          random_h_diff=$(( random_h - random_h_last ))
          random_h_diff=${random_h_diff#-}
          random_v_diff=$(( random_v - random_v_last ))
          random_v_diff=${random_v_diff#-}
          (( count++ ))
        
        done
          random_h_last=$random_h
          random_v_last=$random_v
        
        x1=$(( 10 + random_h ))
        y1=$(( 10 + random_v ))
        x2=$(( 110 + random_h ))
        y2=$(( 110 + random_v ))
        
        # Get video duration
        duration=$( ffprobe -i $random_video -show_entries format=duration -v quiet -of csv="p=0" )
        duration=$( printf "%.0f\n" $duration )
        omx_ori=0
        if [ "$ORIENTATION" = "H" ]; then
          omx_ori=0
        fi
        if [ "$ORIENTATION" = "V" ]; then
          omx_ori=270
        fi
        clear
        SECONDS=0
        /usr/bin/omxplayer --win $x1,$y1,$x2,$y2 --vol $video_volume --orientation $omx_ori --key-config /root/omxkeys.ini "$random_video" &>/dev/null
        omx_offset=2
        
        # Calculate remaining video time to decide whether video was finished (= start over with next video) or stopped by user (= exit screensaver)
        remain=$(( duration - SECONDS + omx_offset ))
      done

      # Jump to last last played video game in menu list
      if [ "$SYSTEMMENU" -ne 1 ]; then
        last_game_menu=$( grep -B 6200 -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | grep "#MENU" | tail -1 | awk -F'"' '{print $2}' )
        last_game_title=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $4}' )
        last_game_par=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $6}' )
        last_game_rom=$random_game
        hash_menu="$last_game_menu"
        hash_mark=""
        hash_title="$last_game_title"
        hash_par="$last_game_par"
        hash_rom="$last_game_rom"
        ll_hash
      fi
    ;;

    # Videos (silent)
    10 )
      joy2key_stop
      joy2key_start "noaxis"
      # List available videos
      ls "$RPI2JAMMA/videos" | grep "\.mp4" > /tmp/videolist
      video_count=$(cat /tmp/videolist | grep "\.mp4" | wc -l )
      if [ "$video_count" -lt 1 ]; then
        remain=1
        dialog --timeout 15 --begin 11 8 --title "pinHP Arcade Classics" --msgbox "\n* No video found *" 7 22
      else
        remain=0
      fi

      random_h_last=0
      random_v_last=0

      # Go into random video loop until video is interrupted by user (= exit screensaver)
      get_random_videolist
      if ! grep "mp4" "/tmp/random_videolist" &> /dev/null; then
        remain=1
      fi
      while [ "$remain" -le 0 ]
      do

        get_random_video $random_vide

        # Calculate screen position, random, but not too close to position of last played video
        random_h_diff=40
        random_v_diff=30
        count=0
        while [ "$random_h_diff" -le 40 ]  && [ "$count" -lt 100 ] || [ "$random_v_diff" -le 30 ] && [ "$count" -lt 100 ]
        do

          random_h=$( shuf -i 0-200 -n1 )
          random_v=$( shuf -i 0-120 -n1 )
          random_h_diff=$(( random_h - random_h_last ))
          random_h_diff=${random_h_diff#-}
          random_v_diff=$(( random_v - random_v_last ))
          random_v_diff=${random_v_diff#-}
          (( count++ ))
        
        done
          random_h_last=$random_h
          random_v_last=$random_v
        
        x1=$(( 10 + random_h ))
        y1=$(( 10 + random_v ))
        x2=$(( 110 + random_h ))
        y2=$(( 110 + random_v ))

        # Get video duration
        duration=$( ffprobe -i $random_video -show_entries format=duration -v quiet -of csv="p=0" )
        duration=$( printf "%.0f\n" $duration )
        omx_ori=0
        if [ "$ORIENTATION" = "H" ]; then
          omx_ori=0
        fi
        if [ "$ORIENTATION" = "V" ]; then
          omx_ori=270
        fi
        clear
        SECONDS=0
        /usr/bin/omxplayer --win $x1,$y1,$x2,$y2 --vol -6000 --orientation $omx_ori --key-config /root/omxkeys.ini "$random_video" &>/dev/null
        omx_offset=2

        # Calculate remaining video time to decide whether video was finished (= start over with next video) or stopped by user (= exit screensaver)
        remain=$(( duration - SECONDS + omx_offset ))
      done

      if [ "$SYSTEMMENU" -ne 1 ]; then
        last_game_menu=$( grep -B 6200 -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | grep "#MENU" | tail -1 | awk -F'"' '{print $2}' )
        last_game_title=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $4}' )
        last_game_par=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $6}' )
        last_game_rom=$random_game
        hash_menu="$last_game_menu"
        hash_mark=""
        hash_title="$last_game_title"
        hash_par="$last_game_par"
        hash_rom="$last_game_rom"
        ll_hash
      fi
    ;;

    # Fav. Videos
    11 )
      joy2key_stop
      joy2key_start "noaxis"
      # List available videos
      ls "$RPI2JAMMA/videos" | grep "\.mp4" > /tmp/videolist
      video_count=$(cat /tmp/videolist | grep "\.mp4" | wc -l )
      if [ "$video_count" -lt 1 ]; then
        remain=1
        dialog --timeout 15 --begin 11 8 --title "pinHP Arcade Classics" --msgbox "\n* No video found *" 7 22
      else
        remain=0
      fi

      random_h_last=0
      random_v_last=0
      
      # Go into random video loop until video is interrupted by user (= exit screensaver)
      get_random_videolist_favgames
      if ! grep "mp4" "/tmp/random_videolist" &> /dev/null; then
        remain=1
      fi
      while [ "$remain" -le 0 ]
      do

        get_random_video $random_video
        
        # Calculate screen position, random, but not too close to position of last played video
        random_h_diff=40
        random_v_diff=30
        count=0
        while [ "$random_h_diff" -le 40 ]  && [ "$count" -lt 100 ] || [ "$random_v_diff" -le 30 ] && [ "$count" -lt 100 ]
        do

          random_h=$( shuf -i 0-200 -n1 )
          random_v=$( shuf -i 0-120 -n1 )
          random_h_diff=$(( random_h - random_h_last ))
          random_h_diff=${random_h_diff#-}
          random_v_diff=$(( random_v - random_v_last ))
          random_v_diff=${random_v_diff#-}
          (( count++ ))
        
        done
          random_h_last=$random_h
          random_v_last=$random_v
        
        x1=$(( 10 + random_h ))
        y1=$(( 10 + random_v ))
        x2=$(( 110 + random_h ))
        y2=$(( 110 + random_v ))
        
        # Get video duration
        duration=$( ffprobe -i $random_video -show_entries format=duration -v quiet -of csv="p=0" )
        duration=$( printf "%.0f\n" $duration )
        omx_ori=0
        if [ "$ORIENTATION" = "H" ]; then
          omx_ori=0
        fi
        if [ "$ORIENTATION" = "V" ]; then
          omx_ori=270
        fi
        clear
        SECONDS=0
        /usr/bin/omxplayer --win $x1,$y1,$x2,$y2 --vol $video_volume --orientation $omx_ori --key-config /root/omxkeys.ini "$random_video" &>/dev/null
        omx_offset=2
        
        # Calculate remaining video time to decide whether video was finished (= start over with next video) or stopped by user (= exit screensaver)
        remain=$(( duration - SECONDS + omx_offset ))
      done

      # Jump to last last played video game in menu list
      if [ "$SYSTEMMENU" -ne 1 ]; then
        last_game_menu=$( grep -B 6200 -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | grep "#MENU" | tail -1 | awk -F'"' '{print $2}' )
        last_game_title=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $4}' )
        last_game_par=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $6}' )
        last_game_rom=$random_game
        hash_menu="$last_game_menu"
        hash_mark=""
        hash_title="$last_game_title"
        hash_par="$last_game_par"
        hash_rom="$last_game_rom"
        ll_hash
      fi
    ;;

    # Fav. Videos (silent)
    12 )
      joy2key_stop
      joy2key_start "noaxis"
      # List available videos
      ls "$RPI2JAMMA/videos" | grep "\.mp4" > /tmp/videolist
      video_count=$(cat /tmp/videolist | grep "\.mp4" | wc -l )
      if [ "$video_count" -lt 1 ]; then
        remain=1
        dialog --timeout 15 --begin 11 8 --title "pinHP Arcade Classics" --msgbox "\n* No video found *" 7 22
      else
        remain=0
      fi

      random_h_last=0
      random_v_last=0

      # Go into random video loop until video is interrupted by user (= exit screensaver)
      get_random_videolist_favgames
      if ! grep "mp4" "/tmp/random_videolist" &> /dev/null; then
        remain=1
      fi
      while [ "$remain" -le 0 ]
      do

        get_random_video $random_vide

        # Calculate screen position, random, but not too close to position of last played video
        random_h_diff=40
        random_v_diff=30
        count=0
        while [ "$random_h_diff" -le 40 ]  && [ "$count" -lt 100 ] || [ "$random_v_diff" -le 30 ] && [ "$count" -lt 100 ]
        do

          random_h=$( shuf -i 0-200 -n1 )
          random_v=$( shuf -i 0-120 -n1 )
          random_h_diff=$(( random_h - random_h_last ))
          random_h_diff=${random_h_diff#-}
          random_v_diff=$(( random_v - random_v_last ))
          random_v_diff=${random_v_diff#-}
          (( count++ ))
        
        done
          random_h_last=$random_h
          random_v_last=$random_v
        
        x1=$(( 10 + random_h ))
        y1=$(( 10 + random_v ))
        x2=$(( 110 + random_h ))
        y2=$(( 110 + random_v ))

        # Get video duration
        duration=$( ffprobe -i $random_video -show_entries format=duration -v quiet -of csv="p=0" )
        duration=$( printf "%.0f\n" $duration )
        omx_ori=0
        if [ "$ORIENTATION" = "H" ]; then
          omx_ori=0
        fi
        if [ "$ORIENTATION" = "V" ]; then
          omx_ori=270
        fi
        clear
        SECONDS=0
        /usr/bin/omxplayer --win $x1,$y1,$x2,$y2 --vol -6000 --orientation $omx_ori --key-config /root/omxkeys.ini "$random_video" &>/dev/null
        omx_offset=2

        # Calculate remaining video time to decide whether video was finished (= start over with next video) or stopped by user (= exit screensaver)
        remain=$(( duration - SECONDS + omx_offset ))
      done

      if [ "$SYSTEMMENU" -ne 1 ]; then
        last_game_menu=$( grep -B 6200 -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | grep "#MENU" | tail -1 | awk -F'"' '{print $2}' )
        last_game_title=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $4}' )
        last_game_par=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $6}' )
        last_game_rom=$random_game
        hash_menu="$last_game_menu"
        hash_mark=""
        hash_title="$last_game_title"
        hash_par="$last_game_par"
        hash_rom="$last_game_rom"
        ll_hash
      fi
    ;;

    # Random fav. game
    13 )
      joy2key_stop
      get_random_game_favgames $random_game
      cd $ADVMHOME > /dev/null
      pikeyd165_start "default"

      if [ "$screensaver_from_autostart" = "Y" ];then
        screensaver_from_autostart="N"
        # Wait for network, autostart game would exit if network connects during game
        if [ -n "$autoconnect_wifi" ]; then
    
          # Wait quietly max. 5 seconds
          secs=0
          no_internet=true
          clear
          current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
          while [ "$current_ip" = "" ];
          do
            sleep 1
            ((secs++))
            echo -n "."
            current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
            if [ "$secs" -gt "5" ]; then
              current_ip=false
            fi
          done
          clear
    
          # Wait max. 20 (default) more seconds for network
          secs=0
          no_internet=true
          clear
          current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
          if [ "$current_ip" = "" ]; then
            echo
            echo
            echo "... Waiting for network"
          fi
          while [ "$current_ip" = "" ];
          do
            sleep 1
            ((secs++))
            echo -n "."
            current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
            if [ "$secs" -gt "$AUTOSTART_GAME_NETWORK_TIMEOUT" ]; then
              current_ip=false
            fi
          done
          clear
        fi        
      fi

      rom="$random_game"

      # Custom folders
      gameline_local=$( cat "$CFGGAMES" | grep -m 1 "\"$rom"\" )
      gameline_par_local=$( echo "$gameline_local" | awk -F"\"" '{print $6}' )
      advmrom_symlink=$( readlink -f $ADVMHOME/rom )
      if [[ "$gameline_par_local" =~ .*MENUSUBDIR.* ]]; then
        subdir=$( echo "$gameline_par_local" | awk -F"$DLM" '{print $2}')
        if [ "$advmrom_symlink" != "$ROMS_ADVM/$subdir" ]; then
          ln -sfn "$ROMS_ADVM/$subdir" $ADVMHOME/rom
        fi
      else
        if [ "$advmrom_symlink" != "$ROMS_ADVM" ]; then
          ln -sfn "$ROMS_ADVM" $ADVMHOME/rom
        fi
      fi

      customscript_autostart_flag="Y"
      run_mame

      # Jump to last last played game in menu list
      if [ "$SYSTEMMENU" -ne 1 ]; then
        last_game_menu=$( grep -B 6200 -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | grep "#MENU" | tail -1 | awk -F'"' '{print $2}' )
        last_game_title=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $4}' )
        last_game_par=$( grep -m 1 \"$random_game\" /root/.lemonlauncher_common/menu_main.conf | awk -F'"' '{print $6}' )
        last_game_rom=$random_game
        hash_menu="$last_game_menu"
        hash_mark=""
        hash_title="$last_game_title"
        hash_par="$last_game_par"
        hash_rom="$last_game_rom"
        ll_hash
      fi
    ;;

  esac

  setterm -cursor off
  if [ "$servostik" = "Y" ]; then
    rm "/tmp/servostik_state" &> /dev/null
    bash "$SCRIPTS/switch_servostik.sh" "" "4" &> /dev/null
  fi
  if [ "$mail_alarm" = "Y" ]; then
    kill $(jobs -p) &> /dev/null
  fi
  joy2key_stop
}

no_autostart_markers ()
{
  autostart_rom=""
  
  # Set back splash, if previously disabled for autostart game
  if [ ! -e $DEFAULT/splash.mp4 ]; then
    mv $DEFAULT/_splash.mp4 $DEFAULT/splash.mp4 &> /dev/null
  fi
  sed -i -e "s/title =\".*$TEXT_AUTOSTART_GAME\"/title =\"$TEXT_SELECT_AUTOSTART_GAME\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_AUTOSTART_LAST_GAME\"/title =\"$TEXT_AUTOSTART_LAST_GAME\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_AUTOSTART:[^\"]*\"/title =\"$TEXT_SELECT_AUTOSTART_GAME\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_BOOT_INTO_SCREENSAVER/title =\"$TEXT_BOOT_INTO_SCREENSAVER/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_NO_AUTOSTART/title =\"$TEXT_NO_AUTOSTART/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_AUTOSTART_ADVMENU/title =\"$TEXT_AUTOSTART_ADVMENU/" $CFGSETTINGS
  sync
}

no_game_menu_markers ()
{
  # There are 4 characters considered special in the replacement part of the sed s command, which need to be escaped:
  # \, &, newline and the delimiter (usually / but can actually be anything).
  menu_list="
  TEXT_1_LINE_GAME_MENU
  TEXT_2_LINE_GAME_MENU
  TEXT_3_LINE_GAME_MENU
  TEXT_FAV_GAMES_MENU_ONLY
  TEXT_FAV_AND_SECOND_MENU_ONLY
  "
  for menu_item in $menu_list
    do
      ESCAPED_TEXT=$(sed -e 's/[&\\/]/\\&/g; s/$/\\/' -e '$s/\\$//' <<<"${!menu_item}")
      sed -i -e "s/title =\".*$ESCAPED_TEXT\"/title =\" $ESCAPED_TEXT\"/" $CFGSETTINGS
    done
  sync
}

clear_gameselect_flags ()
{
  favmenu_select_flag=0
  favmenu_deselect_flag=0
  secondmenu_select_flag=0
  secondmenu_deselect_flag=0
  autostart_game_flag=0
  set_4_8_way_flag=0
  if [ "$show_deleted_games" = "Y" ]; then
    show_deleted_games="N"
    quickedit_changed=1
  fi

  sed -i '/pinHP_mark/s/\scolor =.*#pinHP_mark//' /root/.lemonlauncherH/theme.conf
  sed -i '/pinHP_mark/s/\scolor =.*#pinHP_mark//' /root/.lemonlauncherV/theme.conf
  if [ "$preview_marquees" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/marquees" /root/.lemonlauncher_common/lemonmarquees
  fi
  if [ "$preview_logos" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/logos" /root/.lemonlauncher_common/lemonlogos
  fi
  ln -sf "/root/.lemonlauncherH/bg/backgroundH.png" /root/.lemonlauncherH/background.png
  ln -sf "/root/.lemonlauncherV/bg/backgroundV.png" /root/.lemonlauncherV/background.png
  sed -i -e "s/title =\".*$TEXT_SELECT_FAV_GAMES\"/title =\"$TEXT_SELECT_FAV_GAMES\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_DESELECT_FAV_GAMES\"/title =\"$TEXT_DESELECT_FAV_GAMES\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_SELECT_2ND_MENU_GAMES\"/title =\"$TEXT_SELECT_2ND_MENU_GAMES\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_DESELECT_2ND_MENU_GAMES\"/title =\"$TEXT_DESELECT_2ND_MENU_GAMES\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_AUTOSTART_GAME\"/title =\"$TEXT_SELECT_AUTOSTART_GAME\"/" $CFGSETTINGS
  sed -i -e "s/title =\".*$TEXT_SET_4_8_WAY_GAMES\"/title =\"$TEXT_SET_4_8_WAY_GAMES\"/" $CFGSETTINGS
  sed -i -e '/game.*quickeditmode.*}/d' $CFGGAMES
  quickedit_menu_markers="N"
  if [ "$quickedit_changed" = "1" ]; then
    generate_game_menu
    quickedit_changed=0
  fi
  sync
}

get_uptime ()
{
  uptime=$(cat /proc/uptime | awk -F. '{print $1}')
  up_d=$((uptime/60/60/24))
  up_h=$((uptime/60/60%24))
  up_m=$((uptime/60%60))
  up_s=$((uptime%60))
  up_m=$(printf %02d $up_m)
  up_s=$(printf %02d $up_s)
  if [ $up_d -gt 0 ]; then
    up_h=$(printf %02d $up_h)
    uptime="$up_d d $up_h h $up_m min"
  elif [ $up_h -gt 0 ]; then
    uptime="$up_h h $up_m min"
  else
    uptime="$up_m min $up_s s"
  fi
  sed -i -e "s/title =\".*$TEXT_UPTIME.*\" params/title =\"$TEXT_UPTIME$uptime\" params/" $CFGGAMES
}

menu_mark_quickedit ()
{
  quickedit_menu_markers="Y"
  if ! grep -q quickeditmode "$CFGGAMES"; then
    if [ "$custom_folders" != "Y" ] || [ "$favmenu_select_flag" = "1" ] || [ "$favmenu_deselect_flag" = "1" ] || [ "$set_4_8_way_flag" = "1" ]; then

      if [ "$favmenu_select_flag" != "1" ] || [ "$game_menu_dirs" = "1" ]; then
        if [ "$set_4_8_way_flag" = "1" ]; then
          line_code_1="  game { rom =\"quickeditmode\" title =\"   $TEXT_SET_4_8_WAY_GAMES   \" params =\"-MENU1-ID00\" orientation =\"a\" }"
        else
          line_code_1="  game { rom =\"quickeditmode\" title =\"       \" params =\"-MENU1-ID00\" orientation =\"a\" }"
        fi
        line_code_2="  game { rom =\"quickeditmode\" title =\"  ---  \" params =\"-MENU1-ID01\" orientation =\"a\" }"
        line_code_3="  game { rom =\"quickeditmode_menu1\" title =\" \#\#\# $TEXT_APPLY_CHANGES \#\#\# \" params =\"quickedit_apply\" orientation =\"a\" }"
        line_code_4="  game { rom =\"quickeditmode\" title =\" --- \" params =\"-MENU1-ID02\" orientation =\"a\" }"
        line_code="$line_code_1\n$line_code_2\n$line_code_3\n$line_code_4"
        line_number=$(cat $CFGGAMES | grep -n --max-count=1 "\-MENU1" | grep -o '^[0-9]*')
        if [ -n "$line_number" ] && [ "$line_number" -eq "$line_number" ]; then
          sed -i "$line_number i\
          $line_code" $CFGGAMES
        fi
      fi
  
      if [ "$secondmenu_select_flag" != "1" ]; then
        if [ "$set_4_8_way_flag" = "1" ]; then
          line_code_1="  game { rom =\"quickeditmode\" title =\"   $TEXT_SET_4_8_WAY_GAMES   \" params =\"-MENU2-ID00\" orientation =\"a\" }"
        else
          line_code_1="  game { rom =\"quickeditmode\" title =\"       \" params =\"-MENU2-ID00\" orientation =\"a\" }"
        fi
        line_code_2="  game { rom =\"quickeditmode\" title =\"  ---  \" params =\"-MENU2-ID01\" orientation =\"a\" }"
        line_code_3="  game { rom =\"quickeditmode_menu2\" title =\" \#\#\# $TEXT_APPLY_CHANGES \#\#\# \" params =\"quickedit_apply\" orientation =\"a\" }"
        line_code_4="  game { rom =\"quickeditmode\" title =\" --- \" params =\"-MENU2-ID02\" orientation =\"a\" }"
        line_code="$line_code_1\n$line_code_2\n$line_code_3\n$line_code_4"
        line_number=$(cat $CFGGAMES | grep -n --max-count=1 "\-MENU2" | grep -o '^[0-9]*')
        if [ -n "$line_number" ] && [ "$line_number" -eq "$line_number" ]; then
          sed -i "$line_number i\
          $line_code" $CFGGAMES
        fi
      fi
  
      if [ "$set_4_8_way_flag" = "1" ]; then
        line_code_1="  game { rom =\"quickeditmode\" title =\"   $TEXT_SET_4_8_WAY_GAMES   \" params =\"-MENU3-ID00\" orientation =\"a\" }"
      else
        line_code_1="  game { rom =\"quickeditmode\" title =\"       \" params =\"-MENU3-ID00\" orientation =\"a\" }"
      fi
      line_code_2="  game { rom =\"quickeditmode\" title =\"  ---  \" params =\"-MENU3-ID01\" orientation =\"a\" }"
      line_code_3="  game { rom =\"quickeditmode_menu3\" title =\" \#\#\# $TEXT_APPLY_CHANGES \#\#\# \" params =\"quickedit_apply\" orientation =\"a\" }"
      line_code_4="  game { rom =\"quickeditmode\" title =\" --- \" params =\"-MENU3-ID02\" orientation =\"a\" }"
      line_code="$line_code_1\n$line_code_2\n$line_code_3\n$line_code_4"
      line_number=$(cat $CFGGAMES | grep -n --max-count=1 "\-MENU3" | grep -o '^[0-9]*')
      if [ -n "$line_number" ] && [ "$line_number" -eq "$line_number" ]; then
        sed -i "$line_number i\
        $line_code" $CFGGAMES
      fi

    fi

    if [ "$custom_folders" = "Y" ] || [ "$game_menu_dirs" = "7" ]; then
      menu_dirlist=$( cat $CFGGAMES | grep "{ #MENU_" | awk -F"MENU_" '{print $2}' )
      OIFS="$IFS"
      IFS=$'\n'
      for name in $menu_dirlist
      do
        if [ "$set_4_8_way_flag" = "1" ]; then
          line_code_1="  game { rom =\"quickeditmode\" title =\"   $TEXT_SET_4_8_WAY_GAMES   \" params =\"-MENU$DLM$name$DLM-ID00\" orientation =\"a\" }"
        else
          line_code_1="  game { rom =\"quickeditmode\" title =\"       \" params =\"-MENU$DLM$name$DLM-ID00\" orientation =\"a\" }"
        fi
        line_code_2="  game { rom =\"quickeditmode\" title =\"  ---  \" params =\"-MENU$DLM$name$DLM-ID01\" orientation =\"a\" }"
        line_code_3="  game { rom =\"quickeditmode_menusubdir\" title =\" \#\#\# $TEXT_APPLY_CHANGES \#\#\# \" params =\"quickedit_apply\" orientation =\"a\" }"
        line_code_4="  game { rom =\"quickeditmode\" title =\" --- \" params =\"-MENU$DLM$name$DLM-ID02\" orientation =\"a\" }"
        line_code="$line_code_1\n$line_code_2\n$line_code_3\n$line_code_4"
        line_number=$(cat $CFGGAMES | grep -n --max-count=1 "params.=.*SUBDIR$DLM$name$DLM" | grep -o '^[0-9]*')
        if [ -n "$line_number" ] && [ "$line_number" -eq "$line_number" ]; then
          sed -i "$line_number i\
          $line_code" $CFGGAMES
        fi
      done
      IFS="$OIFS"
    fi

    sed -i '/id01.*hiddenfeatures/s/title =" " params ="hiddenfeatures"/title ="# '"$TEXT_BACK_TO_MAIN_MENU"' #" params ="quickedit_apply"/' $CFGGAMES

  fi
}

ll_hash ()
{
  # Echo text | convert to hex to allow non-ASCII text in jenkinshash python script | strip whitespace from output
  hash_menu_hex=$( echo -n "$hash_menu" | od -A n -t x1 | sed 's/ *//g' )
  hash_title_hex=$( echo -n "$hash_title" | od -A n -t x1 | sed 's/ *//g' )
  python3 "$SCRIPTS/ll_jenkinshash.py" "$hash_menu_hex" "$hash_mark" "$hash_title_hex" "$hash_par" "$hash_rom"
  mv /tmp/ll_hash_tmp.txt /tmp/ll_rememberlastselection_tmp_file.txt
}

hash_boot_game ()
{
  boot_game=$( cat $CFGGAMES | grep "game { rom.*-MENU1" | awk -F'"' '{print $4}' | sort | sed -n 1p )
  boot_gameline=$( cat $CFGGAMES | grep -m 1 "$boot_game" )
  hash_menu=$( cat $CFGGAMES | grep "{ #MENU1" | awk -F'"' '{print $2}' )
  hash_mark=""
  hash_title=$( echo "$boot_gameline" | awk -F'"' '{print $4}' )
  hash_par=$( echo "$boot_gameline" | awk -F'"' '{print $6}' )
  hash_rom=$( echo "$boot_gameline" | awk -F'"' '{print $2}' )
  ll_hash
}

install_patch ()
{
PATCHDIR="$RPI2JAMMA"

if [ -d "$PATCHDIR" ]; then
  cd "$PATCHDIR"
  PATCHLIST=$(ls | grep patch_pinhp | grep -v _done | grep -v _notinstalled )
  for file in $PATCHLIST
    do
      clear
      if [ $PATCHREBOOT -eq 1 ]; then
        response=0
      else
        pikeyd165_start "yesno"
        joy2key_start "yesno"
        dialog --timeout 15 --begin 9 5 --title "pinHP Arcade Classics" --defaultno --yesno "\nApply system patch?\n\n$file" 10 30
        response=$?
        joy2key_stop
        clear
      fi

      if [ "$response" -eq 0 ]; then
        
        # Check for patch info file
        if tar -tzvf $PATCHDIR/$file --warning=no-timestamp | grep -o "patch_info.txt"; then
          ( cd / ; tar -xzvf $PATCHDIR/$file tmp/patch_info.txt --warning=no-timestamp )
          patch_minversion=$(grep "patch_minversion" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -o "[0-9]\+")
        else
          patch_minversion=0
        fi
        clear

        # Does patch require a greater running version?
        if [ "$patch_minversion" -gt "$VERSION" ]; then
          pikeyd165_start "anykey"
          joy2key_start "anykey"
          dialog --timeout 15 --begin 10 6 --title "pinHP Arcade Classics" --msgbox "\nUpdate available, but not\n\ncompatible with this version." 10 29
          joy2key_stop
          mv $file "$file"_notinstalled
        
        # Ok, install patch
        else   
          echo
          echo "... Applying patch"
          echo "    "$file
          echo
          sleep 3
          ( cd / ; tar -xzvf $PATCHDIR/$file --warning=no-timestamp )
          if tar -tzvf $PATCHDIR/$file --warning=no-timestamp | grep -o "autostart.sh"; then
            PATCHREBOOT=1
          fi
          if tar -tzvf $PATCHDIR/$file --warning=no-timestamp | grep -o "patchscript.sh"; then
            ( cd /root ; bash patchscript.sh ; rm patchscript.sh )
          fi
          pwd
          mv $file "$file"_done
          echo
          sleep 1
          if [ "$PATCHREBOOT" = "1" ]; then
            reboot_system
          fi
          sync
        fi
      elif [ "$response" = "1" ]; then
        mv $file "$file"_notinstalled
      fi

    done
fi
}

dialog_no_network ()
{
  pikeyd165_start "yesno" "0.5"
  joy2key_start "anykey"
  dialog --timeout 15 --begin 11 8 --title "pinHP Arcade Classics" --msgbox "\n* No network *" 7 22
  joy2key_stop
}

dialog_current_ip ()
{
  pikeyd165_start "yesno" "0.5"
  joy2key_start "anykey"
  dialog --timeout 30 --begin 10 6 --title "pinHP Arcade Classics" --msgbox "\nIP address:\n\n$current_ip" 10 27
  joy2key_stop
}

get_active_wifi_profile ()
{
  active_wifi_profile_tmp=$( netctl list | grep "*" | awk -F '* ' '{print $2}' ) &> /dev/null
  if [ -n "$active_wifi_profile_tmp" ]; then
    active_wifi_profile=$active_wifi_profile_tmp
    if ! grep -q "$active_wifi_profile" "$DEFAULT/last_wifi_profile" &> /dev/null; then
      echo "$active_wifi_profile" > "$DEFAULT/last_wifi_profile"
    fi
  else
    active_wifi_profile="n/a"
  fi
}

get_last_wifi_profile ()
{
  last_wifi_profile_tmp=""
  if [ -e "$DEFAULT/last_wifi_profile" ]; then
    last_wifi_profile_tmp=$( cat "$DEFAULT/last_wifi_profile" )
  fi
  if [ -n "$last_wifi_profile_tmp" ]; then
    last_wifi_profile=$last_wifi_profile_tmp
  else
    last_wifi_profile="n/a"
  fi
}

check_hardwaremode ()
{
  case $pi2scartmode_current in
    Y )
      hardwaremode_current="SCART"
    ;;
    N )
      hardwaremode_current="Jamma"
    ;;
  esac

  saved_pi2scart_mode=$(cat $CONFIGFILE | grep -v "#" | grep -m 1 pi2scart_mode= | awk -F= '{print $2}' | grep -o "[YNA]")
  case $saved_pi2scart_mode in
    A )
      hardwaremode_saved="Auto"
    ;;
    Y )
      hardwaremode_saved="SCART"
    ;;
    N )
      hardwaremode_saved="Jamma"
    ;;
  esac

  pikeyd165_start "yesno" "0.5"
  joy2key_start "yesno"

  if [ "$hardwaremode_current" = "SCART" ]; then
    dialog --timeout 10 --begin 9 2 --title "pinHP Arcade Classics" --yesno "\n*Current* hardware mode: $hardwaremode_current\n\nSaved hardware mode:   $hardwaremode_saved\n\nDo you want to change the\n*current* (running) mode?\n\n"  0 0
    response=$?
  else    
    dialog --timeout 10 --begin 9 2 --title "pinHP Arcade Classics" --defaultno --yesno "\n*Current* hardware mode: $hardwaremode_current\n\nSaved hardware mode:   $hardwaremode_saved\n\nDo you want to change the\n*current* (running) mode?\n\n"  0 0
    response=$?
  fi

  if [ "$response" != "1" ]; then

    case $pi2scartmode_current in
      Y )
        dialog --timeout 1 --title "pinHP Arcade Classics" --msgbox "\nSwitching ...\n\n"  0 0
        unset pikeyd_current
        if [ "$PI2SCART_MODE_DETECTED" = "N" ]; then
          pi2scartmode_current=$PI2SCART_MODE_DETECTED
          hardwaremode_current="Jamma"
          unset pikeyd_current
          pikeyd165_start "yesno" "0.5"
          mode_changed=Y
        else
          hardwaremode_current="SCART"
          dialog --timeout 10 --begin 6 6 --title "pinHP Arcade Classics" --msgbox "\nJAMMA NOT POSSIBLE\n\nIf required, edit\n\n 'rpi2jamma/config.ini'\n\nand set\n\n 'pi2scart_mode=N'\n\nfor Jamma hardware mode.\n\n" 0 0
          pikeyd165_stop
          mode_changed=N
        fi
      ;;
      N )
        pi2scartmode_current="Y"
        hardwaremode_current="SCART"
        pikeyd165_stop
        mode_changed=Y
      ;;
    esac

    if [ "$mode_changed" = "Y" ]; then
      dialog --timeout 10 --begin 9 2 --title "pinHP Arcade Classics" --defaultno --no-label "Undo" --yesno "\nCurrent hardware mode: $hardwaremode_current\n\nAre you sure?\n\n"  0 0
      response=$?
      if [ "$response" != "0" ]; then
  
        case $pi2scartmode_current in
          Y )
            dialog --timeout 1 --title "pinHP Arcade Classics" --msgbox "\nSwitching back...\n\n"  0 0
            unset pikeyd_current
            if [ "$PI2SCART_MODE_DETECTED" = "N" ]; then
              pi2scartmode_current=$PI2SCART_MODE_DETECTED
              hardwaremode_current="Jamma"
              unset pikeyd_current
              pikeyd165_start "yesno" "0.5"
            else
              hardwaremode_current="SCART"
              dialog --timeout 10 --begin 6 6 --title "pinHP Arcade Classics" --msgbox "\nJAMMA NOT POSSIBLE\n\nIf required, edit\n\n 'rpi2jamma/config.ini'\n\nand set\n\n 'pi2scart_mode=N'\n\nfor Jamma hardware mode.\n\n" 0 0
              pikeyd165_stop
            fi
          ;;
          N )
            pi2scartmode_current="Y"
            hardwaremode_current="SCART"
            pikeyd165_stop
          ;;
        esac
  
      fi
    fi
  fi

  if [ "$pi2scartmode_current" != "$saved_pi2scart_mode" ]; then
    sleep 0.5
    dialog --timeout 15 --begin 7 3 --title "pinHP Arcade Classics" --defaultno --yesno "\nSAVE HARDWARE MODE\n\nCurrent hardware mode: $hardwaremode_current\n\nSaved hardware mode:   $hardwaremode_saved\n\nDo you want to permanently\nsave current $hardwaremode_current mode?\n\n(Recommended: Yes)\n\n"  0 0
    response=$?
    if [ "$response" = "0" ]; then
      sed -i -e "s/pi2scart_mode=./pi2scart_mode=$pi2scartmode_current/" "$CONFIGFILE"
    fi
  fi

  joy2key_stop
  if [ "$SYSTEMMENU" = "1" ]; then
    check_pi2scart
    hash_menu="$TEXT_CONTROL_SETTINGS"
    hash_mark="B7"
    hash_title="${TEXT_HARDWARE_MODE}Pi2${hardwaremode_current}"
    hash_par="$par"
    hash_rom="pinhp"
    ll_hash
    generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
  fi
}

checksum_compare ()
{
  # Scan advmame rom dir
  ls -RA $ROMS_ADVM | grep -v "_md5sum" > $ROMLIST
  MD5SUMADVM=$(md5sum $ROMLIST | awk '{print $1}')
  MD5SUMCONFIG=$(md5sum $CONFIGFILE | awk '{print $1}')
  MD5SUMTEMPLATE=$(md5sum $TEMPLATEFILE | awk '{print $1}')
  MD5SUMLANGUAGE=$(md5sum $LANGUAGEFILE | awk '{print $1}')

  # Has something changed in the rom directory?
  # Yes -> Set GENERATFLAG=1 to force game menu generation and save new MD5 file
    
  if [[ $(cat $ROMS_ADVM/_md5sum_) != $MD5SUMADVM ]] &> /dev/null; then
    GENERATFLAG=1
    echo $MD5SUMADVM > $ROMS_ADVM/_md5sum_
    sync
  fi
  
  if [[ $(cat $ROMS_ADVM/_md5sum_config_) != $MD5SUMCONFIG ]] &> /dev/null; then
    GENERATFLAG=1
    echo $MD5SUMCONFIG > $ROMS_ADVM/_md5sum_config_
    if [ "$video_delay" = "0" ]; then
      sed -i -e "s/.*#pinHP#.*/# sleep 0 #pinHP#/" /usr/bin/omxplayer
    else
      sed -i -e "s/.*#pinHP#.*/sleep $video_delay #pinHP#/" /usr/bin/omxplayer
    fi
    sync
  fi
  
  if [[ $(cat $ROMS_ADVM/_md5sum_template_) != $MD5SUMTEMPLATE ]] &> /dev/null; then
    GENERATFLAG=1
    echo $MD5SUMTEMPLATE > $ROMS_ADVM/_md5sum_template_
    sync
  fi

  if [[ $(cat $ROMS_ADVM/_md5sum_language_) != $MD5SUMLANGUAGE ]] &> /dev/null; then
    GENERATFLAG=1
    echo $MD5SUMLANGUAGE > $ROMS_ADVM/_md5sum_language_
    sync
  fi

  rm $ROMLIST

}

exit_systemmenu ()
{
  ln -sf $CFGGAMES /root/.lemonlauncherH/games.conf
  ln -sf $CFGGAMES /root/.lemonlauncherV/games.conf
  if [ "$preview_images" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/snaps" /root/.lemonlauncher_common/lemonsnaps
  else
    ln -sfn "/root/rpi2jamma/systemsnaps" /root/.lemonlauncher_common/lemonsnaps
  fi

  for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
  do
    ln -sf "/root/.lemonlauncherH/bg$theme/theme_main.conf" "/root/.lemonlauncherH/bg$theme/theme.conf"
    ln -sf "/root/.lemonlauncherV/bg$theme/theme_main.conf" "/root/.lemonlauncherV/bg$theme/theme.conf"
  done

  ln -sf "/root/.lemonlauncherH/bg/backgroundH.png" /root/.lemonlauncherH/background.png
  ln -sf "/root/.lemonlauncherV/bg/backgroundV.png" /root/.lemonlauncherV/background.png
  ln -sf "/root/.lemonlauncherH/bg/theme.conf" /root/.lemonlauncherH/theme.conf
  ln -sf "/root/.lemonlauncherV/bg/theme.conf" /root/.lemonlauncherV/theme.conf
  if [ "$preview_logos" = "Y" ]; then
    if [ "$ORIENTATION" != "H" ] || [ "$screen_theme" != "2" ]; then
      preview_marquees="N"
      sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_MARQUEES/title =\"$TEXT_GAME_PREVIEW_MARQUEES/" $CFGSYSTEM
      ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
    fi
  fi
  checksum_compare
  if [ "$GENERATFLAG" = "1" ] || [ "$quickedit_changed" = "1" ]; then
    generate_game_menu
    get_active_wifi_profile
    quickedit_changed=0
  fi
  get_active_wifi_profile
  sed -i '/pinHP_mark/s/\scolor =.*#pinHP_mark//' /root/.lemonlauncherH/theme.conf
  sed -i '/pinHP_mark/s/\scolor =.*#pinHP_mark//' /root/.lemonlauncherV/theme.conf
  SYSTEMMENU=0
  pikeyd165_start "force"
}

escape_menu_titles ()
{
  # Escape double quotes
  # for text variables customaizable via "Language Settings", in case a user enters double qoutes
  menu_list="
  single_menu_title
  menu_title_1_of_2
  menu_title_2_of_2
  menu_title_1_of_3
  menu_title_2_of_3
  menu_title_3_of_3
  menu_options
  menu_back
  menu_screensaver
  menu_reboot
  menu_shutdown
  menu_backup
  menu_restore
  menu_about
  "
  for menu_item in $menu_list
    do
      ESCAPED_TEXT=$(sed -e 's/"/\\"/g;' <<<"${!menu_item}")
      declare -g "escaped_$menu_item=$ESCAPED_TEXT"
    done
}

dialog_convert_utf8 ()
{
  # Convert from ISO8859-1 to UTF-8 and back, to be able to read and enter special characters (e. g. Umlauts) in dialog box
  # Lemonlauncher cannot handle UTF-8

  input=""
  echo "$1" > /tmp/menu_text.ISO8859
  iconv -c -f ISO8859-1 -t UTF-8 /tmp/menu_text.ISO8859 > /tmp/menu_text.UTF8
  menu_text_UTF8=$(cat /tmp/menu_text.UTF8)
  setterm -cursor on
  LANG=en_DK.UTF-8
  pikeyd165_start "yesno"
  joy2key_start "yesno"
  input_UTF8=$(dialog --inputbox "Enter menu text" 0 30 "$menu_text_UTF8" 3>&1 1>&2 2>&3)
  joy2key_stop
  LANG=C
  setterm -cursor off
  echo "$input_UTF8" > /tmp/input.UTF8
  iconv -c -f UTF-8 -t ISO8859-1 /tmp/input.UTF8 > /tmp/input.ISO8859
  input=$(cat /tmp/input.ISO8859)
}

get_human_readable_time ()
{
  hrt=$1
  hrt_d=$((hrt/60/60/24))
  hrt_h=$((hrt/60/60%24))
  hrt_m=$((hrt/60%60))
  hrt_s=$((hrt%60))
  hrt_m=$(printf %02d $hrt_m)
  hrt_s=$(printf %02d $hrt_s)
  if [ $hrt_d -gt 0 ]; then
    hrt_h=$(printf %02d $hrt_h)
    hrt="$hrt_d d $hrt_h h $hrt_m min"
  elif [ $hrt_h -gt 0 ]; then
    hrt="$hrt_h h $hrt_m min"
  else
    hrt="$hrt_m min $hrt_s s"
  fi
}

copy_gauge_dialog ()
{
copy_dirsource=$1
copy_dirdest=$2
copy_info=$3
copy_filter=$4

if [ -z "$copy_filter" ]; then
  copyfilter=".*"
fi
mkdir "$copy_dirdest" &> /dev/null
filecount=$( ls $copy_dirsource | grep $copy_filter | wc -l )
file="..."
lastfile=$file
ls $copy_dirsource | grep $copy_filter >/tmp/sourcelist
dialog --title "pinHP Arcade Classics" --gauge "\n$copy_info $file\n\nCopied: 0 / $filecount" 10 32 < <(
copycount_local=0
echo $copycount_local /tmp/copycount

i=0
while read file
do
# calculate progress
percent=$(( 100*(++i)/filecount ))

# If file exists, skip copy
if [ ! -e "$copy_dirdest/$file" ]; then
cp -n "$copy_dirsource/$file" "$copy_dirdest" &> /dev/null
((copycount_local++))
lastfile=$file

# update dialog box 
cat <<EOF
XXX
$percent
\n$copy_info ${file:0:20}\n\nCopied: $copycount_local / $filecount
XXX
EOF

# If copy skipped, display progress bar every 25 %
elif ! (( $percent % 25 )); then
cat <<EOF
XXX
$percent
\n$copy_info ${lastfile:0:20}\n\nCopied: $copycount_local / $filecount
XXX
EOF
fi
done < /tmp/sourcelist
echo $copycount_local > /tmp/copycount
)
rm /tmp/sourcelist
setterm -cursor off
sleep 2
}

copy_gauge_dialog_overwrite ()
{
copy_dirsource=$1
copy_dirdest=$2
copy_info=$3
copy_filter=$4

if [ -z "$copy_filter" ]; then
  copyfilter=".*"
fi
mkdir "$copy_dirdest" &> /dev/null
filecount=$( ls $copy_dirsource | grep "$copy_filter" | wc -l )
file="..."
lastfile=$file
ls $copy_dirsource | grep "$copy_filter" >/tmp/sourcelist
dialog --title "pinHP Arcade Classics" --gauge "\n$copy_info $file\n\nCopied: 0 / $filecount" 10 32 < <(
copycount_local=0
echo $copycount_local /tmp/copycount

i=0
while read file
do
# calculate progress
percent=$(( 100*(++i)/filecount ))

cp "$copy_dirsource/$file" "$copy_dirdest" &> /dev/null
((copycount_local++))
lastfile=$file

# update dialog box 
cat <<EOF
XXX
$percent
\n$copy_info ${file:0:20}\n\nCopied: $copycount_local / $filecount
XXX
EOF

done < /tmp/sourcelist
echo $copycount_local > /tmp/copycount
)
rm /tmp/sourcelist
setterm -cursor off
sleep 2
}

save_orientation_settings ()
{
  echo "#!/bin/bash" > "$SETTINGS_HV"
  echo  >> "$SETTINGS_HV"
  echo "#########################################" >> "$SETTINGS_HV"
  echo "##  Saved settings for: ORIENTATION=$ORIENTATION  ##" >> "$SETTINGS_HV"
  echo "#########################################" >> "$SETTINGS_HV"
  echo  >> "$SETTINGS_HV"
  echo "CONFIGFILE=\$1" >> "$SETTINGS_HV"
  echo  >> "$SETTINGS_HV"

  declare -a vars=( "color_mode" "friendly_names" "game_count" "menu_text_size" "screen_theme" "orientation_filter" "preview_images" "preview_logos" "preview_marquees" "preview_videos" )
  for var in "${vars[@]}"
  do
    echo "$var=${!var}" >> "$SETTINGS_HV"
    echo "sed -i -e \"s/$var=./$var=\$$var/\" \"\$CONFIGFILE\""  >> "$SETTINGS_HV"  
    echo >> "$SETTINGS_HV"
  done 

  declare -a vars=( "ll_flip" "menu_text_color" "menu_highlight_color" "menu_text_justify" )
  for var in "${vars[@]}"
  do
    echo "$var=${!var}" >> "$SETTINGS_HV"
  done
}

read_orientation_settings ()
{
  ln -sfn "$SETTINGS/settings_$ORIENTATION" "$SETTINGS_HV"
  source "$SETTINGS_HV" "$CONFIGFILE"

  if [ "$ll_flip" = "Y" ]; then
    sed -i -e "s/title =\".*$TEXT_SCREEN_UPSIDE_DOWN/title =\"\xB7$TEXT_SCREEN_UPSIDE_DOWN/" $CFGSETTINGS
  else
    sed -i -e "s/title =\".*$TEXT_SCREEN_UPSIDE_DOWN/title =\"$TEXT_SCREEN_UPSIDE_DOWN/" $CFGSETTINGS
  fi                        

  if [ "$orientation_filter" = "Y" ]; then
    sed -i -e 's/^orientationfilter=.*/orientationfilter="h"/' $LLCONFH
    sed -i -e 's/^orientationfilter=.*/orientationfilter="v"/' $LLCONFV
  else
    sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFH
    sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFV  
  fi

  # Display game preview images?
  if [ "$preview_images" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/snaps" /root/.lemonlauncher_common/lemonsnaps
  else
    ln -sfn "/root/rpi2jamma/systemsnaps" /root/.lemonlauncher_common/lemonsnaps
  fi
  
  # Display game preview videos?
  if [ "$preview_videos" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/videos" /root/.lemonlauncher_common/lemonvideos
  else
    ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonvideos
  fi
  
  # Enable game preview marquees if checked
  if [ "$preview_marquees" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/marquees" /root/.lemonlauncher_common/lemonmarquees
  else
    ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
  fi
  
  # Enable game preview logos if checked
  if [ "$preview_logos" = "Y" ]; then
    ln -sfn "$RPI2JAMMA/logos" /root/.lemonlauncher_common/lemonlogos
  else
    ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
  fi

  # If preview logos is checked, disable marquees unless theme = horizontal maxi
  if [ "$preview_logos" = "Y" ]; then
    if [ "$ORIENTATION" != "H" ] || [ "$screen_theme" != "2" ]; then
      preview_marquees="N"
      ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
    fi
  fi

  case $menu_text_justify in
    center )
      for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
        do
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
        done
      sync
    ;;
    left )
      for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
        do
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
        done
      sync
    ;;
    right )
      for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
        do
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
          sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
        done
      sync
    ;;
  esac

  for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
    do
      sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
      sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
      sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
      sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
    done

  for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
    do
      sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
      sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
      sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
      sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
    done

  set_screen_theme
  set_lemon_configdir
  set_video_options
  checksum_compare
}

save_game_filters ()
{
  echo "# game filter vars" > $GAMEFILTERS
  echo "" >> $GAMEFILTERS

  echo "group_games=\"$group_games\"" >> $GAMEFILTERS
  echo "" >> $GAMEFILTERS
  
  for item in "${FILTER_ARRAY_CHOICE[@]}"
  do
    if ! [[ "$item" =~ .*exclude ]]; then
      var_filter="filter_${item}"
      var_index="filter_${item}_index"
      value_filter=${!var_filter}
      value_index=${!var_index}
      echo "$var_filter=\"$value_filter\"" >> $GAMEFILTERS
      echo "$var_index=$value_index" >> $GAMEFILTERS
    fi
  done
  echo "filter_horizontal=\"$filter_horizontal\"" >> $GAMEFILTERS
  echo "filter_vertical=\"$filter_vertical\"" >> $GAMEFILTERS
}

online_modeline_update ()
{
  pikeyd165_start "yesno" "0.5"
  joy2key_start "yesno"
  pinhp_image=""
  current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
  
  # Check online status
  if [ "$current_ip" = "" ]; then
    joy2key_stop
    dialog_no_network
  
  # Ok, we are online
  else

    token_admin=""
    token_file="https://drive.google.com/uc?export=download&id=15WxG1aCyw-vsDx9UnJgJoDGX_SV3VnTF"
    update_beta_server="https://drive.google.com/uc?export=download&id=1NaSYkyAVPhBAcSpkPBTyv4cDnQ7u96m8"
    token_admin_tmp=$(cat $CONFIGFILE | grep -m 1 ^token_admin= | awk -F= '{print $2}')
    token_file_tmp=$(cat $CONFIGFILE | grep -m 1 ^token_file= | awk -F'token_file=' '{print $2}')
    if [ -n "$token_admin_tmp" ]; then
      token_admin=$token_admin_tmp
    fi
    if [ -n "$token_user_tmp" ]; then
      token_user=$token_user_tmp
    fi
    if [ -n "$token_file_tmp" ]; then
      token_file=$token_file_tmp
    fi
    TOKEN_ADMIN=""

    if [ -n "$token_admin" ]; then
      curl --connect-timeout $connection_timeout -k -L -o /tmp/TOKEN "$token_file"
      sed -i 's/\r//g' "/tmp/TOKEN"
      TOKEN_ADMIN=$(grep "TOKEN_ADMIN" "/tmp/TOKEN" | awk -F= '{print $2}' )
      rm "/tmp/TOKEN"
      if [ -n "$TOKEN_ADMIN" ] && [ "$TOKEN_ADMIN" = "$token_admin" ]; then
        TOKEN_ADMIN="valid"
      fi
    fi

    unset token_admin
    unset token_file
    unset token_admin_tmp
    unset token_file_tmp

    # Get update server file containing further links
    if ! [ -e /tmp/patch_server.txt ]; then
      touch /tmp/patch_server.txt
      echo "$update_server" > /tmp/update_server_url
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_server.txt "$update_server"
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nTrying alternate server" 9 26
      fi
    fi
    
    # Test if download is valid, otherwise download from alternate server
    if ! grep -q "pinhp_image" "/tmp/patch_server.txt"; then
      echo "$UPDATE_SERVER_2" >> /tmp/update_server_url
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_server.txt "$UPDATE_SERVER_2"  
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
    fi

    sed -i 's/\r//g' "/tmp/patch_server.txt"
    pinhp_image=$(grep "pinhp_image" "/tmp/patch_server.txt" | awk -F 'pinhp_image=' '{print $2}' )
    update_info_file=$(grep "update_info_file" "/tmp/patch_server.txt" | awk -F 'update_info_file=' '{print $2}' )
    update_script=$(grep "update_script" "/tmp/patch_server.txt" | awk -F 'update_script=' '{print $2}' )
    
    # Check if update server file is valid
    if [ "$pinhp_image" = "pinHP Arcade Classics" ]; then
      pinhp_image=""
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_info.txt "$update_info_file"
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
      sed -i 's/\r//g' "/tmp/patch_info.txt"
      patch_disabled=$(grep "patch_disabled" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[1]")

      # Update not disabled?
      if [ "$patch_disabled" != "1" ] || [ "$TOKEN_ADMIN" = "valid" ]; then
        TOKEN_ADMIN=""

        # Download update script, do not download again within 10 minutes
        if [ ! -e /tmp/update_script_last ]; then
          echo $SECONDS > /tmp/update_script_last
        fi
        update_script_last=$( cat /tmp/update_script_last )
        time_passed=$(( SECONDS - update_script_last ))
        if ! [ -e /tmp/update_script.sh ] || [ $time_passed -gt 600 ]; then
          curl --connect-timeout $connection_timeout -k -L -o /tmp/update_script.sh "$update_script"
          response=$?
          if [ "$response" = "28" ] || [ ! -e "/tmp/update_script.sh" ]; then
            if [ "$response" = "28" ]; then
              dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
            else
              dialog --timeout 15 --begin 10 9 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR ***\n\nFile not found" 9 22
            fi
          else
            echo $SECONDS > /tmp/update_script_last
          fi
        fi
        
        # File exists already or has been just downloaded
        if [ -e /tmp/update_script.sh ]; then
          # Make variables accessible
          declare -p > /tmp/pinhp_variables
          # Run update script
          joy2key_stop
          bash /tmp/update_script.sh "$MAMECONFIG" "$hardwaremode_current" "$TEMPLATEFILE" "$RPI2JAMMA"
          setterm -cursor off
        fi

      # Update disabled  
      else
        dialog --timeout 15 --begin 10 6 --title "pinHP Arcade Classics" --msgbox "\nSystem maintenance ...\n\nPlease check back later." 10 29
      fi  

    # Error - update server file not valid
    else
      dialog --timeout 15 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR [1] ***\n\nCheck update server" 9 24
    fi             

  fi
  joy2key_stop
}

online_timings_replace ()
{
  pikeyd165_start "yesno" "0.5"
  joy2key_start "yesno"
  pinhp_image=""
  current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
  
  # Check online status
  if [ "$current_ip" = "" ]; then
    joy2key_stop
    dialog_no_network
  
  # Ok, we are online
  else

    token_admin=""
    token_file="https://drive.google.com/uc?export=download&id=15WxG1aCyw-vsDx9UnJgJoDGX_SV3VnTF"
    update_beta_server="https://drive.google.com/uc?export=download&id=1NaSYkyAVPhBAcSpkPBTyv4cDnQ7u96m8"
    token_admin_tmp=$(cat $CONFIGFILE | grep -m 1 ^token_admin= | awk -F= '{print $2}')
    token_file_tmp=$(cat $CONFIGFILE | grep -m 1 ^token_file= | awk -F'token_file=' '{print $2}')
    if [ -n "$token_admin_tmp" ]; then
      token_admin=$token_admin_tmp
    fi
    if [ -n "$token_user_tmp" ]; then
      token_user=$token_user_tmp
    fi
    if [ -n "$token_file_tmp" ]; then
      token_file=$token_file_tmp
    fi
    TOKEN_ADMIN=""

    if [ -n "$token_admin" ]; then
      curl --connect-timeout $connection_timeout -k -L -o /tmp/TOKEN "$token_file"
      sed -i 's/\r//g' "/tmp/TOKEN"
      TOKEN_ADMIN=$(grep "TOKEN_ADMIN" "/tmp/TOKEN" | awk -F= '{print $2}' )
      rm "/tmp/TOKEN"
      if [ -n "$TOKEN_ADMIN" ] && [ "$TOKEN_ADMIN" = "$token_admin" ]; then
        TOKEN_ADMIN="valid"
      fi
    fi

    unset token_admin
    unset token_file
    unset token_admin_tmp
    unset token_file_tmp

    # Get update server file containing further links
    if ! [ -e /tmp/patch_server.txt ]; then
      touch /tmp/patch_server.txt
      echo "$update_server" > /tmp/update_server_url
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_server.txt "$update_server"
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nTrying alternate server" 9 26
      fi
    fi
    
    # Test if download is valid, otherwise download from alternate server
    if ! grep -q "pinhp_image" "/tmp/patch_server.txt"; then
      echo "$UPDATE_SERVER_2" >> /tmp/update_server_url
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_server.txt "$UPDATE_SERVER_2"  
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
    fi

    sed -i 's/\r//g' "/tmp/patch_server.txt"
    pinhp_image=$(grep "pinhp_image" "/tmp/patch_server.txt" | awk -F 'pinhp_image=' '{print $2}' )
    update_info_file=$(grep "update_info_file" "/tmp/patch_server.txt" | awk -F 'update_info_file=' '{print $2}' )
    pinhp_timings_script=$(grep "pinhp_timings_script" "/tmp/patch_server.txt" | awk -F 'pinhp_timings_script=' '{print $2}' )
    
    # Check if update server file is valid
    if [ "$pinhp_image" = "pinHP Arcade Classics" ]; then
      pinhp_image=""
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_info.txt "$update_info_file"
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
      sed -i 's/\r//g' "/tmp/patch_info.txt"
      patch_disabled=$(grep "patch_disabled" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[1]")

      # Update not disabled?
      if [ "$patch_disabled" != "1" ] || [ "$TOKEN_ADMIN" = "valid" ]; then
        TOKEN_ADMIN=""

        # Download update script, do not download again within 10 minutes
        if [ ! -e /tmp/pinhp_timings_script_last ]; then
          echo $SECONDS > /tmp/pinhp_timings_script_last
        fi
        pinhp_timings_script_last=$( cat /tmp/pinhp_timings_script_last )
        time_passed=$(( SECONDS - pinhp_timings_script_last ))
        if ! [ -e /tmp/pinhp_timings_script.sh ] || [ $time_passed -gt 600 ]; then
          curl --connect-timeout $connection_timeout -k -L -o /tmp/pinhp_timings_script.sh "$pinhp_timings_script"
          response=$?
          if [ "$response" = "28" ] || [ ! -e "/tmp/pinhp_timings_script.sh" ]; then
            if [ "$response" = "28" ]; then
              dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
            else
              dialog --timeout 15 --begin 10 9 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR ***\n\nFile not found" 9 22
            fi
          else
            echo $SECONDS > /tmp/pinhp_timings_script_last
          fi
        fi
        
        # File exists already or has been just downloaded
        if [ -e /tmp/pinhp_timings_script.sh ]; then
          # Make variables accessible
          declare -p > /tmp/pinhp_variables
          # Run update script
          joy2key_stop
          bash /tmp/pinhp_timings_script.sh "$MAMECONFIG" "$hardwaremode_current" "$TEMPLATEFILE" "$RPI2JAMMA"
          setterm -cursor off
        fi

      # Update disabled  
      else
        dialog --timeout 15 --begin 10 6 --title "pinHP Arcade Classics" --msgbox "\nSystem maintenance ...\n\nPlease check back later." 10 29
      fi  

    # Error - update server file not valid
    else
      dialog --timeout 15 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR [1] ***\n\nCheck update server" 9 24
    fi             

  fi
  joy2key_stop
}

online_system_update ()
{
  pikeyd165_start "yesno" "0.5"
  joy2key_start "yesno"
  pinhp_image=""
  current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
  
  # Check online status
  if [ "$current_ip" = "" ]; then
    joy2key_stop
    dialog_no_network
  
  # Ok, we are online
  else

    ### BEGIN patch beta handling by user token ###

    token_admin=""
    token_user=""
    token_file="https://drive.google.com/uc?export=download&id=15WxG1aCyw-vsDx9UnJgJoDGX_SV3VnTF"
    update_beta_server="https://drive.google.com/uc?export=download&id=1NaSYkyAVPhBAcSpkPBTyv4cDnQ7u96m8"
    token_admin_tmp=$(cat $CONFIGFILE | grep -m 1 ^token_admin= | awk -F= '{print $2}')
    token_user_tmp=$(cat $CONFIGFILE | grep -m 1 ^token= | awk -F= '{print $2}')
    token_file_tmp=$(cat $CONFIGFILE | grep -m 1 ^token_file= | awk -F'token_file=' '{print $2}')
    update_beta_server_tmp=$(cat $CONFIGFILE | grep -m 1 ^update_beta_server= | awk -F 'update_beta_server=' '{print $2}')
    if [ -n "$token_admin_tmp" ]; then
      token_admin=$token_admin_tmp
    fi
    if [ -n "$token_user_tmp" ]; then
      token_user=$token_user_tmp
    fi
    if [ -n "$token_file_tmp" ]; then
      token_file=$token_file_tmp
    fi
    if [ -n "$update_beta_server_tmp" ]; then
      update_beta_server=$update_beta_server_tmp
    fi
    TOKEN_ADMIN=""
    TOKEN_USER=""

    if [ -n "$token_admin" ] || [ -n "$token_user" ]; then
      curl --connect-timeout $connection_timeout -k -L -o /tmp/TOKEN "$token_file"
      sed -i 's/\r//g' "/tmp/TOKEN"
      TOKEN_ADMIN=$(grep "TOKEN_ADMIN" "/tmp/TOKEN" | awk -F= '{print $2}' )
      TOKEN_USER=$(grep "TOKEN_USER" "/tmp/TOKEN" | awk -F= '{print $2}' )
      rm "/tmp/TOKEN"
      if [ -n "$TOKEN_ADMIN" ] && [ "$TOKEN_ADMIN" = "$token_admin" ]; then
        TOKEN_ADMIN="valid"
      fi
      if  [ -n "$TOKEN_USER" ] && [ "$TOKEN_USER" = "$token_user" ]; then
        TOKEN_USER="valid"
      fi
    fi

    unset token_admin
    unset token_user
    unset token_file
    unset token_admin_tmp
    unset token_user_tmp
    unset token_file_tmp
     
    if [ "$TOKEN_USER" = "valid" ]; then
      TOKEN_USER=""

      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_beta_server.txt "$update_beta_server"
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
      sed -i 's/\r//g' "/tmp/patch_beta_server.txt"
      pinhp_image=$(grep "pinhp_image" "/tmp/patch_beta_server.txt" | awk -F 'pinhp_image=' '{print $2}' )
      update_info_file=$(grep "update_info_file" "/tmp/patch_beta_server.txt" | awk -F 'update_info_file=' '{print $2}' )
      update_patch_file=$(grep "update_patch_file" "/tmp/patch_beta_server.txt" | awk -F 'update_patch_file=' '{print $2}' )

      # Check if update server file is valid
      if [ "$pinhp_image" = "pinHP Arcade Classics" ]; then
        pinhp_image=""
        curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_info.txt "$update_info_file"
        response=$?
        if [ "$response" = "28" ]; then
          dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
        fi
        sed -i 's/\r//g' "/tmp/patch_info.txt"
        pinhp_image=$(grep "pinhp_image" "/tmp/patch_info.txt" | awk -F= '{print $2}' )
        patch_version=$(grep "patch_version" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[0-9]\+")
        patch_date=$(grep "patch_date" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[A-Za-z0-9]\+")
        patch_minversion=$(grep "patch_minversion" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[0-9]\+")
        patch_general_info=$(grep "patch_general_info" "/tmp/patch_info.txt" | awk -F= '{print $2}' )
        patch_update_info=$(grep "patch_update_info" "/tmp/patch_info.txt" | awk -F= '{print $2}' )
        patch_disabled=$(grep "patch_disabled" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[1]")
      fi

      # Check if version info file is valid
      if [ "$pinhp_image" = "pinHP Arcade Classics" ]; then
        pinhp_image=""

        # Is there some general info to display?
        if [ "$patch_general_info" != "" ]; then
          dialog --timeout 30 --title "pinHP Arcade Classics" --msgbox "\n$patch_general_info" 0 0
        fi

        # Update not disabled?
        if [ "$patch_disabled" != "1" ] || [ "$TOKEN_ADMIN" = "valid" ]; then
          TOKEN_ADMIN=""
          # Is there some version info to display?
          if [ "$patch_update_info" != "" ]; then
            dialog --timeout 30 --title "pinHP Arcade Classics" --msgbox "\n$patch_update_info" 0 0
          fi

          dialog --timeout 15 --begin 9 6 --title "pinHP Arcade Classics" --defaultno --yesno "\nUpdate available:\n\n$patch_date\n\nDownload and install?" 11 28
          response=$?
          if [ "$response" = "0" ]; then
            clear
            curl --connect-timeout $connection_timeout -k -L -o /tmp/online_beta_patch.tgz "$update_patch_file"
            response=$?
            if [ "$response" = "28" ]; then
              dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
            fi
            echo
            cp -v /tmp/online_beta_patch.tgz "$RPI2JAMMA/patch_pinhp_beta_$patch_date.tgz"
            sync
            sleep 1
            PATCHREBOOT=1
            install_patch
          fi
        fi
      fi
    fi

    unset TOKEN_USER
    unset update_beta_server
    unset update_beta_server_tmp

    ### END patch beta handling ###

    ### Regular patch handling ###
    # Get update server file containing further links
    touch /tmp/patch_server.txt
    echo "$update_server" > /tmp/update_server_url
    curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_server.txt "$update_server"
    response=$?
    if [ "$response" = "28" ]; then
      dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nTrying alternate server" 9 26
    fi

    # Test if download is valid, otherwise download from alternate server
    if ! grep -q "pinhp_image" "/tmp/patch_server.txt"; then
      echo "$UPDATE_SERVER_2" >> /tmp/update_server_url
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_server.txt "$UPDATE_SERVER_2"  
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
    fi

    sed -i 's/\r//g' "/tmp/patch_server.txt"
    pinhp_image=$(grep "pinhp_image" "/tmp/patch_server.txt" | awk -F 'pinhp_image=' '{print $2}' )
    update_info_file=$(grep "update_info_file" "/tmp/patch_server.txt" | awk -F 'update_info_file=' '{print $2}' )
    update_patch_file=$(grep "update_patch_file" "/tmp/patch_server.txt" | awk -F 'update_patch_file=' '{print $2}' )
    
    # Check if update server file is valid
    if [ "$pinhp_image" = "pinHP Arcade Classics" ]; then
      pinhp_image=""
      curl --connect-timeout $connection_timeout -k -L -o /tmp/patch_info.txt "$update_info_file"
      response=$?
      if [ "$response" = "28" ]; then
        dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
      fi
      sed -i 's/\r//g' "/tmp/patch_info.txt"
      pinhp_image=$(grep "pinhp_image" "/tmp/patch_info.txt" | awk -F= '{print $2}' )
      patch_version=$(grep "patch_version" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[0-9]\+")
      patch_date=$(grep "patch_date" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[A-Za-z0-9]\+")
      patch_minversion=$(grep "patch_minversion" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[0-9]\+")
      patch_general_info=$(grep "patch_general_info" "/tmp/patch_info.txt" | awk -F= '{print $2}' )
      patch_update_info=$(grep "patch_update_info" "/tmp/patch_info.txt" | awk -F= '{print $2}' )
      patch_disabled=$(grep "patch_disabled" "/tmp/patch_info.txt" | awk -F= '{print $2}' | grep -m 1 -o "[1]")

      # Check if version info file is valid
      if [ "$pinhp_image" = "pinHP Arcade Classics" ]; then
        pinhp_image=""

        # Is there some general info to display?
        if [ "$patch_general_info" != "" ]; then
          dialog --timeout 30 --title "pinHP Arcade Classics" --msgbox "\n$patch_general_info" 0 0
        fi

        # Update not disabled?
        if [ "$patch_disabled" != "1" ] || [ "$TOKEN_ADMIN" = "valid" ]; then
          TOKEN_ADMIN=""

          # Check if patch is ok with running version, install after confirmation dialog 
          if [ "$patch_version" -gt "$VERSION" ] && [ "$VERSION" -ge "$patch_minversion" ]; then

            # Is there some version info to display?
            if [ "$patch_update_info" != "" ]; then
              dialog --timeout 30 --title "pinHP Arcade Classics" --msgbox "\n$patch_update_info" 0 0
            fi
            dialog --timeout 15 --begin 9 6 --title "pinHP Arcade Classics" --defaultno --yesno "\nUpdate available:\n\n$patch_date\n\nDownload and install?" 11 28
            response=$?
            if [ "$response" = "0" ]; then
              clear
              curl --connect-timeout $connection_timeout -k -L -o /tmp/online_patch.tgz "$update_patch_file"
              response=$?
              if [ "$response" = "28" ]; then
                dialog --timeout 15 --begin 10 7 --title "pinHP Arcade Classics" --msgbox "\n*** TIMEOUT ERROR ***\n\nCheck connection" 9 26
              fi
              echo
              cp -v /tmp/online_patch.tgz "$RPI2JAMMA/patch_pinhp_$patch_date.tgz"
              sync
              sleep 1
              PATCHREBOOT=1
              install_patch
            fi
          
          # Patch requires greater running version
          elif [ "$patch_minversion" -gt "$VERSION" ]; then
            dialog --timeout 15 --begin 10 6 --title "pinHP Arcade Classics" --msgbox "\nUpdate available, but not\n\ncompatible with this version." 10 29
          
          # It seems we are already up to date
          else
            dialog --timeout 15 --begin 8 7 --title "pinHP Arcade Classics" --msgbox "\nCongratulations!\n\nYou are already running\nthe latest version.\n$ABOUTDIALOG_DATE\n" 12 27
          fi
        
        # Update disabled  
        else
          dialog --timeout 15 --begin 10 6 --title "pinHP Arcade Classics" --msgbox "\nSystem maintenance ...\n\nPlease check back later." 10 29
        fi              

      # Error - version info file not valid
      else
      dialog --timeout 15 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR [2] ***\n\nCheck update server" 9 24
      fi
    
    # Error - update server file not valid
    else
    dialog --timeout 15 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR [1] ***\n\nCheck update server" 9 24
    fi

  fi
  unset TOKEN_ADMIN
  joy2key_stop
  rm -f /tmp/patch_info.txt
  rm -f /tmp/patch_server.txt
  generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
}

# Game menu
generate_game_menu ()
{
  source "$SCRIPTS/generate_game_menu.sh"
}

# Options menu
generate_options_menu ()
{
  source "$SCRIPTS/generate_options_menu.sh"
}

# Filter menu
generate_filter_menu ()
{
  source "$SCRIPTS/generate_filter_menu.sh"
  pikeyd165_start "force"
  CURRENTMENU="Filter"
}

# Group menu
generate_group_menu ()
{
  source "$SCRIPTS/generate_group_menu.sh"
  pikeyd165_start "force"
  CURRENTMENU="Group"
}

# Additional settings sub menus
generate_submenu ()
{
  SYSTEMMENU=1
  GENERATFLAG=0
  clear_gameselect_flags
  set_screen_theme
  source "$1"
  cat $CFGMENUTMP > $CFGSETTINGS
  ln -sf $CFGSETTINGS /root/.lemonlauncherH/games.conf
  ln -sf $CFGSETTINGS /root/.lemonlauncherV/games.conf
  ln -sfn "/root/rpi2jamma/systemsnaps" /root/.lemonlauncher_common/lemonsnaps
  
  for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
  do
    ln -sf "/root/.lemonlauncherH/bg$theme/theme_system.conf" "/root/.lemonlauncherH/bg$theme/theme.conf"
    ln -sf "/root/.lemonlauncherV/bg$theme/theme_system.conf" "/root/.lemonlauncherV/bg$theme/theme.conf"
  done
  pikeyd165_start "force"
}


filter_menu_back ()          
{
  exit_systemmenu
  CURRENTMENU=""
  save_game_filters
  menuline=$( cat $CFGGAMES | grep 'params ="filter_games"' )
  hash_menu="$menu_options"
  hash_mark=""
  hash_title=$( echo "$menuline" | awk -F'"' '{print $4}' )
  if grep -q "\\xB7" <<< "$hash_title"; then
    hash_title=${hash_title#\\xB7}
    hash_mark="B7"
  fi
  hash_par=$( echo "$menuline" | awk -F'"' '{print $6}' )
  hash_rom=$( echo "$menuline" | awk -F'"' '{print $2}' )
  ll_hash
}

group_menu_back ()
{
  exit_systemmenu
  CURRENTMENU=""
  menuline=$( cat $CFGGAMES | grep 'params ="group_games"' )
  hash_menu="$menu_options"
  hash_mark=""
  hash_title=$( echo "$menuline" | awk -F'"' '{print $4}' )
  if grep -q "\\xB7" <<< "$hash_title"; then
    hash_title=${hash_title#\\xB7}
    hash_mark="B7"
  fi
  hash_par=$( echo "$menuline" | awk -F'"' '{print $6}' )
  hash_rom=$( echo "$menuline" | awk -F'"' '{print $2}' )
  ll_hash
}

settings_menu_back ()
{
  hash_menu="$menu_options"
  hash_mark=""
  hash_title="$hash_return_title"
  hash_par="$hash_return_par"
  hash_rom="pinhp"
  ll_hash
  exit_systemmenu
}

read_configfile ()
{

  # Default values
  backup_option="N"
  restore_option="N"
  hidden_features=1
  hidden_seconds=10
  game_menu_dirs=1
  screen_orientation="H"
  orientation_filter="N"
  autostart_rom=""
  autostart_arcade="Y"
  reboot_option="Y"
  shutdown_option="Y"
  game_count="Y"
  friendly_names="N"
  screensaver_seconds=600
  status_messages="N"
  quickedit_mode="Y"
  screen_theme=1
  preview_images="Y"
  preview_videos="Y"
  preview_marquees="Y"
  preview_logos="Y"
  video_delay=2
  pi2scart_mode="A"
  favbutton="3"
  color_mode=2
  screensaver_type=1
  update_server=$UPDATE_SERVER
  connection_timeout=$CURL_TIMEOUT
  date_mode=1
  keymap_1="de"
  keymap_2="us"
  keymap_3="fr"
  current_keyboard_layout="de-latin1-nodeadkeys"
  mail_alarm="N"
  mame_buttons="Y"
  mame_buttons_timeout=30
  custom_folders="Y"
  custom_favmenu="N"
  servostik="N"
  servostik_default="8"
  toggle_servostik_option="Y"
  screensaver_option="Y"
  filter_games_option="Y"
  group_games_option="Y"
  menu_text_size=1
  hide_mature="N"
  group_show_other="Y"
  autostart_last="N"
  clone_joysticks="N"
  clone_buttons="N"
  autorotate_gpio=-1
  boot_into_gamelist="N"
  auto_insert_coin="N"
  shutdown_dialog="Y"
  buttons_456="0"
  preview_videos_loop="N"
 
  # Read configfile entries
  backup_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^backup_option= | awk -F= '{print $2}' | grep -o "[YN]")
  restore_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^restore_option= | awk -F= '{print $2}' | grep -o "[YN]")
  hidden_features_tmp=$(cat $CONFIGFILE | grep -m 1 ^hidden_features= | awk -F= '{print $2}' | grep -o "[01]")
  game_menu_dirs_tmp=$(cat $CONFIGFILE | grep -m 1 ^game_menu_dirs= | awk -F= '{print $2}' | grep -o "[0-9]")
  screen_orientation_tmp=$(cat $CONFIGFILE | grep -m 1 ^screen_orientation= | awk -F= '{print $2}' | grep -o "[HVA]")
  orientation_filter_tmp=$(cat $CONFIGFILE | grep -m 1 ^orientation_filter= | awk -F= '{print $2}' | grep -o "[YN]")
  autostart_rom_tmp=$(cat $CONFIGFILE | grep -m 1 ^autostart_rom= | awk -F= '{print $2}')
  autostart_arcade_tmp=$(cat $CONFIGFILE | grep -m 1 ^autostart_arcade= | awk -F= '{print $2}' | grep -o "[YN]")
  reboot_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^reboot_option= | awk -F= '{print $2}' | grep -o "[YN]")
  shutdown_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^shutdown_option= | awk -F= '{print $2}' | grep -o "[YN]")
  single_menu_title_tmp=$(cat $CONFIGFILE | grep -m 1 ^single_menu_title= | awk -F'single_menu_title=' '{print $2}')
  menu_title_1_of_2_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_title_1_of_2= | awk -F'menu_title_1_of_2=' '{print $2}')
  menu_title_2_of_2_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_title_2_of_2= | awk -F'menu_title_2_of_2=' '{print $2}')
  menu_title_1_of_3_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_title_1_of_3= | awk -F'menu_title_1_of_3=' '{print $2}')
  menu_title_2_of_3_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_title_2_of_3= | awk -F'menu_title_2_of_3=' '{print $2}')
  menu_title_3_of_3_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_title_3_of_3= | awk -F'menu_title_3_of_3=' '{print $2}')
  game_count_tmp=$(cat $CONFIGFILE | grep -m 1 ^game_count= | awk -F= '{print $2}' | grep -o "[YN]")
  friendly_names_tmp=$(cat $CONFIGFILE | grep -m 1 ^friendly_names= | awk -F= '{print $2}' | grep -o "[YN]")
  screensaver_seconds_tmp=$(cat $CONFIGFILE | grep -m 1 ^screensaver_seconds= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  status_messages_tmp=$(cat $CONFIGFILE | grep -m 1 ^status_messages= | awk -F= '{print $2}' | grep -o "[YN]")
  quickedit_mode_tmp=$(cat $CONFIGFILE | grep -m 1 ^quickedit_mode= | awk -F= '{print $2}' | grep -o "[YN]")
  menu_options_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_options= | awk -F'menu_options=' '{print $2}')
  menu_back_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_back= | awk -F'menu_back=' '{print $2}')
  menu_screensaver_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_screensaver= | awk -F'menu_screensaver=' '{print $2}')
  menu_reboot_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_reboot= | awk -F'menu_reboot=' '{print $2}')
  menu_shutdown_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_shutdown= | awk -F'menu_shutdown=' '{print $2}')
  menu_backup_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_backup= | awk -F'menu_backup=' '{print $2}')
  menu_restore_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_restore= | awk -F'menu_restore=' '{print $2}')
  menu_about_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_about= | awk -F'menu_about=' '{print $2}')
  screen_theme_tmp=$(cat $CONFIGFILE | grep -m 1 ^screen_theme= | awk -F= '{print $2}' | grep -o "[12]")
  preview_images_tmp=$(cat $CONFIGFILE | grep -m 1 ^preview_images= | awk -F= '{print $2}' | grep -o "[YN]")
  preview_videos_tmp=$(cat $CONFIGFILE | grep -m 1 ^preview_videos= | awk -F= '{print $2}' | grep -o "[YN]")
  preview_marquees_tmp=$(cat $CONFIGFILE | grep -m 1 ^preview_marquees= | awk -F= '{print $2}' | grep -o "[YN]")
  preview_logos_tmp=$(cat $CONFIGFILE | grep -m 1 ^preview_logos= | awk -F= '{print $2}' | grep -o "[YN]")
  hidden_seconds_tmp=$(cat $CONFIGFILE | grep -m 1 ^hidden_seconds= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  video_delay_tmp=$(cat $CONFIGFILE | grep -m 1 ^video_delay= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  pi2scart_mode_tmp=$(cat $CONFIGFILE | grep -m 1 ^pi2scart_mode= | awk -F= '{print $2}' | grep -o "[YNA]")
  favbutton_tmp=$(cat $CONFIGFILE | grep -m 1 ^favbutton= | awk -F= '{print $2}' | grep -o "[1234567]")
  color_mode_tmp=$(cat $CONFIGFILE | grep -m 1 ^color_mode= | awk -F= '{print $2}' | grep -o "[1234]")
  screensaver_type_tmp=$(cat $CONFIGFILE | grep -m 1 ^screensaver_type= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  update_server_tmp=$(cat $CONFIGFILE | grep -m 1 ^update_server= | awk -F 'update_server=' '{print $2}')
  connection_timeout_tmp=$(cat $CONFIGFILE | grep -m 1 ^connection_timeout= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  date_mode_tmp=$(cat $CONFIGFILE | grep -m 1 ^date_mode= | awk -F= '{print $2}' | grep -o "[123]")
  keymap_1_tmp=$(cat $CONFIGFILE | grep -m 1 ^keymap_1= | awk -F= '{print $2}')
  keymap_2_tmp=$(cat $CONFIGFILE | grep -m 1 ^keymap_2= | awk -F= '{print $2}')
  keymap_3_tmp=$(cat $CONFIGFILE | grep -m 1 ^keymap_3= | awk -F= '{print $2}')
  current_keyboard_layout_tmp=$(cat $CONFIGFILE | grep -m 1 ^current_keyboard_layout= | awk -F= '{print $2}')
  mail_alarm_tmp=$(cat $CONFIGFILE | grep -m 1 ^mail_alarm= | awk -F= '{print $2}' | grep -o "[YN]")
  mame_buttons_tmp=$(cat $CONFIGFILE | grep -m 1 ^mame_buttons= | awk -F= '{print $2}' | grep -o "[YN]")
  mame_buttons_timeout_tmp=$(cat $CONFIGFILE | grep -m 1 ^mame_buttons_timeout= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  custom_folders_tmp=$(cat $CONFIGFILE | grep -m 1 ^custom_folders= | awk -F= '{print $2}' | grep -o "[YN]")
  custom_favmenu_tmp=$(cat $CONFIGFILE | grep -m 1 ^custom_favmenu= | awk -F= '{print $2}' | grep -o "[YN]")
  servostik_tmp=$(cat $CONFIGFILE | grep -m 1 ^servostik= | awk -F= '{print $2}' | grep -o "[YN]")
  servostik_default_tmp=$(cat $CONFIGFILE | grep -m 1 ^servostik_default= | awk -F= '{print $2}' | grep -o "[48]")
  toggle_servostik_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^toggle_servostik_option= | awk -F= '{print $2}' | grep -o "[YN]")
  menu_text_size_tmp=$(cat $CONFIGFILE | grep -m 1 ^menu_text_size= | awk -F= '{print $2}' | grep -o "[12]")
  screensaver_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^screensaver_option= | awk -F= '{print $2}' | grep -o "[YN]")
  hide_mature_tmp=$(cat $CONFIGFILE | grep -m 1 ^hide_mature= | awk -F= '{print $2}' | grep -o "[YN]")
  filter_games_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^filter_games_option= | awk -F= '{print $2}' | grep -o "[YN]")
  group_games_option_tmp=$(cat $CONFIGFILE | grep -m 1 ^group_games_option= | awk -F= '{print $2}' | grep -o "[YN]")
  group_show_other_tmp=$(cat $CONFIGFILE | grep -m 1 ^group_show_other= | awk -F= '{print $2}' | grep -o "[YN]")
  autostart_last_tmp=$(cat $CONFIGFILE | grep -m 1 ^autostart_last= | awk -F= '{print $2}' | grep -o "[YN]")
  clone_joysticks_tmp=$(cat $CONFIGFILE | grep -m 1 ^clone_joysticks= | awk -F= '{print $2}' | grep -o "[YN]")
  clone_buttons_tmp=$(cat $CONFIGFILE | grep -m 1 ^clone_buttons= | awk -F= '{print $2}' | grep -o "[YN]")
  autorotate_gpio_tmp=$(cat $CONFIGFILE | grep -m 1 ^autorotate_gpio= | awk -F= '{print $2}' | grep -o "[0-9]\+")
  boot_into_gamelist_tmp=$(cat $CONFIGFILE | grep -m 1 ^boot_into_gamelist= | awk -F= '{print $2}' | grep -o "[YN]")
  auto_insert_coin_tmp=$(cat $CONFIGFILE | grep -m 1 ^auto_insert_coin= | awk -F= '{print $2}' | grep -o "[YN]")
  shutdown_dialog_tmp=$(cat $CONFIGFILE | grep -m 1 ^shutdown_dialog= | awk -F= '{print $2}' | grep -o "[YN]")
  buttons_456_tmp=$(cat $CONFIGFILE | grep -m 1 ^buttons_456= | awk -F= '{print $2}' | grep -o "[0456]")
  preview_videos_loop_tmp=$(cat $CONFIGFILE | grep -m 1 ^preview_videos_loop= | awk -F= '{print $2}' | grep -o "[YN]")

  if [ -n "$backup_option_tmp" ]; then
    backup_option=$backup_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "backup_option=$backup_option" >> $CONFIGFILE
    sed -i -e "s/backup_option=.*/backup_option=$backup_option/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi

  if [ -n "$restore_option_tmp" ]; then
    restore_option=$restore_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "restore_option=$restore_option" >> $CONFIGFILE
    sed -i -e "s/restore_option=.*/restore_option=$restore_option/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$hidden_features_tmp" ]; then
    hidden_features=$hidden_features_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "hidden_features=$hidden_features" >> $CONFIGFILE
    sed -i -e "s/hidden_features=.*/hidden_features=$hidden_features/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$game_menu_dirs_tmp" ]; then
    game_menu_dirs=$game_menu_dirs_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "game_menu_dirs=$game_menu_dirs" >> $CONFIGFILE
    sed -i -e "s/game_menu_dirs=.*/game_menu_dirs=$game_menu_dirs/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$screen_orientation_tmp" ]; then
    screen_orientation=$screen_orientation_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "screen_orientation=$screen_orientation" >> $CONFIGFILE
    sed -i -e "s/screen_orientation=.*/screen_orientation=$screen_orientation/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$orientation_filter_tmp" ]; then
    orientation_filter=$orientation_filter_tmp
    if [ "$orientation_filter" = "Y" ]; then
      sed -i -e 's/^orientationfilter=.*/orientationfilter="h"/' $LLCONFH
      sed -i -e 's/^orientationfilter=.*/orientationfilter="v"/' $LLCONFV
    else
      sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFH
      sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFV
    fi
    sync
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "orientation_filter=$orientation_filter" >> $CONFIGFILE
    sed -i -e "s/orientation_filter=.*/orientation_filter=$orientation_filter/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  if [ -n "$reboot_option_tmp" ]; then
    reboot_option=$reboot_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "reboot_option=$reboot_option" >> $CONFIGFILE
    sed -i -e "s/reboot_option=.*/reboot_option=$reboot_option/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$shutdown_option_tmp" ]; then
    shutdown_option=$shutdown_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "shutdown_option=$shutdown_option" >> $CONFIGFILE
    sed -i -e "s/shutdown_option=.*/shutdown_option=$shutdown_option/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$screen_theme_tmp" ]; then
    screen_theme=$screen_theme_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "screen_theme=$screen_theme" >> $CONFIGFILE
    sed -i -e "s/screen_theme=.*/screen_theme=$screen_theme/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi

  if [ -n "$color_mode_tmp" ]; then
    color_mode=$color_mode_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "color_mode=$color_mode" >> $CONFIGFILE
    sed -i -e "s/color_mode=.*/color_mode=$color_mode/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi

  if [ -n "$screensaver_type_tmp" ]; then
    screensaver_type=$screensaver_type_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "screensaver_type=$screensaver_type" >> $CONFIGFILE
    sed -i -e "s/screensaver_type=.*/screensaver_type=$screensaver_type/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi

  if [[ -n `echo $update_server_tmp` ]]; then
    update_server=$update_server_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "update_server=$update_server" >> $CONFIGFILE
    sed -i "s${DELIM}^update_server=.*${DELIM}update_server=${update_server//&/\\&}${DELIM}" "$CONFIGFILE" # Ampersand in URL needs to be escaped before variable expansion on right hand side of sed command
    GENERATFLAG=1
    sync
  fi

  if [ -n "$connection_timeout_tmp" ]; then
    connection_timeout=$connection_timeout_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "connection_timeout=$connection_timeout" >> $CONFIGFILE
    sed -i -e "s/connection_timeout=.*/connection_timeout=$connection_timeout/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi

  if [ -n "$single_menu_title_tmp" ]; then
    single_menu_title=$single_menu_title_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "single_menu_title=$single_menu_title" >> $CONFIGFILE
    sed -i -e "s/single_menu_title=.*/single_menu_title=$single_menu_title/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  if [ -n "$menu_title_1_of_2_tmp" ]; then
    menu_title_1_of_2=$menu_title_1_of_2_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_title_1_of_2=$menu_title_1_of_2" >> $CONFIGFILE
    sed -i -e "s/menu_title_1_of_2=.*/menu_title_1_of_2=$menu_title_1_of_2/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_title_2_of_2_tmp" ]; then
    menu_title_2_of_2=$menu_title_2_of_2_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_title_2_of_2=$menu_title_2_of_2" >> $CONFIGFILE
    sed -i -e "s/menu_title_2_of_2=.*/menu_title_2_of_2=$menu_title_2_of_2/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_title_1_of_3_tmp" ]; then
    menu_title_1_of_3=$menu_title_1_of_3_tmp
  elif [ "$game_menu_dirs" = "3" ]; then
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_title_1_of_3=$menu_title_1_of_3" >> $CONFIGFILE
    sed -i -e "s/menu_title_1_of_3=.*/menu_title_1_of_3=$menu_title_1_of_3/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_title_2_of_3_tmp" ]; then
    menu_title_2_of_3=$menu_title_2_of_3_tmp
  elif [ "$game_menu_dirs" = "3" ]; then
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_title_2_of_3=$menu_title_2_of_3" >> $CONFIGFILE
    sed -i -e "s/menu_title_2_of_3=.*/menu_title_2_of_3=$menu_title_2_of_3/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_title_3_of_3_tmp" ]; then
    menu_title_3_of_3=$menu_title_3_of_3_tmp
  elif [ "$game_menu_dirs" = "3" ]; then
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_title_3_of_3=$menu_title_3_of_3" >> $CONFIGFILE
    sed -i -e "s/menu_title_3_of_3=.*/menu_title_3_of_3=$menu_title_3_of_3/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_options_tmp" ]; then
    menu_options=$menu_options_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_options=$menu_options" >> $CONFIGFILE
    sed -i -e "s/menu_options=.*/menu_options=$menu_options/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_back_tmp" ]; then
    menu_back=$menu_back_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_back=$menu_back" >> $CONFIGFILE
    sed -i -e "s/menu_back=.*/menu_back=$menu_back/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_screensaver_tmp" ]; then
    menu_screensaver=$menu_screensaver_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_screensaver=$menu_screensaver" >> $CONFIGFILE
    sed -i -e "s/menu_screensaver=.*/menu_screensaver=$menu_screensaver/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_reboot_tmp" ]; then
    menu_reboot=$menu_reboot_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_reboot=$menu_reboot" >> $CONFIGFILE
    sed -i -e "s/menu_reboot=.*/menu_reboot=$menu_reboot/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_shutdown_tmp" ]; then
    menu_shutdown=$menu_shutdown_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_shutdown=$menu_shutdown" >> $CONFIGFILE
    sed -i -e "s/menu_shutdown=.*/menu_shutdown=$menu_shutdown/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_backup_tmp" ]; then
    menu_backup=$menu_backup_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_backup=$menu_backup" >> $CONFIGFILE
    sed -i -e "s/menu_backup=.*/menu_backup=$menu_backup/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_restore_tmp" ]; then
    menu_restore=$menu_restore_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_restore=$menu_restore" >> $CONFIGFILE
    sed -i -e "s/menu_restore=.*/menu_restore=$menu_restore/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$menu_about_tmp" ]; then
    menu_about=$menu_about_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_about=$menu_about" >> $CONFIGFILE
    sed -i -e "s/menu_about=.*/menu_about=$menu_about/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  escape_menu_titles
  
  if [ -n "$game_count_tmp" ]; then
    game_count=$game_count_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "game_count=$game_count" >> $CONFIGFILE
    sed -i -e "s/game_count=.*/game_count=$game_count/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$friendly_names_tmp" ]; then
    friendly_names=$friendly_names_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "friendly_names=$friendly_names" >> $CONFIGFILE
    sed -i -e "s/friendly_names=.*/friendly_names=$friendly_names/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ ! $(cat $LLCONFH | grep -v "#" | grep orientationfilter=) ]; then
    echo >> $LLCONFH
    echo >> $LLCONFH
    echo "orientationfilter="$orientation_filter >> $LLCONFH
    sync
  fi
  
  if [ ! $(cat $LLCONFV | grep -v "#" | grep orientationfilter=) ]; then
    echo >> $LLCONFV
    echo >> $LLCONFV
    echo "orientationfilter="$orientation_filter >> $LLCONFV
    sync
  fi
  
  if [ "$screen_orientation" = "A" ]; then
     if [[ $(cat $LLCONFH | grep -v "#" | grep ^orientationfilter | awk -F= '{print $2}') != "\"\"" ]] || [[ $(cat $LLCONFV | grep -v "#" | grep ^orientationfilter | awk -F= '{print $2}') != "\"\"" ]]; then
      sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFH
      sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFV
      sync
    fi
  fi
  
  if [ -n "$autostart_arcade_tmp" ]; then
    autostart_arcade=$autostart_arcade_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "autostart_arcade=$autostart_arcade" >> $CONFIGFILE
    sed -i -e "s/autostart_arcade=.*/autostart_arcade=$autostart_arcade/g" "$CONFIGFILE"
    GENERATFLAG=1
    sync
  fi
  
  if [ -n "$autostart_rom_tmp" ]; then
    autostart_rom=$autostart_rom_tmp
  elif [ ! $(cat $CONFIGFILE | grep -v "^#" | grep autostart_rom) ]; then
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "autostart_rom=$autostart_rom" >> $CONFIGFILE
    sed -i -e "s/autostart_rom=.*/autostart_rom=$autostart_rom/g" "$CONFIGFILE"
    sync
  fi
  autostart_subdir=""
  if [[ "$autostart_rom" =~ .*/.* ]]; then
    autostart_subdir=$( echo "$autostart_rom" | awk -F/ '{print $1}' )
    autostart_rom=$( echo "$autostart_rom" | awk -F/ '{print $2}' )
  fi

  if [ -n "$screensaver_seconds_tmp" ]; then
    screensaver_seconds=$screensaver_seconds_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "screensaver_seconds=$screensaver_seconds" >> $CONFIGFILE
    sed -i -e "s/screensaver_seconds=.*/screensaver_seconds=$screensaver_seconds/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$status_messages_tmp" ]; then
    status_messages=$status_messages_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "status_messages=$status_messages" >> $CONFIGFILE
    sed -i -e "s/status_messages=.*/status_messages=$status_messages/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$quickedit_mode_tmp" ]; then
    quickedit_mode=$quickedit_mode_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "quickedit_mode=$quickedit_mode" >> $CONFIGFILE
    sed -i -e "s/quickedit_mode=.*/quickedit_mode=$quickedit_mode/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$preview_images_tmp" ]; then
    preview_images=$preview_images_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "preview_images=$preview_images" >> $CONFIGFILE
    sed -i -e "s/preview_images=.*/preview_images=$preview_images/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$preview_videos_tmp" ]; then
    preview_videos=$preview_videos_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "preview_videos=$preview_videos" >> $CONFIGFILE
    sed -i -e "s/preview_videos=.*/preview_videos=$preview_videos/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$preview_marquees_tmp" ]; then
    preview_marquees=$preview_marquees_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "preview_marquees=$preview_marquees" >> $CONFIGFILE
    sed -i -e "s/preview_marquees=.*/preview_marquees=$preview_marquees/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$preview_logos_tmp" ]; then
    preview_logos=$preview_logos_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "preview_logos=$preview_logos" >> $CONFIGFILE
    sed -i -e "s/preview_logos=.*/preview_logos=$preview_logos/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$hidden_seconds_tmp" ]; then
    hidden_seconds=$hidden_seconds_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "hidden_seconds=$hidden_seconds" >> $CONFIGFILE
    sed -i -e "s/hidden_seconds=.*/hidden_seconds=$hidden_seconds/g" "$CONFIGFILE"
    sync
  fi
  
  if [ -n "$video_delay_tmp" ]; then
    video_delay=$video_delay_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "video_delay=$video_delay" >> $CONFIGFILE
    sed -i -e "s/video_delay=.*/video_delay=$video_delay/g" "$CONFIGFILE"
    sync
  fi

  if ! grep -q "#pinHP#" "/usr/bin/omxplayer"; then
    sed -i '/OMXPlayer launcher script/ a sleep 2 #pinHP#' /usr/bin/omxplayer
  fi

  if [ -n "$pi2scart_mode_tmp" ]; then
    pi2scart_mode=$pi2scart_mode_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "pi2scart_mode=$pi2scart_mode" >> $CONFIGFILE
    sed -i -e "s/pi2scart_mode=.*/pi2scart_mode=$pi2scart_mode/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$favbutton_tmp" ]; then
    favbutton=$favbutton_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "favbutton=$favbutton" >> $CONFIGFILE
    sed -i -e "s/favbutton=.*/favbutton=$favbutton/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$date_mode_tmp" ]; then
    date_mode=$date_mode_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "date_mode=$date_mode" >> $CONFIGFILE
    sed -i -e "s/date_mode=.*/date_mode=$date_mode/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$keymap_1_tmp" ]; then
    keymap_1=$keymap_1_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "keymap_1=$keymap_1" >> $CONFIGFILE
    sed -i -e "s/keymap_1=.*/keymap_1=$keymap_1/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$keymap_2_tmp" ]; then
    keymap_2=$keymap_2_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "keymap_2=$keymap_2" >> $CONFIGFILE
    sed -i -e "s/keymap_2=.*/keymap_2=$keymap_2/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$keymap_3_tmp" ]; then
    keymap_3=$keymap_3_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "keymap_3=$keymap_3" >> $CONFIGFILE
    sed -i -e "s/keymap_3=.*/keymap_3=$keymap_3/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$current_keyboard_layout_tmp" ]; then
    current_keyboard_layout=$current_keyboard_layout_tmp
  else
    if ! grep ^current_keyboard_layout=.* "$CONFIGFILE"; then
      echo >> $CONFIGFILE
      echo >> $CONFIGFILE
      echo "current_keyboard_layout=current_keyboard_layout=$current_keyboard_layout" >> $CONFIGFILE
    fi
    sed -i -e "s/current_keyboard_layout=.*/current_keyboard_layout=$current_keyboard_layout/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$mail_alarm_tmp" ]; then
    mail_alarm=$mail_alarm_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "mail_alarm=$mail_alarm" >> $CONFIGFILE
    sed -i -e "s/mail_alarm=.*/mail_alarm=$mail_alarm/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$mame_buttons_tmp" ]; then
    mame_buttons=$mame_buttons_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "mame_buttons=$mame_buttons" >> $CONFIGFILE
    sed -i -e "s/mame_buttons=.*/mame_buttons=$mame_buttons/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$mame_buttons_timeout_tmp" ]; then
    mame_buttons_timeout=$mame_buttons_timeout_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "mame_buttons_timeout=$mame_buttons_timeout" >> $CONFIGFILE
    sed -i -e "s/mame_buttons_timeout=.*/mame_buttons_timeout=$mame_buttons_timeout/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$custom_folders_tmp" ]; then
    custom_folders=$custom_folders_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "custom_folders=$custom_folders" >> $CONFIGFILE
    sed -i -e "s/custom_folders=.*/custom_folders=$custom_folders/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$custom_favmenu_tmp" ]; then
    custom_favmenu=$custom_favmenu_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "custom_favmenu=$custom_favmenu" >> $CONFIGFILE
    sed -i -e "s/custom_favmenu=.*/custom_favmenu=$custom_favmenu/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$servostik_tmp" ]; then
    servostik=$servostik_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "servostik=$servostik" >> $CONFIGFILE
    sed -i -e "s/servostik=.*/servostik=$servostik/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$servostik_default_tmp" ]; then
    servostik_default=$servostik_default_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "servostik_default=$servostik_default" >> $CONFIGFILE
    sed -i -e "s/servostik_default=.*/servostik_default=$servostik_default/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$toggle_servostik_option_tmp" ]; then
    toggle_servostik_option=$toggle_servostik_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "toggle_servostik_option=$toggle_servostik_option" >> $CONFIGFILE
    sed -i -e "s/toggle_servostik_option=.*/toggle_servostik_option=$toggle_servostik_option/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$screensaver_option_tmp" ]; then
    screensaver_option=$screensaver_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "screensaver_option=$screensaver_option" >> $CONFIGFILE
    sed -i -e "s/screensaver_option=.*/screensaver_option=$screensaver_option/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$filter_games_option_tmp" ]; then
    filter_games_option=$filter_games_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "filter_games_option=$filter_games_option" >> $CONFIGFILE
    sed -i -e "s/filter_games_option=.*/filter_games_option=$filter_games_option/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$group_games_option_tmp" ]; then
    group_games_option=$group_games_option_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "group_games_option=$group_games_option" >> $CONFIGFILE
    sed -i -e "s/group_games_option=.*/group_games_option=$group_games_option/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$group_show_other_tmp" ]; then
    group_show_other=$group_show_other_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "group_show_other=$group_show_other" >> $CONFIGFILE
    sed -i -e "s/group_show_other=.*/group_show_other=$group_show_other/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$hide_mature_tmp" ]; then
    hide_mature=$hide_mature_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "hide_mature=$hide_mature" >> $CONFIGFILE
    sed -i -e "s/hide_mature=.*/hide_mature=$hide_mature/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$menu_text_size_tmp" ]; then
    menu_text_size=$menu_text_size_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "menu_text_size=$menu_text_size" >> $CONFIGFILE
    sed -i -e "s/menu_text_size=.*/menu_text_size=$menu_text_size/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$autostart_last_tmp" ]; then
    autostart_last=$autostart_last_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "autostart_last=$autostart_last" >> $CONFIGFILE
    sed -i -e "s/autostart_last=.*/autostart_last=$autostart_last/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$clone_joysticks_tmp" ]; then
    clone_joysticks=$clone_joysticks_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "clone_joysticks=$clone_joysticks" >> $CONFIGFILE
    sed -i -e "s/clone_joysticks=.*/clone_joysticks=$clone_joysticks/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$clone_buttons_tmp" ]; then
    clone_buttons=$clone_buttons_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "clone_buttons=$clone_buttons" >> $CONFIGFILE
    sed -i -e "s/clone_buttons=.*/clone_buttons=$clone_buttons/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$autorotate_gpio_tmp" ]; then
    autorotate_gpio=$autorotate_gpio_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "autorotate_gpio=$autorotate_gpio" >> $CONFIGFILE
    sed -i -e "s/autorotate_gpio=.*/autorotate_gpio=$autorotate_gpio/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$boot_into_gamelist_tmp" ]; then
    boot_into_gamelist=$boot_into_gamelist_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "boot_into_gamelist=$boot_into_gamelist" >> $CONFIGFILE
    sed -i -e "s/boot_into_gamelist=.*/boot_into_gamelist=$boot_into_gamelist/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$auto_insert_coin_tmp" ]; then
    auto_insert_coin=$auto_insert_coin_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "auto_insert_coin=$auto_insert_coin" >> $CONFIGFILE
    sed -i -e "s/auto_insert_coin=.*/auto_insert_coin=$auto_insert_coin/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$shutdown_dialog_tmp" ]; then
    shutdown_dialog=$shutdown_dialog_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "shutdown_dialog=$shutdown_dialog" >> $CONFIGFILE
    sed -i -e "s/shutdown_dialog=.*/shutdown_dialog=$shutdown_dialog/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$buttons_456_tmp" ]; then
    buttons_456=$buttons_456_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "buttons_456=$buttons_456" >> $CONFIGFILE
    sed -i -e "s/buttons_456=.*/buttons_456=$buttons_456/g" "$CONFIGFILE"
    sync
  fi

  if [ -n "$preview_videos_loop_tmp" ]; then
    preview_videos_loop=$preview_videos_loop_tmp
  else
    echo >> $CONFIGFILE
    echo >> $CONFIGFILE
    echo "preview_videos_loop=$preview_videos_loop" >> $CONFIGFILE
    sed -i -e "s/preview_videos_loop=.*/preview_videos_loop=$preview_videos_loop/g" "$CONFIGFILE"
    sync
  fi
}

read_mame_config ()
{

  # Default Mame settings
  display_flipx="no"
  display_flipy="no"
  horizontal_display_ror="no"
  horizontal_display_rol="no"
  vertical_display_ror="no"
  vertical_display_rol="yes"
  display_artwork_backdrop="no"
  display_artwork_overlay="yes"
  display_artwork_magnify="1"
  ll_flip="N"
  misc_cheat="no"
  input_idleexit=$screensaver_seconds
  display_vsync="yes"
  display_pausebrightness="0.5"
  display_brightness="1.0"
  display_gamma="1.0"
  sound_normalize="yes"
  sound_mode="auto"
  display_antialias="yes"
  misc_freeplay="no"
  misc_cocktail="no"
    
  # Read Mame settings from config file
  horizontal_display_rol_tmp=$(cat $MAMECONFIG | grep ^horizontal/display_rol | awk '{print $2}')
  vertical_display_rol_tmp=$(cat $MAMECONFIG | grep ^vertical/display_rol | awk '{print $2}')
  horizontal_display_ror_tmp=$(cat $MAMECONFIG | grep ^horizontal/display_ror | awk '{print $2}')
  vertical_display_ror_tmp=$(cat $MAMECONFIG | grep ^vertical/display_ror | awk '{print $2}')
  display_flipx_tmp=$(cat $MAMECONFIG | grep ^display_flipx | awk '{print $2}')
  display_flipy_tmp=$(cat $MAMECONFIG | grep ^display_flipy | awk '{print $2}')
  display_artwork_backdrop_tmp=$(cat $MAMECONFIG | grep ^display_artwork_backdrop | awk '{print $2}')
  display_artwork_overlay_tmp=$(cat $MAMECONFIG | grep ^display_artwork_overlay | awk '{print $2}')
  display_artwork_magnify_tmp=$(cat $MAMECONFIG | grep ^display_artwork_magnify | awk '{print $2}')
  ll_flip_tmp=$(cat $LLCONFH | grep ^rotate | awk -F= '{print $2}' | awk '{print $1}')
  display_vsync_tmp=$(cat $MAMECONFIG | grep ^display_vsync | awk '{print $2}')
  misc_cheat_tmp=$(cat $MAMECONFIG | grep ^misc_cheat | awk '{print $2}')
  input_idleexit_tmp=$(cat $MAMECONFIG | grep ^input_idleexit | awk '{print $2}')
  display_pausebrightness_tmp=$(cat $MAMECONFIG | grep ^display_pausebrightness | awk '{print $2}')
  display_brightness_tmp=$(cat $MAMECONFIG | grep ^display_brightness | awk '{print $2}')
  display_gamma_tmp=$(cat $MAMECONFIG | grep ^display_gamma | awk '{print $2}')
  sound_normalize_tmp=$(cat $MAMECONFIG | grep ^sound_normalize | awk '{print $2}')
  sound_mode_tmp=$(cat $MAMECONFIG | grep ^sound_mode | awk '{print $2}')
  display_antialias_tmp=$(cat $MAMECONFIG | grep ^display_antialias | awk '{print $2}')
  misc_freeplay_tmp=$(cat $MAMECONFIG | grep ^misc_freeplay | awk '{print $2}')
  misc_cocktail_tmp=$(cat $MAMECONFIG | grep ^misc_cocktail | awk '{print $2}')
 
  # Assign Mame config values to variables
  # If no entry is found, create it with default values 
  if [ -n "$horizontal_display_rol_tmp" ]; then
    horizontal_display_rol=$horizontal_display_rol_tmp
  elif ! grep ^horizontal/display_rol $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "horizontal/display_rol no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$vertical_display_rol_tmp" ]; then
    vertical_display_rol=$vertical_display_rol_tmp
  elif ! grep ^vertical/display_rol $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "vertical/display_rol yes" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$horizontal_display_ror_tmp" ]; then
    horizontal_display_ror=$horizontal_display_ror_tmp
  elif ! grep ^horizontal/display_ror $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "horizontal/display_ror no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$vertical_display_ror_tmp" ]; then
    vertical_display_ror=$vertical_display_ror_tmp
  elif ! grep ^vertical/display_ror $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "vertical/display_ror no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_flipx_tmp" ]; then
    display_flipx=$display_flipx_tmp
  elif ! grep ^display_flipx $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_flipx no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_flipy_tmp" ]; then
    display_flipy=$display_flipy_tmp
  elif ! grep ^display_flipy $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_flipy no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_artwork_backdrop_tmp" ]; then
    display_artwork_backdrop=$display_artwork_backdrop_tmp
  elif ! grep ^display_artwork_backdrop $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_artwork_backdrop no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_artwork_overlay_tmp" ]; then
    display_artwork_overlay=$display_artwork_overlay_tmp
  elif ! grep ^display_artwork_overlay $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_artwork_overlay yes" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_artwork_magnify_tmp" ]; then
    display_artwork_magnify=$display_artwork_magnify_tmp
  elif ! grep ^display_artwork_magnify $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_artwork_magnify 1" >> $MAMECONFIG
    sync
  fi
  
  if ! grep ^rotate $LLCONFH &> /dev/null; then
    echo >> $LLCONFH
    echo "rotate = none" >> $LLCONFH
    sync
  fi
  if ! grep ^rotate $LLCONFV &> /dev/null; then
    echo >> $LLCONFV
    echo "rotate = right" >> $LLCONFV
    sync
  fi
  
  if [ -n "$misc_cheat_tmp" ]; then
    misc_cheat=$misc_cheat_tmp
  elif ! grep ^misc_cheat $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "misc_cheat no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$input_idleexit_tmp" ]; then
    input_idleexit=$input_idleexit_tmp
  elif ! grep ^input_idleexit $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "input_idleexit $input_idleexit" >> $MAMECONFIG
    sync
  fi
  input_idleexit_seconds=$input_idleexit

  if [ -n "$display_vsync_tmp" ]; then
    display_vsync=$display_vsync_tmp
  elif ! grep ^display_vsync $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_vsync yes" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_pausebrightness_tmp" ]; then
    display_pausebrightness=$display_pausebrightness_tmp
  elif ! grep ^display_pausebrightness $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_pausebrightness 0.5" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_brightness_tmp" ]; then
    display_brightness=$display_brightness_tmp
  elif ! grep ^display_brightness $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_brightness 1.0" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_gamma_tmp" ]; then
    display_gamma=$display_gamma_tmp
    if [ "$display_gamma" != "1.0" ] && [ "$display_gamma" != "0.5" ] && [ "$display_gamma" != "1.5" ]; then
      unset custom_display_gamma
      custom_display_gamma=$display_gamma
    fi
  elif ! grep ^display_gamma $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_gamma 1.0" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$sound_normalize_tmp" ]; then
    sound_normalize=$sound_normalize_tmp
  elif ! grep ^sound_normalize $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "sound_normalize yes" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$sound_mode_tmp" ]; then
    sound_mode=$sound_mode_tmp
  elif ! grep ^sound_mode $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "sound_mode auto" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$display_antialias_tmp" ]; then
    display_antialias=$display_antialias_tmp
  elif ! grep ^display_antialias $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "display_antialias yes" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$misc_freeplay_tmp" ]; then
    misc_freeplay=$misc_freeplay_tmp
  elif ! grep ^misc_freeplay $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "misc_freeplay no" >> $MAMECONFIG
    sync
  fi
  
  if [ -n "$misc_cocktail_tmp" ]; then
    misc_cocktail=$misc_cocktail_tmp
  elif ! grep ^misc_cocktail $MAMECONFIG; then
    echo >> $MAMECONFIG
    echo "misc_cocktail no" >> $MAMECONFIG
    sync
  fi
}

read_ll_config ()
{
  # Preview video volume
  VIDEO_VOL_OFF="-6000" # 0 %
  VIDEO_VOL_LOW="-1648" # 15 %
  VIDEO_VOL_MID="-963" # 33 %
  VIDEO_VOL_HIGH="-141" # 85 %
  
  VIDEO_VOL_OFF_tmp=$(cat $LLCONFH | grep -m 1 VIDEO_VOL_OFF | awk -F= '{print $2}' | grep -o "\-\?[0-9]\+")
  VIDEO_VOL_LOW_tmp=$(cat $LLCONFH | grep -m 1 VIDEO_VOL_LOW | awk -F= '{print $2}' | grep -o "\-\?[0-9]\+")
  VIDEO_VOL_MID_tmp=$(cat $LLCONFH | grep -m 1 VIDEO_VOL_MID | awk -F= '{print $2}' | grep -o "\-\?[0-9]\+")
  VIDEO_VOL_HIGH_tmp=$(cat $LLCONFH | grep -m 1 VIDEO_VOL_HIGH | awk -F= '{print $2}' | grep -o "\-\?[0-9]\+")

  if [ -n "$VIDEO_VOL_OFF_tmp" ]; then
    VIDEO_VOL_OFF="$VIDEO_VOL_OFF_tmp"
  fi  
  if [ -n "$VIDEO_VOL_LOW_tmp" ]; then
    VIDEO_VOL_LOW="$VIDEO_VOL_LOW_tmp"
  fi  
  if [ -n "$VIDEO_VOL_MID_tmp" ]; then
    VIDEO_VOL_MID="$VIDEO_VOL_MID_tmp"
  fi  
  if [ -n "$VIDEO_VOL_HIGH_tmp" ]; then
    VIDEO_VOL_HIGH="$VIDEO_VOL_HIGH_tmp"
  fi  

  video_volume="$VIDEO_VOL_MID"
  if [ -f "/root/.lemonlauncher/bg/theme.conf" ]; then
    video_volume_tmp=$(cat "/root/.lemonlauncher/bg/theme.conf" | grep -v "#" | grep -m 1 video_volume | awk -F= '{print $2}' | grep -o "\-\?[0-9]\+")
  fi

  if [ -n "$video_volume_tmp" ]; then
    video_volume="$video_volume_tmp"
  fi

  ### Check config for missing features after Lemonlauncher 2.7 upgrade ###
  # Append video config to Lemonlauncher config
  if ! grep "^video =" "$LLCONFH" &> /dev/null; then
    cat "$DEFAULT/lemon_video_H.default" >> "$LLCONFH"
  fi
  if ! grep "^video =" "$LLCONFV" &> /dev/null; then
    cat "$DEFAULT/lemon_video_V.default" >> "$LLCONFV"
  fi
  # Append marquee config to Lemonlauncher config
  if ! grep "^marquee =" "$LLCONFH" &> /dev/null; then
    cat "$DEFAULT/lemon_marquee_H.default" >> "$LLCONFH"
  fi
  if ! grep "^marquee =" "$LLCONFV" &> /dev/null; then
    cat "$DEFAULT/lemon_marquee_V.default" >> "$LLCONFV"
  fi
  # Append fav button support to Lemonlauncher config
  if ! grep "^fav =" "$LLCONFH" &> /dev/null; then
    echo >> "$LLCONFH"
    echo "fav = 50   # 2   (p2-start)" >> "$LLCONFH"
  fi
  if ! grep "^fav =" "$LLCONFV" &> /dev/null; then
    echo >> "$LLCONFV"
    echo "fav = 50   # 2   (p2-start)" >> "$LLCONFV"
  fi
  # Disable Lemonlauncher screensaver
  if ! grep "^screensaver_time =" "$LLCONFH" &> /dev/null; then
    echo >> "$LLCONFH"
    echo "screensaver_time = 0" >> "$LLCONFH"
  fi
  if ! grep "^screensaver_time =" "$LLCONFV" &> /dev/null; then
    echo >> "$LLCONFV"
    echo "screensaver_time = 0" >> "$LLCONFV"
  fi  
  # Set Lemonlauncher screensaver video volume lowest
  if ! grep "^video_volume =" "$LLCONFH" &> /dev/null; then
    echo >> "$LLCONFH"
    echo "video_volume = -6000" >> "$LLCONFH"
  fi
  if ! grep "^video_volume =" "$LLCONFV" &> /dev/null; then
    echo >> "$LLCONFV"
    echo "video_volume = -6000" >> "$LLCONFV"
  fi  

  ### Check advmame.rc for correct directory settings ###
  # To force keeping edited lines, comment out system-generated lines and write edited lines BELOW
  advmame_rc_dir_rom="dir_rom /mnt/data/rpi2jamma/bios_advmame:/mnt/usb/rpi2jamma/bios_advmame:/root/.advance/rom"
  advmame_rc_dir_sample="dir_sample /mnt/data/rpi2jamma/samples_advmame:/mnt/usb/rpi2jamma/samples_advmame"
  advmame_rc_dir_artwork="dir_artwork /mnt/data/rpi2jamma/artwork_advmame:/mnt/usb/rpi2jamma/artwork_advmame"
  advmame_rc_dir_snap="dir_snap /root/.advance/snap"
  advmame_rc_dir_image="dir_image /mnt/data/rpi2jamma/image_advmame:/mnt/usb/rpi2jamma/image_advmame"
  advmame_rc_dir_diff="dir_diff /mnt/data/rpi2jamma/diff_advmame:/mnt/usb/rpi2jamma/diff_advmame"
  advmame_rc_dir_memcard="dir_memcard /mnt/data/rpi2jamma/memcard_advmame:/mnt/usb/rpi2jamma/memcard_advmame"
  advmame_rc_dir_sta="dir_sta /root/.advance/sta"
  if ! grep -Fxq "$advmame_rc_dir_rom" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_rom.*!$advmame_rc_dir_rom!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_sample" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_sample.*!$advmame_rc_dir_sample!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_artwork" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_artwork.*!$advmame_rc_dir_artwork!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_snap" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_snap.*!$advmame_rc_dir_snap!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_image" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_image.*!$advmame_rc_dir_image!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_diff" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_diff.*!$advmame_rc_dir_diff!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_memcard" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_memcard.*!$advmame_rc_dir_memcard!" $ADVMHOME/advmame.rc
  fi
  if ! grep -Fxq "$advmame_rc_dir_sta" $ADVMHOME/advmame.rc; then
    sed -i -e "s!^dir_sta.*!$advmame_rc_dir_sta!" $ADVMHOME/advmame.rc
  fi

  # Get USB gamepad name
  gamepad_current="Keyboard"
  gamepad_current_tmp=$(cat "/root/.lemonlauncher/lemonlauncher.conf" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    gamepad_current=$gamepad_current_tmp
  fi

  # Default
  GAMEPAD_1="Keyboard"
  GAMEPAD_2="SNES"
  GAMEPAD_3="PS3"
  GAMEPAD_4="Xbox 360"
  GAMEPAD_5="Xbox One"
  GAMEPAD_6="XinMotek"

  # Get USB gamepad name from ll config
  gamepad_tmp="Keyboard"
  gamepad_tmp=$(cat "/root/.lemonlauncher_common/gamepad_1.cfg" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    GAMEPAD_1=$gamepad_tmp
  fi

  gamepad_tmp="SNES"
  gamepad_tmp=$(cat "/root/.lemonlauncher_common/gamepad_2.cfg" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    GAMEPAD_2=$gamepad_tmp
  fi

  gamepad_tmp="PS3"
  gamepad_tmp=$(cat "/root/.lemonlauncher_common/gamepad_3.cfg" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    GAMEPAD_3=$gamepad_tmp
  fi

  gamepad_tmp="Xbox 360"
  gamepad_tmp=$(cat "/root/.lemonlauncher_common/gamepad_4.cfg" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    GAMEPAD_4=$gamepad_tmp
  fi

  gamepad_tmp="Xbox One"
  gamepad_tmp=$(cat "/root/.lemonlauncher_common/gamepad_5.cfg" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    GAMEPAD_5=$gamepad_tmp
  fi

  gamepad_tmp="XinMotek"
  gamepad_tmp=$(cat "/root/.lemonlauncher_common/gamepad_6.cfg" | grep -m 1 "pinHP USB gamepad" | awk -F# '{print $3}')
  if [ -n "$gamepad_current_tmp" ]; then
    GAMEPAD_6=$gamepad_tmp
  fi

  # Get menu text color
  menu_text_color=$( sed -n '/^list/,/^}/p' "/root/.lemonlauncher/theme.conf" | grep "\scolor =.*" | awk '{print $3}' )
  menu_highlight_color=$( sed -n '/^list/,/^}/p' "/root/.lemonlauncher/theme.conf" | grep "\shover_color =.*" | awk '{print $3}' )
  [ -z "$menu_text_color" ] && menu_text_color="0xffffff"
  [ -z "$menu_highlight_color" ] && menu_highlight_color="0x0b7cc1"

  # Get menu text alignment
  menu_text_justify=$( sed -n '/^list/,/^}/p' "/root/.lemonlauncher/theme.conf" | grep "\sjustify =.*" | awk '{print $3}' )
  [ -z "$menu_text_justify" ] && menu_text_justify="center"

}

run_mame ()
{
  # Run alarm mail script if set to ALWAYS
  if [ "$mail_alarm" = "Y" ]; then
    if grep -q "ALWAYS=Y" "$MAIL_DIR/config.ini"; then
      (bash "$SCRIPTS/mail_alarm.sh" "$MAIL_DIR" "$MAIL_PERMLOG" "$MAIL_TEMPLOG" &> /dev/null) &
    fi
  fi

  gameline=$( cat "$TEMPLATEFILE" | grep -m 1 "\"$rom"\" )
  gameline_title=$( echo "$gameline" | awk -F"\"" '{print $4}' )
  gameline_par=$( echo "$gameline" | awk -F"\"" '{print $6}' )
  gameline_orientation=$( echo "$gameline" | awk -F"\"" '{print $8}' )

  # ServoStik support
  if  [ "$servostik" = "Y" ]; then
    if ! [ -e /tmp/servostik_toggled ]; then
      bash "$SCRIPTS/switch_servostik.sh" "$gameline" "$servostik_default"
    else
      rm /tmp/servostik_toggled
    fi
  fi

  # Auto rotate screen / monitor
  if [ "$screen_orientation" = "A" ]; then
    ori=$( echo "$gameline_orientation" | tr '[:lower:]' '[:upper:]' )
    if [ "$status_messages" = "Y" ]; then
      echo "... Auto set screen orientation"
    fi
    if [ "$ori" != "$ORIENTATION" ] && [ "$ori" != "A" ]; then
      ORIENTATION="$ori"
      read_orientation_settings
      SCREEN_ROTATED="Y"
  	fi
    bash "$SCRIPTS/auto_rotate_monitor.sh" "$gameline_orientation" "$autorotate_gpio"
  fi

  # Check runscript-mame-before.sh
  if [ -e "$SCRIPTS/custom/runscript-mame-before.sh" ]; then
    chmod +x "$SCRIPTS/custom/runscript-mame-before.sh"
    declare -p > /tmp/pinhp_variables
    bash "$SCRIPTS/custom/runscript-mame-before.sh" "$rom" "$gameline_title" "$gameline_par" "$gameline_orientation" "$gameline" "$customscript_autostart_flag"
    cd /root
    setterm -cursor off
    if [ -e "/tmp/external_vars" ]; then
      source /tmp/external_vars
      rm /tmp/external_vars
    fi
  fi

  # Display button layout images  
  if [ "$mame_buttons" = "Y" ] && [ -e "$RPI2JAMMA/buttons/$rom.png" ] && [ "$customscript_autostart_flag" != "Y" ]; then

    # Bug: fbv does not run properly (quits immediately) at its very first start with Pi4
    # It is OK with Pi3, therefore the script needs to check and compensate
    if [ "$FBVRUN" = "Y" ]; then
      pikeyd165_start "anykey" "0.5"
    else
      pikeyd165_start "anykey" "1"
    fi
    joy2key_start "anykey"
    case $ORIENTATION in
      H )
        { printf 'f'; bash "$SCRIPTS/waitkey.sh" "$mame_buttons_timeout"; } | fbv -i "$RPI2JAMMA/buttons/$rom.png"
        if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$FBVRUN" != "Y" ]; then
          fbv -i "$RPI2JAMMA/buttons/$rom.png"
          { printf 'f'; bash "$SCRIPTS/waitkey.sh" "$mame_buttons_timeout"; } | fbv -i "$RPI2JAMMA/buttons/$rom.png"
        fi
      ;;   
      V )
        { printf 'nf'; bash "$SCRIPTS/waitkey.sh" "$mame_buttons_timeout"; } | fbv -i "$RPI2JAMMA/buttons/$rom.png"
        if grep -a "Raspberry Pi 4" < /sys/firmware/devicetree/base/model && [ "$FBVRUN" != "Y" ]; then
          fbv -i "$RPI2JAMMA/buttons/$rom.png"
          { printf 'nf'; bash "$SCRIPTS/waitkey.sh" "$mame_buttons_timeout"; } | fbv -i "$RPI2JAMMA/buttons/$rom.png"
        fi
      ;;    
    esac
    joy2key_stop
    FBVRUN="Y"
  fi

  # Run Mame game
  cd $ADVMHOME > /dev/null
  pikeyd165_start "default"
  clear
  echo
  echo
  /usr/bin/taskset -c 3 /root/local/bin/advmame "$rom" 2>&1 | tee "/tmp/mame_last_message"
  file "/tmp/mame_last_message" > /tmp/filetype
  if grep "ASCII" "/tmp/filetype" &> /dev/null; then
    mkdir "$RPI2JAMMA/_MAME_ERROR" &> /dev/null
    mv "/tmp/mame_last_message" "$RPI2JAMMA/_MAME_ERROR/$rom.txt"
    echo
    echo
    echo "--------"
    echo "Logfile:"
    echo "$RPI2JAMMA/_MAME_ERROR/$rom.txt"
    pikeyd165_start "anykey" "0.5"
    joy2key_start "anykey"
    maxwait=10
    for (( i = 1; i <= $maxwait; i++ ))
    do
      read -n 1 -t 1
      [ $? -eq 0 ] && break
    done
    joy2key_stop
  else
    rm "/tmp/mame_last_message" &> /dev/null
  fi
  rm "/tmp/filetype"  &> /dev/null
    
  # After game exit, make sure pinHP control settings are still present, which might have been deleted by Mame if COIN1 was manually set to "5"
  if ! grep -q "DO NOT EDIT THIS LINE" "$MAMECONFIG"; then
    sed -i '1 i\#\n' "$MAMECONFIG"
    
    case "$pi2scartmode_current" in
      Y )
        sed -i '1 i\# Pi2Scart mode --- DO NOT EDIT THIS LINE ---' "$MAMECONFIG"
      ;;
      N )
        sed -i '1 i\# Pi2Jamma mode --- DO NOT EDIT THIS LINE ---' "$MAMECONFIG"
      ;;
    esac
    
    if ! grep -q "^# mameconfig=." "$MAMECONFIG"; then
      sed -i "/--- DO NOT EDIT THIS LINE ---/a # mameconfig=$current_mameconfig" $MAMECONFIG
    fi

  fi

  if [ -e "$ADVMHOME/hi/$rom.hi" ]; then
    cp -vr $ADVMHOME/hi/$rom.hi $RPI2JAMMA/autobackup/hi/ &> /dev/null
  fi
  if [ -e "$ADVMHOME/nvram/$rom.nv" ]; then
    cp -vr $ADVMHOME/nvram/$rom.nv $RPI2JAMMA/autobackup/nvram/ &> /dev/null
  fi  
  
  lastgame="$rom"
  if [ "$autostart_last" = "Y" ]; then
    autostart_rom="$lastgame"
    gameline_local=$( cat "$CFGGAMES" | grep -m 1 "\"$rom"\" )
    gameline_par_local=$( echo "$gameline_local" | awk -F"\"" '{print $6}' )
    if [[ "$gameline_par_local" =~ .*MENUSUBDIR.* ]]; then
      subdir=$( echo "$gameline_par_local" | awk -F"$DLM" '{print $2}')
      autostart_rom="$subdir/$rom"
    fi
    sed -i -e 's/.*autostart_rom=.*/autostart_rom=/' "$CONFIGFILE"
    sed -i -e "s${DELIM}^autostart_rom=${DELIM}autostart_rom=$autostart_rom${DELIM}" "$CONFIGFILE"
  fi
  
  # Check runscript-mame-after.sh
  cd /root
  if [ -e "$SCRIPTS/custom/runscript-mame-after.sh" ]; then
    chmod +x "$SCRIPTS/custom/runscript-mame-after.sh"
    declare -p > /tmp/pinhp_variables
    bash "$SCRIPTS/custom/runscript-mame-after.sh" "$rom" "$gameline_title" "$gameline_par" "$gameline_orientation" "$gameline" "$customscript_autostart_flag"
    cd /root
    setterm -cursor off
    if [ -e "/tmp/external_vars" ]; then
      source /tmp/external_vars
      rm /tmp/external_vars
    fi
  fi

  # Kill alarm mail script
  if [ "$mail_alarm" = "Y" ]; then
    if grep -q "ALWAYS=Y" "$MAIL_DIR/config.ini"; then
      kill $(jobs -p) &> /dev/null
    fi
  fi
}

### Functions END ###

### Initialization BEGIN ###

SETTINGS="/root/settings"
SCRIPTS="/root/scripts"
DEFAULT="/root/default"

source "$SCRIPTS/filter_arrays.sh"

SETTINGS_H="$SETTINGS/settings_H"
SETTINGS_V="$SETTINGS/settings_V"
SETTINGS_HV="$SETTINGS/settings_HV"
FILTERFILE="$SETTINGS/_database.csv"
FILTEREDROMS="$SETTINGS/filteredroms"
GAMEFILTERS="$SETTINGS/gamefilters"
GAMEMENULAST="$SETTINGS/gamemenulast"
  
CFGGAMES="/root/.lemonlauncher_common/menu_main.conf"
CFGSYSTEM="/root/.lemonlauncher_common/menu_system.conf"
CFGFILTER="/root/.lemonlauncher_common/menu_filter.conf"
CFGGROUP="/root/.lemonlauncher_common/menu_group.conf"
CFGSETTINGS="/root/.lemonlauncher_common/menu_settings.conf"

ln -sf $CFGGAMES /root/.lemonlauncherH/games.conf
ln -sf $CFGGAMES /root/.lemonlauncherV/games.conf

ROMLIST="/tmp/romlist.txt"
CFGGAMESTMP1="/tmp/games1.conf"
CFGGAMESTMP2="/tmp/games2.conf"
CFGGAMESTMP3="/tmp/games3.conf"
CFGGAMESTMP="/tmp/games.conf"
CFGSYSTEMTMP="/tmp/system.conf"
CFGFILTERTMP="/tmp/filter.conf"
CFGGROUPTMP="/tmp/group.conf"
CFGMENUTMP="/tmp/submenu.conf"
CFGGAMESTMP_SUBDIR="/tmp/games_subdir.conf"
TEMPLATEGAMES1="/tmp/templategames1"
TEMPLATEGAMES2="/tmp/templategames2"
TEMPLATEGAMES3="/tmp/templategames3"
TEMPLATEGAMES="/tmp/templategames"
FILTEREDTEMPLATEGAMES="/tmp/filtered_templategames.tmp"

MENUTITLE1=$(cat "$CFGGAMES" | grep "^menu.*#MENU1" | awk -F'"' '{print $2}')
MENUTITLE2=$(cat "$CFGGAMES" | grep "^menu.*#MENU2" | awk -F'"' '{print $2}')
MENUTITLE3=$(cat "$CFGGAMES" | grep "^menu.*#MENU3" | awk -F'"' '{print $2}')
HIDDENCOUNT=0
CLEARED_HISCORES_FLAG=0

export PATH=$PATH:/opt/vc/bin/

clear
setterm -cursor off

# Let pikeyd165.conf reside in /tmp (RAM)
cp /root/pikeyd165_default.conf /tmp/pikeyd165.conf
ln -sf /tmp/pikeyd165.conf /etc/pikeyd165.conf

# Exit, if Lemonlauncher is already running
RUNNING=$(ps x | grep lemonlauncher | wc -l)
if [ "$RUNNING" -gt "1" ]; then
  echo "... Lemonlauncher already running"
  exit 0
fi

# Create default files if missing
if [ ! -e "$LANGUAGEFILE" ]; then
  cat "$DEFAULT/language.ini" > "$LANGUAGEFILE"
  sync
fi

if [ ! -e "$CONFIGFILE" ]; then
  cat "$DEFAULT/config.ini" > "$CONFIGFILE"
  sync
fi
# Remove Windows carriage returns
sed -i 's/\r//g' "$LANGUAGEFILE"
sed -i 's/\r//g' "$CONFIGFILE"

# Create default (no filters) game filter remember file
if [ ! -e "$GAMEFILTERS" ]; then
  for item in "${FILTER_ARRAY_CHOICE[@]}"
  do
    var_filter="filter_${item}"
    var_index="filter_${item}_index"
    declare $var_filter=""
    declare $var_index=0
  done
  filter_horizontal="N"
  filter_vertical="N"
  save_game_filters
fi

# Read initial pi2scart mode from SD config 
sd_pi2scart_mode=$(cat $CONFIGFILE | grep -v "#" | grep -m 1 pi2scart_mode= | awk -F= '{print $2}' | grep -o "[YNA]")

# Read current mame config number from or create default entry ("1") in advmame.rc
if ! grep -q "^# mameconfig=." "$MAMECONFIG"; then
  sed -i -e "/--- DO NOT EDIT THIS LINE ---/a # mameconfig=1" $MAMECONFIG
fi
current_mameconfig=$( grep -o "^# mameconfig=." "$MAMECONFIG" | awk -F= '{print $2}' )

# Is USB stick present? Yes -> mount | Assign $RPI2JAMMA directory

usb_test_sda=$(dmesg | grep sda )
usb_test_sda1=$(dmesg | grep sda1 )
[ "$usb_test_sda" ] && MOUNTED_USB="/dev/sda"
[ "$usb_test_sda1" ] && MOUNTED_USB="/dev/sda1"

if [ "$MOUNTED_USB" ]; then
  [ ! -e "$DIR_USB" ] && mkdir "$DIR_USB"
  mount $MOUNTED_USB $DIR_USB
  if [ -e "/root/_nousbdrive" ]; then
    rm "/root/_nousbdrive"
    cleanup_all
    dialog --timeout 5 --ok-label " Wait ... " --title "pinHP Arcade Classics" --msgbox "\nOne-time notification:\n\nUSB flash drive found.\nSwitching from SD to USB.\n\n" 0 0
  fi
  RPI2JAMMA="$DIR_USB/rpi2jamma"
else
  if [ ! -e "/root/_nousbdrive" ]; then
    touch /root/_nousbdrive
    cleanup_all
    dialog --timeout 5 --ok-label " Wait ... " --title "pinHP Arcade Classics" --msgbox "\nOne-time notification:\n\nMissing USB flash drive.\nSwitching to SD card.\n\n" 0 0
  fi 
  RUN_WITHOUT_USB="Y"
fi

# Make sure, for proper Lemonlauncher operation, to set "us" keymap
# (User defined keymaps will be set on a per-session basis when required)
localectl_keymap=$( localectl status | grep Keymap | awk "-F: " '{print $2}')
if [ "$localectl_keymap" != "us" ]; then
  localectl set-keymap --no-convert "us"
fi

# Variables not yet read from config.ini
switchtest_boot=$(cat $RPI2JAMMA/config.ini | grep -v "#" | grep -m 1 switchtest_boot= | awk -F= '{print $2}' | grep -o "[YN]")
force_hardwaremode=$(cat $RPI2JAMMA/config.ini | grep -v "#" | grep -m 1 force_hardwaremode= | awk -F= '{print $2}' | grep -o "[YN]")
disable_pikeyd165=$(cat $RPI2JAMMA/config.ini | grep -v "#" | grep -m 1 disable_pikeyd165= | awk -F= '{print $2}' | grep -o "[YN]")
pi2scart_mode=$(cat $RPI2JAMMA/config.ini | grep -v "#" | grep -m 1 pi2scart_mode= | awk -F= '{print $2}' | grep -o "[YNA]")

# Auto detect Jamma / SCART hardware mode
bash $SCRIPTS/check_pi2scart.sh "/tmp/pi2scart_mode_autodetected"
PI2SCART_MODE_DETECTED=$(cat "/tmp/pi2scart_mode_autodetected" )
pi2scartmode_current=$PI2SCART_MODE_DETECTED
[ "$force_hardwaremode" = "Y" ] && pi2scartmode_current=$pi2scart_mode
[ "$pi2scart_mode" = "A" ] && pi2scartmode_current="$PI2SCART_MODE_DETECTED"
rm /tmp/pi2scart_mode_autodetected

# Test for stuck Jamma switches
if [ "$pi2scartmode_current" = "N" ] && [ "$switchtest_boot" != "N" ]; then
  pikeyd165_start "switchtest" "0.5"
  SWITCHREPORT="/tmp/switchreport"
  SWITCHTEST_LOG="/tmp/switchboot.log"
  bash $SCRIPTS/jamma_switchtest_boot.sh "$SWITCHREPORT" "$SWITCHTEST_LOG"
  switchreport=$( sed -z 's/\n/\\n/g' "$SWITCHREPORT" )
  pikeyd165_stop
  if ! grep -q "none" "$SWITCHREPORT"; then
    cp /root/default/dialogrc_switchtest /tmp/.dialogrc
    export DIALOGRC=/tmp/.dialogrc
    dialog --no-cancel --ok-label "OK" --title "pinHP Arcade Classics" --pause "\n* POSSIBLY STUCK SWITCHES *\n\n$switchreport\nReport saved to:\n  rpi2jamma/switchboot.log\n\n" 0 0 9
    unset DIALOGRC
    pikeyd165_start "anykey" 0.5
    setterm -cursor off
    dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n* POSSIBLY STUCK SWITCHES *\n\n$switchreport\nReport saved to:\n  rpi2jamma/switchboot.log\n\n\n\n" 0 0
  fi
  clear
  [ -e "/tmp/switchboot.log" ] && mv -f "/tmp/switchboot.log" "$RPI2JAMMA"
fi

# Initialize USB directory in case it is missing (e. g. empty USB stick)
if [ "$RPI2JAMMA" = "$DIR_USB/rpi2jamma" ] && [ ! -e "$DIR_USB/rpi2jamma" ]; then
  clear
  pikeyd165_start "yesno"
  joy2key_start "yesno"
  dialog --timeout 15 --title "pinHP Arcade Classics" --yesno "\nUSB flash drive:\nMissing directory structure\n\nPreparing for first time use.\n\nThis takes several minutes -\nplease be patient ...\n\n" 0 0
  response=$?
  joy2key_stop
  clear
  if [ "$response" != "1" ]; then

    echo > /tmp/diskspacetemp
    clear
    echo
    echo
    echo "... Calculating disk space "
    # Write dots as progress indicator
    echo

    filecount=$( ls /mnt/data/rpi2jamma/roms_advmame | grep \.zip | wc -l )
    echo -n "... $filecount roms "
    (
      data_size_roms=$(du -c /mnt/data/rpi2jamma/roms_advmame | grep "total" | awk '{print $1}')
      echo "data_size_roms=$data_size_roms" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_roms / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/bios_advmame | grep \.zip | wc -l )
    echo -n "... $filecount bios "
    (
      data_size_bios=$(du -c /mnt/data/rpi2jamma/bios_advmame | grep "total" | awk '{print $1}')
      echo "data_size_bios=$data_size_bios" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_bios / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/snaps | grep \.png | wc -l )
    echo -n "... $filecount snaps "
    (
      data_size_snaps=$(du -c /mnt/data/rpi2jamma/snaps | grep "total" | awk '{print $1}')
      echo "data_size_snaps=$data_size_snaps" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_snaps / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/marquees | grep \.png | wc -l )
    echo -n "... $filecount marquees "
    (
      data_size_marquees=$(du -c /mnt/data/rpi2jamma/marquees | grep "total" | awk '{print $1}')
      echo "data_size_marquees=$data_size_marquees" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_marquees / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/logos | grep \.png | wc -l )
    echo -n "... $filecount logos "
    (
      data_size_logos=$(du -c /mnt/data/rpi2jamma/logos | grep "total" | awk '{print $1}')
      echo "data_size_logos=$data_size_logos" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_logos / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/buttons | grep \.png | wc -l )
    echo -n "... $filecount buttons "
    (
      data_size_buttons=$(du -c /mnt/data/rpi2jamma/buttons | grep "total" | awk '{print $1}')
      echo "data_size_buttons=$data_size_buttons" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_buttons / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/videos | grep \.mp4 | wc -l )
    echo -n "... $filecount videos "
    (
      data_size_videos=$(du -c /mnt/data/rpi2jamma/videos | grep "total" | awk '{print $1}')
      echo "data_size_videos=$data_size_videos" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_videos / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/artwork_advmame | grep \.zip | wc -l )
    echo -n "... $filecount artwork "
    (
      data_size_artwork=$(du -c /mnt/data/rpi2jamma/artwork_advmame | grep "total" | awk '{print $1}')
      echo "data_size_artwork=$data_size_artwork" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_artwork / 1024 )) MB"

    filecount=$( ls /mnt/data/rpi2jamma/samples_advmame | grep \.zip | wc -l )
    echo -n "... $filecount samples "
    (
      data_size_samples=$(du -c /mnt/data/rpi2jamma/samples_advmame | grep "total" | awk '{print $1}')
      echo "data_size_samples=$data_size_samples" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
      sleep 1.5
    done
    source /tmp/diskspacetemp
    echo " $(( data_size_samples / 1024 )) MB"

    data_size_sd=$(( data_size_roms + data_size_bios + data_size_snaps + data_size_marquees + data_size_logos + data_size_buttons + data_size_videos + data_size_artwork + data_size_samples ))
    # Add 100 MB overhead to be on the safe side
    data_size_sd=$(( data_size_sd + 102400 ))


    (
      usb_size_free=$(df | grep "/mnt/usb" | awk '{print $4}')
      echo "usb_size_free=$usb_size_free" >> /tmp/diskspacetemp
    ) &
    pid=$!
    while ps -a | awk '{print $1}' | grep -q "${pid}"
    do
      sleep 1
      echo -n "."
    done

    source /tmp/diskspacetemp
    data_size_sd_mb=$(( data_size_sd / 1024 ))
    usb_size_free_mb=$(( usb_size_free / 1024 ))
    echo
    echo
    echo "... Total copy: $data_size_sd_mb MB"
    sleep 1
    echo "... Free USB:  $usb_size_free_mb MB"
    sleep 2    

    if [ $usb_size_free -lt $data_size_sd ]; then
      dialog --timeout 5 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR ***\n\nTotal: $data_size_sd_mb MB\nFree:  $usb_size_free_mb MB\n\nNot enough space on USB\n\nAborting ...\n\n" 0 0
      RPI2JAMMA="$DIR_SD/rpi2jamma"
      RUN_WITHOUT_USB="Y"
      dialog --timeout 5 --title "pinHP Arcade Classics" --msgbox "\n*** USB NOT READY ***\n\nSwitching to SD card\n\n" 0 0
      clear
      echo
      echo
      echo "... Switching to SD card"
    else
      echo "... ok"
      sleep 1
      clear
      mkdir "$DIR_USB/rpi2jamma"
      cp "$DIR_SD/rpi2jamma/*" "$DIR_USB/rpi2jamma"
      cp -r "$DIR_SD/rpi2jamma/backup" "$DIR_USB/rpi2jamma/backup"
      mkdir "$DIR_USB/rpi2jamma/roms_advmame"
      touch "$DIR_USB/rpi2jamma/roms_advmame/_hidden_features_"
      cp "$DIR_USB/rpi2jamma/roms_advmame/_*" "$DIR_USB/rpi2jamma/roms_advmame"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/roms_advmame" "$DIR_USB/rpi2jamma/roms_advmame" "ROMs:" "\.zip"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/bios_advmame" "$DIR_USB/rpi2jamma/bios_advmame" "BIOS:" "\.zip"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/snaps" "$DIR_USB/rpi2jamma/snaps" "Snaps:" "\.png"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/logos" "$DIR_USB/rpi2jamma/logos" "Logos:" "\.png"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/buttons" "$DIR_USB/rpi2jamma/buttons" "Buttons:" "\.png"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/marquees" "$DIR_USB/rpi2jamma/marquees" "Marquees:" "\.png"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/videos" "$DIR_USB/rpi2jamma/videos" "Videos:" "\.mp4"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/samples_advmame" "$DIR_USB/rpi2jamma/samples_advmame" "Samples:" "\.zip"
      copy_gauge_dialog_overwrite "$DIR_SD/rpi2jamma/artwork_advmame" "$DIR_USB/rpi2jamma/artwork_advmame" "Artwork:" "\.zip"
      clear
      echo
      echo
      echo "... Switching to USB"
    fi

  else
    RPI2JAMMA="$DIR_SD/rpi2jamma"
    RUN_WITHOUT_USB="Y"
    [ $MOUNTED_USB ] && umount $MOUNTED_USB >& /dev/null
    clear
    echo
    echo
    echo "... Switching to SD card"
  fi
fi

ROMS_ADVM="$RPI2JAMMA/roms_advmame"
ROMS_UNUSED="$RPI2JAMMA/roms_unused"
CONFIGFILE="$RPI2JAMMA/config.ini"
LANGUAGEFILE="$RPI2JAMMA/language.ini"
HIDDENFEATURES="$RPI2JAMMA/roms_advmame/_hidden_features_"
MAIL_DIR="$RPI2JAMMA/.mail"
MAIL_PERMLOG="$MAIL_DIR/log.txt"
MAIL_TEMPLOG="/tmp/mail_status.txt"
TEMPLATEFILE="$ROMS_ADVM/_games.template"

# Create default files if missing
if [ ! -e "$LANGUAGEFILE" ]; then
  cat "$DEFAULT/language.ini" > "$LANGUAGEFILE"
  sync
fi

if [ ! -e "$CONFIGFILE" ]; then
  cat "$DEFAULT/config.ini" > "$CONFIGFILE"
  sync
fi
# Remove Windows carriage returns
sed -i 's/\r//g' "$LANGUAGEFILE"
sed -i 's/\r//g' "$CONFIGFILE"

# If there is a patch_pinhp_*.tgz file available on the USB stick, unpack and install it
PATCHREBOOT=0
install_patch

# Assign system directories and files, create if not exist
if [ -e "$ADVMHOME/rom" ]; then
  rm -r "$ADVMHOME/rom"
fi
ln -sfn "$RPI2JAMMA/roms_advmame" $ADVMHOME/rom
if [ -e "$ADVMHOME/snap" ]; then
  rm -r "$ADVMHOME/snap"
fi
ln -sfn "$RPI2JAMMA/snaps_advmame" $ADVMHOME/snap
if [ -e "$ADVMHOME/sta" ]; then
  rm -r "$ADVMHOME/sta"
fi
ln -sfn "$RPI2JAMMA/savestates_advmame" $ADVMHOME/sta

if [ ! -e "$ROMS_ADVM" ]; then
  mkdir -p "$ROMS_ADVM"
  cp -r $DEFAULT/roms/. $ROMS_ADVM
fi
if [ ! -e "$ROMS_UNUSED" ]; then
  mkdir -p "$ROMS_UNUSED"
fi
if [ ! -e "$RPI2JAMMA/snaps/" ]; then
  mkdir "$RPI2JAMMA/snaps/"
  cp -r $DEFAULT/snaps/. $RPI2JAMMA/snaps
fi
if [ ! -e "$RPI2JAMMA/marquees/" ]; then
  mkdir "$RPI2JAMMA/marquees/"
fi
if [ ! -e "$RPI2JAMMA/logos/" ]; then
  mkdir "$RPI2JAMMA/logos/"
fi
if [ ! -e "$RPI2JAMMA/videos/" ]; then
  mkdir "$RPI2JAMMA/videos/"
  cp -r $DEFAULT/videos/. $RPI2JAMMA/videos
fi
if [ ! -e "$RPI2JAMMA/samples_advmame/" ]; then
  mkdir "$RPI2JAMMA/samples_advmame/"
  cp -r $DEFAULT/samples/. $RPI2JAMMA/samples_advmame
fi
if [ ! -e "$CONFIGFILE" ]; then
  cat "$DEFAULT/config.default" > "$CONFIGFILE"
  sync
fi
if [ ! -e "$LANGUAGEFILE" ]; then
  cat "$DEFAULT/language.default" > "$LANGUAGEFILE"
  sync
fi
if [ ! -e "$RPI2JAMMA/snaps_advmame/" ]; then
  mkdir "$RPI2JAMMA/snaps_advmame/"
fi
if [ ! -e "$RPI2JAMMA/artwork_advmame/" ]; then
  mkdir "$RPI2JAMMA/artwork_advmame/"
fi
if [ ! -e "$RPI2JAMMA/buttons/" ]; then
  mkdir "$RPI2JAMMA/buttons/"
  cp -r $DEFAULT/buttons/. $RPI2JAMMA/buttons
fi
if [ ! -e "$RPI2JAMMA/diff_advmame/" ]; then
  mkdir "$RPI2JAMMA/diff_advmame/"
fi
if [ ! -e "$RPI2JAMMA/image_advmame/" ]; then
  mkdir "$RPI2JAMMA/image_advmame/"
fi
if [ ! -e "$RPI2JAMMA/memcard_advmame/" ]; then
  mkdir "$RPI2JAMMA/memcard_advmame/"
fi
if [ ! -e "$RPI2JAMMA/savestates_advmame/" ]; then
  mkdir "$RPI2JAMMA/savestates_advmame/"
fi
if [ ! -e "$RPI2JAMMA/bios_advmame" ]; then
  mkdir "$RPI2JAMMA/bios_advmame"
  # Copy bios directory from SD to USB 
  if [ "$RPI2JAMMA" = "$DIR_USB/rpi2jamma" ]; then
    cp -rv "$DIR_SD/rpi2jamma/bios_advmame" "$RPI2JAMMA" | awk '{print $3}'| awk -F'rpi2jamma' '{print $2}' | awk -F\' '{print $1}'
  fi
fi
if [ ! -e "$RPI2JAMMA/autobackup" ]; then
  mkdir "$RPI2JAMMA/autobackup"
fi
if [ ! -e "$RPI2JAMMA/autobackup/hi" ]; then
  mkdir "$RPI2JAMMA/autobackup/hi"
fi
if [ ! -e "$RPI2JAMMA/autobackup/nvram" ]; then
  mkdir "$RPI2JAMMA/autobackup/nvram"
fi
if [ ! -e "$RPI2JAMMA/autobackup/mame_config" ]; then
  mkdir "$RPI2JAMMA/autobackup/mame_config"
fi
if [ ! -e "$MAIL_DIR" ]; then
  mkdir -p "$MAIL_DIR"
fi
if [ ! -e "$MAIL_DIR/config.ini" ]; then
  cp "$DEFAULT/config.mail" "$MAIL_DIR/config.ini"
fi
if [ ! -e "$MAIL_DIR/lastactivity.txt" ]; then
  echo $EPOCHSECONDS > "$MAIL_DIR/lastactivity.txt"
fi
if [ ! -e "$MAIL_DIR/lastboot.txt" ]; then
  date > "$MAIL_DIR/lastboot.txt"
fi
if [ ! -e "$MAIL_DIR/log.txt" ]; then
  touch "$MAIL_DIR/log.txt"
fi
if [ ! -e "$MAIL_DIR/mail_alarm.txt" ]; then
  cp "$DEFAULT/mail_alarm.txt" "$MAIL_DIR/mail_alarm.txt"
fi
if [ ! -e "$MAIL_DIR/mail_start.txt" ]; then
  cp "$DEFAULT/mail_start.txt" "$MAIL_DIR/mail_start.txt"
fi
if [ ! -e "$MAIL_DIR/ssmtp.conf" ]; then
  cp "$DEFAULT/ssmtp.conf" "$MAIL_DIR/ssmtp.conf"
fi
ln -sf "$MAIL_DIR/ssmtp.conf" "/etc/ssmtp/ssmtp.conf"

# Remove Windows carriage returns
sed -i 's/\r//g' "$CONFIGFILE"
sed -i 's/\r//g' "$LANGUAGEFILE"

read_configfile

# Replace empty variable declarations ("") with space (" ")
sed -i "s${DELIM}=\"\"${DELIM}=\" \"${DELIM}g" "$LANGUAGEFILE"
source "$LANGUAGEFILE"

# Exit into shell
if [ "$autostart_arcade" = "N" ]; then
  pikeyd165_stop
  setterm -cursor on
  clear
  exit
fi

# Set system date
case $date_mode in
1 )
  date -s "$VERSION 12:34" > /dev/null
;;
2 )
  if [ -f "$DEFAULT/custom_boot_date.txt" ]; then
    custom_boot_date=$( cat "$DEFAULT/custom_boot_date.txt" )
    date -s "$custom_boot_date 12:34" > /dev/null
  else
    date -s "$VERSION 12:34" > /dev/null
  fi
;;
3 )
  if [ -f "$DEFAULT/last_shutdown_date.txt" ]; then
    last_shutdown_date=$( cat "$DEFAULT/last_shutdown_date.txt" )
    date -s "$last_shutdown_date" > /dev/null
  else
    date -s "$VERSION 12:34" > /dev/null
  fi
;;
esac

if [ "$sd_pi2scart_mode" != "$pi2scart_mode" ]; then
  sed -i -e "s/^pi2scart_mode=.*/pi2scart_mode=$pi2scart_mode/" "$DIR_SD/rpi2jamma/config.ini"
fi

check_pi2scart

if [ "$autostart_rom" = "screensaver" ]; then
  pikeyd165_start "anykey"
else
  pikeyd165_start "default"
fi
read_ll_config

# Initialize Lemonlauncher theme
if [ -e "/root/.lemonlauncherH/bg" ]; then
  rm -r "/root/.lemonlauncherH/bg"
fi
if [ -e "/root/.lemonlauncherV/bg" ]; then
  rm -r "/root/.lemonlauncherV/bg"
fi

for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
  do
    ln -sf "/root/.lemonlauncherH/bg$theme/theme_main.conf" "/root/.lemonlauncherH/bg$theme/theme.conf"
    ln -sf "/root/.lemonlauncherV/bg$theme/theme_main.conf" "/root/.lemonlauncherV/bg$theme/theme.conf"
  done

set_screen_theme

read_mame_config

ORIENTATION="H"
if [ "$screen_orientation" = "V" ]; then
  ORIENTATION="V"
fi

if [ ! -e "$SETTINGS_H" ]; then
  mkdir -p $SETTINGS
  touch $SETTINGS_H
fi
if [ ! -e "$SETTINGS_V" ]; then
  mkdir -p $SETTINGS
  touch $SETTINGS_V
fi

ln -sfn "$SETTINGS/settings_$ORIENTATION" "$SETTINGS_HV"
if [ ! -s "$SETTINGS_HV" ]; then
  save_orientation_settings
fi

if [ "$screen_orientation" = "A" ]; then
  ORIENTATION="$AUTOROTATE_DEFAULT"
  read_orientation_settings
fi 

# Display game preview images?
if [ "$preview_images" = "Y" ]; then
  ln -sfn "$RPI2JAMMA/snaps" /root/.lemonlauncher_common/lemonsnaps
else
  ln -sfn "/root/rpi2jamma/systemsnaps" /root/.lemonlauncher_common/lemonsnaps
fi

# Display game preview videos?
if [ "$preview_videos" = "Y" ]; then
  ln -sfn "$RPI2JAMMA/videos" /root/.lemonlauncher_common/lemonvideos
else
  ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonvideos
fi

# Enable game preview marquees if checked
if [ "$preview_marquees" = "Y" ]; then
  ln -sfn "$RPI2JAMMA/marquees" /root/.lemonlauncher_common/lemonmarquees
else
  ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
fi

# Enable game preview logos if checked
if [ "$preview_logos" = "Y" ]; then
  ln -sfn "$RPI2JAMMA/logos" /root/.lemonlauncher_common/lemonlogos
else
  ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
fi

# Check wi-fi auto connect
get_last_wifi_profile
autoconnect_wifi=$( ls /etc/systemd/system/multi-user.target.wants | grep netctl@ )

# Read game filters
if [ -e "$GAMEFILTERS" ]; then
  source $GAMEFILTERS &> /dev/null
fi

# Initialize and prepare to run Lemonlauncher
cd /root

# Force Game Menu Generation at very first image boot
if [ -e "/root/_first_start_" ]; then
  touch $HIDDENFEATURES
	cleanup_all
fi

# Switch off console blanking
setterm -blank 0

# Initialize Lemonlauncher background
ln -sf "/root/.lemonlauncherH/bg/backgroundH.png" /root/.lemonlauncherH/background.png
ln -sf "/root/.lemonlauncherV/bg/backgroundV.png" /root/.lemonlauncherV/background.png

# Set pinHP logo
cp $DEFAULT/pinhp.png $RPI2JAMMA/snaps

# Set back splash, if previously disabled for autostart game
if [ -z "$autostart_rom" ] || [ "$autostart_rom" = "screensaver" ]; then
  if [ ! -e $DEFAULT/splash.mp4 ]; then
    mv $DEFAULT/_splash.mp4 $DEFAULT/splash.mp4 &> /dev/null
  fi
fi

# If preview logos is checked, disable marquees unless theme = horizontal maxi
if [ "$preview_logos" = "Y" ]; then
  if [ "$ORIENTATION" != "H" ] || [ "$screen_theme" != "2" ]; then
    preview_marquees="N"
    ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
  fi
fi

set_lemon_configdir
set_video_options

if [ ! -e "$TEMPLATEFILE" ]; then
  cat "$DEFAULT/_games.template" > "$TEMPLATEFILE"
  sync
fi

if [ ! -e "$FILTERFILE" ]; then
  cat "$DEFAULT/_database.csv" > "$FILTERFILE"
  sync
fi

# Assign filter database column variables
grep "^Rom;" $FILTERFILE > /tmp/filterheader
col_genre=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Genre") print i}' "/tmp/filterheader")
col_year=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Year") print i}' "/tmp/filterheader")
col_manufacturer=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Manufacturer") print i}' "/tmp/filterheader")
col_system=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "System") print i}' "/tmp/filterheader")
col_clone=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Clone") print i}' "/tmp/filterheader")
col_recommended=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "AKNF") print i}' "/tmp/filterheader")
col_buttons=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Buttons") print i}' "/tmp/filterheader")
col_controls=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Controls") print i}' "/tmp/filterheader")
col_mature=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Genre") print i}' "/tmp/filterheader")
col_players=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Players") print i}' "/tmp/filterheader")
col_slow=$(awk -F';' '{for (i=1;i<=NF;i++) if($i == "Slow") print i}' "/tmp/filterheader")
rm /tmp/filterheader

# Force menu generation if checksum has changed
checksum_compare
if [ "$GENERATFLAG" = "1" ]; then
  set_video_options
  generate_game_menu
fi

clear_gameselect_flags

# Check for rom subdirs
if grep -q "MENUSUBDIR" $CONFIGFILE; then
  game_menu_dirs=0
fi

# Check for obsolete screen upside down settings
if [ "$ll_flip_tmp" = "flip" ]; then
  ll_flip="N"
  sed -i -e "s/title =\".*$TEXT_SCREEN_UPSIDE_DOWN/title =\"$TEXT_SCREEN_UPSIDE_DOWN/" $CFGSETTINGS
  pikeyd165_start "anykey"
  joy2key_start "anykey"
  dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n*** Attention ***\n\nScreen upside down settings\nneed to be refreshed.\n\nMake sure to check\nOptions > Screen Settings\n\n" 0 0
  joy2key_stop
fi

# Allow TAB into MAME menu only if pinHP menu is in admin mode
if [ -e "$HIDDENFEATURES" ]; then
  sed -i -e 's/^#input_map\[ui_configure\]/input_map\[ui_configure\]/' $MAMECONFIG
  sed -i -e 's/^#input_map\[ui_mode_next\]/input_map\[ui_mode_next\]/' $MAMECONFIG
  sed -i -e 's/^#input_map\[ui_mode_pred\]/input_map\[ui_mode_pred\]/' $MAMECONFIG
else
  sed -i -e 's/^input_map\[ui_configure\]/#input_map\[ui_configure\]/' $MAMECONFIG
  sed -i -e 's/^input_map\[ui_mode_next\]/#input_map\[ui_mode_next\]/' $MAMECONFIG
  sed -i -e 's/^input_map\[ui_mode_pred\]/#input_map\[ui_mode_pred\]/' $MAMECONFIG
fi

# Autostart a game or screensaver?
if [ -n "$autostart_rom" ]; then
  clear
  if [ "$autostart_rom" = "screensaver" ]; then
    screensaver_from_autostart="Y"
    screen_saver
  elif [ "$autostart_rom" = "advmenu" ]; then
    advmenu_rc_dir_snap="dir_snap $RPI2JAMMA/snaps"
    if ! grep -Fxq "$advmenu_rc_dir_snap" $ADVMHOME/advmame.rc; then
      sed -i -e "s!^dir_snap.*!$advmenu_rc_dir_snap!" $ADVMHOME/advmame.rc
    fi
    pikeyd165_start "advmenu"
    clear
    echo
    echo
    /usr/bin/taskset -c 3 /root/local/bin/advmenu    
    pikeyd165_start "default"
    if ! grep -Fxq "$advmame_rc_dir_snap" $ADVMHOME/advmame.rc; then
      sed -i -e "s!^dir_snap.*!$advmame_rc_dir_snap!" $ADVMHOME/advmame.rc
    fi
  else
    rom="$autostart_rom"
    # Wait for network, autostart game would exit if network connects during game
    if [ -n "$autoconnect_wifi" ]; then

      # Wait quietly max. 5 seconds
      secs=0
      no_internet=true
      clear
      current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
      while [ "$current_ip" = "" ];
      do
        sleep 1
        ((secs++))
        echo -n "."
        current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
        if [ "$secs" -gt "5" ]; then
          current_ip=false
        fi
      done
      clear

      # Wait max. 20 (default) more seconds for network
      secs=0
      no_internet=true
      clear
      current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
      if [ "$current_ip" = "" ]; then
        echo
        echo
        echo "... Waiting for network"
      fi
      while [ "$current_ip" = "" ];
      do
        sleep 1
        ((secs++))
        echo -n "."
        current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
        if [ "$secs" -gt "$AUTOSTART_GAME_NETWORK_TIMEOUT" ]; then
          current_ip=false
        fi
      done
      clear
    fi
    if [ -n "$autostart_subdir" ]; then
      advmrom_symlink=$( readlink -f $ADVMHOME/rom )
      if [ "$advmrom_symlink" != "$ROMS_ADVM/$autostart_subdir" ]; then
        ln -sfn "$ROMS_ADVM/$autostart_subdir" $ADVMHOME/rom
      fi
    fi

    customscript_autostart_flag="Y"
    run_mame

  fi
fi

# Set ServoStik 4-way
if [ "$servostik" = "Y" ]; then
  rm "/tmp/servostik_state" &> /dev/null
  bash "$SCRIPTS/switch_servostik.sh" "" "4" &> /dev/null
fi

# Very first image boot -> Ask to check hardware mode
if [ -e "/root/_first_start_" ]; then
  SECONDS=0
  pikeyd165_start "yesno"
  joy2key_start "yesno"
  dialog --timeout 60 --begin 5 4 --title "pinHP Arcade Classics" --yesno "\nThis is the first time you\nrun this version.\n\nMake sure to check your\nhardware mode (Jamma/SCART)\nfor proper operation.\n\nGo to\n\n> Options\n > Control Settings\n  > Hardware Mode\n\nDo you want to check now?" 19 32
  response=$?
  joy2key_stop
  if [ $SECONDS -le 1 ]; then
    force_pi2scart_dialog=1
  fi
  if [ $response -ne 1 ] || [ "$force_pi2scart_dialog" = "1" ]; then
    check_hardwaremode
    exit_systemmenu
  fi
  rm /root/_first_start_
fi

if [ -e "$SCRIPTS/custom/runscript-boot.sh" ]; then
  chmod +x "$SCRIPTS/custom/runscript-boot.sh"
  declare -p > /tmp/pinhp_variables
  bash "$SCRIPTS/custom/runscript-boot.sh"
  setterm -cursor off
  if [ -e "/tmp/external_vars" ]; then
    source /tmp/external_vars
    rm /tmp/external_vars
  fi
fi

if [ "$boot_into_gamelist" = "Y" ]; then
  hash_boot_game
fi

### Initialization END ###

###########################################

### Endless loop BEGIN ###

while [ 1 ]
do

  [ "$GENERATFLAG" = "1" ] && generate_game_menu 
  joy2key_stop
  cd /root
  clear
  if [ "$date_mode" = "3" ]; then
    date > "$DEFAULT/last_shutdown_date.txt"
  fi
  if [ "$ll_last" != "uptime" ]; then
    get_uptime
  fi
  ll_last=""

  pikeyd165_start "default" "0.3"

  # Run alarm mail script in background
  if [ "$mail_alarm" = "Y" ]; then
    (bash "$SCRIPTS/mail_alarm.sh" "$MAIL_DIR" "$MAIL_PERMLOG" "$MAIL_TEMPLOG" &> /dev/null) &
  fi

  if [ "$preview_videos_loop" = "Y" ]; then
    echo "--loop" > /tmp/omx_options
  else
    rm  /tmp/omx_options &> /dev/null
  fi

  # Make sure, for proper Lemonlauncher operation, to set "us" keymap 
  loadkeys "us"

  # Run Lemonlauncher ... Lemonlauncher waits for result (= a selected menu item)
  # 'timeout' command shuts down lemonlauncher to run screensaver
  lemonresult=$(timeout $screensaver_seconds lemonlauncher)
  timeout_retval=$?

  rm  /tmp/omx_options &> /dev/null

  # Kill alarm mail script
  if [ "$mail_alarm" = "Y" ]; then
    kill $(jobs -p) &> /dev/null
  fi

  # Screensaver auto activated
  if [ "$timeout_retval" = "124" ]; then
    result="timeout"
    par="screensaver"

  # Menu item selected - handle Lemonlauncher result
  else
    result=$(echo "$lemonresult" | grep "^Lemon" | awk '{print $4 " " $3}')
    rom=$(echo "$result" | awk '{print $2}')
    title=$(cat "$CFGGAMES" | grep -m 1 \""$rom"\" | awk -F= '{print $3}' | awk -F\" '{print $2}')
    par=$(echo "$result" | awk '{print $1}')
    if [[ "$lemonresult" =~ -.*SUBDIR.* ]]; then
      par=$( echo "$lemonresult" | awk '{$1=$2=$3=""; sub(/^ */,""); print $0}' )
    fi

    favbutton_flag="N"
    if [[ "$lemonresult" =~ .*Lemon_fav:.* ]]; then
      favbutton_flag="Y"
    fi

    if [ "$rom" = "_nogames" ]; then
      par="back_nogames"
    fi

    # Is a game selected?
    game_flag="N"
    if [[ "$par" =~ .*TRE.*ALL.*FAV.* ]]; then
      game_flag="Y"
    fi

    # Fav. Button (P2 Start) pressed?
    if [ "$favbutton_flag" = "Y" ]; then

      if [ "$SYSTEMMENU" = "1" ]; then
        result="dummy"
        par="dummy"

        case "$CURRENTMENU" in

          Filter )          
            filter_menu_back
          ;;
        
          Group )        
            group_menu_back
          ;;

          * )
            settings_menu_back
          ;;

        esac

      else
        case $favbutton in

          1 ) # Add to Fav.
            result="dummy"
            if [ "$game_flag" = "Y" ]; then
              if [ -e "$HIDDENFEATURES" ]; then
                quoterom="\""$rom"\""
                awk "/$quoterom/ {sub(\"-0FAV\",\"-1FAV\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
                addfav_flag=1
                generate_game_menu
                if [ "$quickedit_menu_markers" = "Y" ]; then
                  menu_mark_quickedit
                fi
                if [ "$custom_folders" = "Y" ]; then
                  par_menu=$( echo "$par" | grep -o "MENU.*$DLM.*$DLM" )
                  par_menu_dir=$( echo "$par_menu" | awk -F$DLM '{print $2}' )
                  currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#MENU_$par_menu_dir" )
                  currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                  currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                else
                  par_menu=$( echo "$par" | grep -o "MENU." )
                  currentmenu_tmp1=$( cat $CFGGAMES | grep "#$par_menu" )
                  currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                  currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                fi
                hash_menu="$currentmenu"
                hash_mark=""
                hash_rom="$rom"
                hash_title="$title"
                hash_par=$( echo "$par" | awk '{sub("0FAV","1FAV"); print}' )
                ll_hash
              fi
            else
              if [ "$par" = "uptime" ]; then
                get_uptime
                hash_menu="$menu_options"
                hash_mark=""
                hash_rom="pinhp"
                hash_title="$TEXT_UPTIME$uptime"
                hash_par="uptime"
                ll_last="uptime"
                ll_hash          
              fi
            fi
            par="dummy"
          ;;
  
          2 ) # Change orientation
            result="dummy"
            [ "$par" != "uptime" ] && par="dummy"
            case $ORIENTATION in
              H )
                ORIENTATION="V"
                if [ "$screen_orientation" = "A" ]; then
                  bash "$SCRIPTS/auto_rotate_monitor.sh" "$ORIENTATION" "$autorotate_gpio"
                else
                  screen_orientation="V"
                  sed -i -e 's/screen_orientation=./screen_orientation=V/' "$CONFIGFILE"
                  sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
                  sed -i -e "s/title =\".*$TEXT_ORIENTATION_V/title =\"\xB7$TEXT_ORIENTATION_V/" $CFGSETTINGS
                fi
              ;;
              V )
                ORIENTATION="H"
                if [ "$screen_orientation" = "A" ]; then
                  bash "$SCRIPTS/auto_rotate_monitor.sh" "$ORIENTATION" "$autorotate_gpio"
                else
                  screen_orientation="H"
                  sed -i -e 's/screen_orientation=./screen_orientation=H/' "$CONFIGFILE"
                  sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
                  sed -i -e "s/title =\".*$TEXT_ORIENTATION_H/title =\"\xB7$TEXT_ORIENTATION_H/" $CFGSETTINGS
                fi
              ;;
            esac
            read_orientation_settings
            bash "$SCRIPTS/auto_rotate_monitor.sh" "$screen_orientation" "$autorotate_gpio"
          ;;
  
          3 ) # Activate screensaver
            result="dummy"
            par="screensaver"
          ;;
  
          4 ) # Delete Game
            result="dummy"
            if [ "$game_flag" = "Y" ]; then
              if [ -e "$HIDDENFEATURES" ]; then
  
                # Does game ROM exist - ask to delete
                if [ -e "$ROMS_ADVM/$rom.zip" ]; then
                  pikeyd165_start "yesno"
                  joy2key_start "yesno"
                  dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nMove to \"roms_unused\"?\n\n$rom.zip\n\n" 0 0
                  response=$?
                  joy2key_stop
                  clear
    
                  if [ "$response" = "0" ]; then
    
                    # Move game to "roms_unused" directory
                    mkdir $ROMS_UNUSED &> /dev/null
                    mv $ROMS_ADVM/$rom.zip $ROMS_UNUSED
                    echo "$rom.zip" > $ROMS_ADVM/_last_deleted
                    if [ $(cat "$CONFIGFILE" | grep "autostart_rom" | grep "$rom") ]; then
                      sed -i -e "s/.*autostart_rom=.*/autostart_rom=/" "$CONFIGFILE"
                      autostart_rom=""
                    fi
    
                    if [ "$show_deleted_games" = "Y" ]; then
                      hash_menu="$currentmenu"
                      hash_mark=""
                      hash_rom="$rom"
                      hash_title="$TEXT_DELETED$title"
                      hash_par="$par"                  
                    else
                      # Get next game in current menu list
                      SORTEDGAMES="/tmp/sorted_games"
                      if [[ "$par" =~ ^-.*SUBDIR.* ]] && [ "$favmenu_deselect_flag" != "1" ]; then
                        par_menu=$( echo "$par" | grep -o "MENU.*$DLM.*$DLM" )
                        par_menu_dir=$( echo "$par_menu" | awk -F$DLM '{print $2}' )
                        currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#MENU_$par_menu_dir" )
                        currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                        currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                        hash_menu="$currentmenu"
                      else
                        par_menu=$( echo "$par" | grep -o "MENU." )
                        currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#$par_menu" )
                        currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                        currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                        hash_menu="$currentmenu"
                      fi        
                      if [ "$orientation_filter" = "N" ]; then           
                        grep -F "$par_menu" $CFGGAMES | grep ".FAV" | grep -o "title =.*" | sort > $SORTEDGAMES
                        nextline=$( grep -F -A1 "\"$title\"" $SORTEDGAMES | grep -F -v "\"$title\"" )
                      else
                        ori=$( echo "$screen_orientation" | tr '[:upper:]' '[:lower:]' )
                        ori_grep="\"[${ori}a]\""
                        grep -F "$par_menu" $CFGGAMES | grep ".FAV" | grep -o "title =.*" | grep "$ori_grep" | sort > $SORTEDGAMES
                        nextline=$( grep -F -A1 "\"$title\"" $SORTEDGAMES | grep -F -v "\"$title\"" )
                      fi
                      rm $SORTEDGAMES
                      nexttitle=$( echo "$nextline" | awk -F'"' '{print $2}' )
                      nextpar=$( echo "$nextline" | awk -F'"' '{print $4}' )
                      nextrom=$( grep -F -m 1 \""$nexttitle"\" $CFGGAMES | awk -F'"' '{print $2}' )
                      hash_menu="$currentmenu"
                      hash_mark=""
                      hash_rom="$nextrom"
                      hash_title="$nexttitle"
                      hash_par="$nextpar"
                    fi
                    ll_hash
                    
                    sed -i "s/rom =\"$rom\" title =\"/rom =\"$rom\" title =\"$TEXT_DELETED/g" "$CFGGAMES"
                  fi
  
                # Is game ROM already deleted - ask for restore
                elif [ -e "$ROMS_UNUSED/$rom.zip" ]; then
                  pikeyd165_start "yesno"
                  joy2key_start "yesno"
                  dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nRestore $rom.zip?\n\n" 0 0
                  response=$?
                  joy2key_stop
                  clear
                  if [ "$response" = "0" ]; then
                    mv $ROMS_UNUSED/$rom.zip $ROMS_ADVM
                    rm $ROMS_ADVM/_last_deleted &> /dev/null
                    if [[ "$par" =~ ^-.*SUBDIR.* ]] && [ "$favmenu_deselect_flag" != "1" ]; then
                      par_menu=$( echo "$par" | grep -o "MENU.*$DLM.*$DLM" )
                      par_menu_dir=$( echo "$par_menu" | awk -F$DLM '{print $2}' )
                      currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#MENU_$par_menu_dir" )
                      currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                      currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                      hash_menu="$currentmenu"
                    else
                      par_menu=$( echo "$par" | grep -o "MENU." )
                      currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#$par_menu" )
                      currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                      currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                      hash_menu="$currentmenu"
                    fi        
                    hash_menu="$currentmenu"
                    hash_mark=""
                    hash_rom="$rom"
                    hash_title=$( echo "$title" | awk -F"$TEXT_DELETED" '{print $2}' )
                    hash_par="$par"
                    ll_hash
                    sed -i "s/rom =\"$rom\" title =\"$TEXT_DELETED/rom =\"$rom\" title =\"/g" "$CFGGAMES"
                  fi
                fi
            
              else
                if [ "$par" = "uptime" ]; then
                  get_uptime
                  hash_menu="$menu_options"
                  hash_mark=""
                  hash_rom="pinhp"
                  hash_title="$TEXT_UPTIME$uptime"
                  hash_par="uptime"
                  ll_last="uptime"
                  ll_hash          
                fi
              fi
            fi
            par="dummy"
          ;;
  
          5 ) # Toggle ServoStik
            result="dummy"
            [ "$par" != "uptime" ] && par="dummy"
            if [ "$servostik" = "Y" ]; then
              bash "$SCRIPTS/toggle_servostik.sh" "$servostik_default"
              touch /tmp/servostik_toggled
            fi
          ;;

          6 ) # System Shutdown
            par="dummy"
            shutdown_system
          ;;

          7 ) # Quick Menu
            joy2key_start "updowntabenter"
            pikeyd165_start "updowntabenter" "0.8"
            result="dummy"
            [ "$par" != "uptime" ] && par="dummy"
            [ "$game_menu_dirs" = "1" ] && game_list_tag="* Alphabetical Game List" || game_list_tag="Alphabetical Game List" 
            [ "$status_messages" = "Y" ] && status_messages_tag="* Status Messages" || status_messages_tag="Status Messages" 

            if [ "$hardwaremode_current" = "Jamma" ]; then
              [ "$clone_joysticks" = "Y" ] && clone_joysticks_tag="* Clone Joysticks" || clone_joysticks_tag="Clone Joysticks"
              [ "$clone_buttons" = "Y" ] && clone_buttons_tag="* Clone Buttons" || clone_buttons_tag="Clone Buttons"
              if [ "$servostik" = "Y" ]; then
                quickmenu_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "1" --menu "\nChanges valid until reboot\n\nQuick menu action:\n" 18 33 1 1 "Screensaver" 2 "System Shutdown" 3 "$clone_joysticks_tag" 4 "$clone_buttons_tag" 5 "Rotate screen" 6 "$game_list_tag" 7 "$status_messages_tag" 8 "Toggle ServoStik" 3>&1 1>&2 2>&3)
              else
                quickmenu_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "1" --menu "\nChanges valid until reboot\n\nQuick menu action:\n" 17 33 1 1 "Screensaver" 2 "System Shutdown" 3 "$clone_joysticks_tag" 4 "$clone_buttons_tag" 5 "Rotate screen" 6 "$game_list_tag" 7 "$status_messages_tag"  3>&1 1>&2 2>&3)
              fi
            else
              if [ "$servostik" = "Y" ]; then
                quickmenu_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "1" --menu "\nChanges valid until reboot\n\nQuick menu action:\n" 16 33 1 1 "Screensaver" 2 "System Shutdown" 5 "Rotate screen" 6 "$game_list_tag" 7 "$status_messages_tag" 8 "Toggle ServoStik" 3>&1 1>&2 2>&3)
              else
                quickmenu_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "1" --menu "\nChanges valid until reboot\n\nQuick menu action:\n" 15 33 1 1 "Screensaver" 2 "System Shutdown" 5 "Rotate screen" 6 "$game_list_tag" 7 "$status_messages_tag"  3>&1 1>&2 2>&3)
              fi
            fi

            if [ ! -z $quickmenu_num ]; then
              case $quickmenu_num in
              
                1 ) # Quick Menu: Activate screensaver
                  par="screensaver"
                ;;
                
                2 ) # Quick Menu: System shutdown
                  shutdown_system
                ;;
                
                3 ) # Quick Menu: Clone joysticks
                  [ "$clone_joysticks" = "Y" ] && clone_joysticks="N" || clone_joysticks="Y"
                ;;            

                4 ) # Quick Menu: Clone buttons
                  [ "$clone_buttons" = "Y" ] && clone_buttons="N" || clone_buttons="Y"
                ;;            
  
                5 ) # Quick Menu: Change orientation
                  [ "$par" != "uptime" ] && par="dummy"
                  case $ORIENTATION in
                    H )
                      ORIENTATION="V"
                      if [ "$screen_orientation" = "A" ]; then
                        bash "$SCRIPTS/auto_rotate_monitor.sh" "$ORIENTATION" "$autorotate_gpio"
                      else
                        screen_orientation="V"
                        sed -i -e 's/screen_orientation=./screen_orientation=V/' "$CONFIGFILE"
                        sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
                        sed -i -e "s/title =\".*$TEXT_ORIENTATION_V/title =\"\xB7$TEXT_ORIENTATION_V/" $CFGSETTINGS
                      fi
                    ;;
                    V )
                      ORIENTATION="H"
                      if [ "$screen_orientation" = "A" ]; then
                        bash "$SCRIPTS/auto_rotate_monitor.sh" "$ORIENTATION" "$autorotate_gpio"
                      else
                        screen_orientation="H"
                        sed -i -e 's/screen_orientation=./screen_orientation=H/' "$CONFIGFILE"
                        sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
                        sed -i -e "s/title =\".*$TEXT_ORIENTATION_H/title =\"\xB7$TEXT_ORIENTATION_H/" $CFGSETTINGS
                      fi
                    ;;
                  esac
                  read_orientation_settings
                  bash "$SCRIPTS/auto_rotate_monitor.sh" "$screen_orientation" "$autorotate_gpio"
                ;;

                6 ) # Toggle games List
                  game_menu_dirs_saved=$(cat $CONFIGFILE | grep -m 1 ^game_menu_dirs= | awk -F= '{print $2}' | grep -o "[0-9]")
                  [ "$game_menu_dirs" = "$game_menu_dirs_saved" ] && game_menu_dirs=1 || game_menu_dirs="$game_menu_dirs_saved"
                  generate_game_menu
                  cleanup_all
                ;;

                7 )
                  clear
                  echo
                  echo
                  if [ "$status_messages" = "Y" ]; then
                    echo "... Status messages: OFF"
                    status_messages="N"
                  else
                    echo "... Status messages: ON"
                    status_messages="Y"
                  fi
                  sleep 1
                ;;

                8 ) # Quick Menu: Toggle ServoStik
                  if [ "$servostik" = "Y" ]; then
                    bash "$SCRIPTS/toggle_servostik.sh" "$servostik_default"
                    touch /tmp/servostik_toggled
                  fi
                ;;
               
              esac
            fi
            joy2key_stop          
          ;;
 
        esac
      fi
    fi
  fi 

  clear
  echo
  echo
  echo

### Lemonlauncher response - BEGIN ###

  # Valid Lemonlauncher response (else issue error message and shut down)
  if [ -n "$result" ]; then

    # USB stick removed?
    if [ "$RUN_WITHOUT_USB" != "Y" ] && [ ! -e "$DIR_USB/rpi2jamma" ]; then
      if [ "$par" != "screensaver" ] && [ "$par" != "reboot" ] && [ "$par" != "shutdown" ] && [ "$par" != "about" ] && [ "$par" != "exit_settings_menu" ]; then
        par="usb_error"
      fi
    fi

### Handle selected Lemonlauncher item BEGIN ###

    case $par in
    
      usb_error )
        echo "... USB device error"
        sleep 1
        echo
        echo "... rpi2jamma directory missing"
        sleep 3
      ;;

### Game has been selected BEGIN ###

      *-1FAV* | *-1ALL* | *-1ONE* | *-1TWO* | *-1TRE* )
        quickedit_changed=0
        quoterom="\""$rom"\""
        
        # Get next game in current menu list
        if [ "$favmenu_select_flag" = "1" ] || [ "$favmenu_deselect_flag" = "1" ] || [ "$secondmenu_select_flag" = "1" ] || [ "$secondmenu_deselect_flag" = "1" ] || [ "$set_4_8_way_flag" = "1" ]; then
          SORTEDGAMES="/tmp/sorted_games"
          if [[ "$par" =~ ^-.*SUBDIR.* ]] && [ "$favmenu_deselect_flag" != "1" ]; then
            par_menu=$( echo "$par" | grep -o "MENU.*$DLM.*$DLM" )
            par_menu_dir=$( echo "$par_menu" | awk -F$DLM '{print $2}' )
            currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#MENU_$par_menu_dir" )
            currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
            currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
            hash_menu="$currentmenu"
          else
            par_menu=$( echo "$par" | grep -o "MENU." )
            currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#$par_menu" )
            currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
            currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
            hash_menu="$currentmenu"
          fi        
          if [ "$orientation_filter" = "N" ]; then           
            if [ "$favmenu_deselect_flag" = "1" ] || [ "$secondmenu_deselect_flag" = "1" ]; then
              grep "MENU1" $CFGGAMES | grep ".FAV" | grep -v "(+)" | grep -o "title =.*" | sort > $SORTEDGAMES
            else
              grep -F "$par_menu" $CFGGAMES | grep ".FAV" | grep -v "MENU1" | grep -v "(+)" | grep -o "title =.*" | sort > $SORTEDGAMES
            fi
            nextline=$( grep -F -A1 "\"$title\"" $SORTEDGAMES | grep -F -v "\"$title\"" )
          else
            ori=$( echo "$screen_orientation" | tr '[:upper:]' '[:lower:]' )
            ori_grep="\"[${ori}a]\""
            if [ "$favmenu_deselect_flag" = "1" ] || [ "$secondmenu_deselect_flag" = "1" ]; then
              grep "MENU1" $CFGGAMES | grep ".FAV" | grep -v "(+)" | grep -o "title =.*" | grep "$ori_grep" | sort > $SORTEDGAMES
            else
              grep -F "$par_menu" $CFGGAMES | grep ".FAV" | grep -v "MENU1" | grep -v "(+)" | grep -o "title =.*" | grep "$ori_grep" | sort > $SORTEDGAMES
            fi
            nextline=$( grep -F -A1 "\"$title\"" $SORTEDGAMES | grep -F -v "\"$title\"" )
          fi
          rm $SORTEDGAMES
          nexttitle=$( echo "$nextline" | awk -F'"' '{print $2}' )
          nextpar=$( echo "$nextline" | awk -F'"' '{print $4}' )
          nextrom=$( grep -F -m 1 \""$nexttitle"\" $CFGGAMES | awk -F'"' '{print $2}' )
 
          # Default, if no next game available
          # Let Lemonlauncher jump to quickedit marker after game selection
          if [ "$quickedit_menu_markers" = "Y" ]; then
            case $par in
              *-MENU1* )
                hash_mark=""
                hash_title=" ### $TEXT_APPLY_CHANGES ### "
                hash_par="quickedit_apply"
                hash_rom="quickeditmode_menu1"
                ;;
              *-MENU2* )
                hash_mark=""
                hash_title=" ### $TEXT_APPLY_CHANGES ### "
                hash_par="quickedit_apply"
                hash_rom="quickeditmode_menu2"
                ;;
              *-MENU3* )
                hash_mark=""
                hash_title=" ### $TEXT_APPLY_CHANGES ### "
                hash_par="quickedit_apply"
                hash_rom="quickeditmode_menu3"
                ;;
              *-MENUSUBDIR* | *-MENUGROUPSUBDIR* )
                hash_mark=""
                hash_title=" ### $TEXT_APPLY_CHANGES ### "
                hash_par="quickedit_apply"
                hash_rom="quickeditmode_menusubdir"
                ;;
            esac
          fi
        fi

        # Prepare how to proceed with selected game according to flag
        gameflag=""
        [ "$favmenu_select_flag" = "1" ] && gameflag="favmenu_select"
        [ "$favmenu_deselect_flag" = "1" ] && gameflag="favmenu_deselect"
        [ "$secondmenu_select_flag" = "1" ] && gameflag="secondmenu_select"
        [ "$secondmenu_deselect_flag" = "1" ] && gameflag="secondmenu_deselect"
        [ "$autostart_game_flag" = "1" ] && gameflag="autostart_game"
        [ "$set_4_8_way_flag" = "1" ] && gameflag="set_4_8_way"

        case "$gameflag" in        

          # Add game to Fav. Menu
          favmenu_select )        
            if grep -q "$quoterom.*-0FAV" $TEMPLATEFILE || grep -q "$quoterom.*$FAVMARK" $CFGGAMES; then
              awk "/$quoterom/ {sub(\"-0FAV\",\"-1FAV\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
              if [ "$quickedit_mode" = "Y" ]; then
                if cat "$CFGGAMES" | grep "$quoterom" | grep \(+\) &> /dev/null; then
                  sed -i -e 's:'$quoterom' title ="'"$FAVMARK"':'$quoterom' title =":' $CFGGAMES
                  awk "/\"$rom\"/ {sub(\"-1FAV\",\"-0FAV\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
                else
                  par=${par/-.FAV/-1FAV}
                  sed -i -e 's:'$quoterom' title =":'$quoterom' title ="'"$FAVMARK"':' $CFGGAMES
                  hash_mark=""
                  if  ! [[ "$hash_menu" =~ "$MENUMARK" ]]; then 
                    hash_menu="$MENUMARK$hash_menu"
                  fi
                  if  [ -n "$nextline" ]; then
                    hash_title="$nexttitle"
                    hash_par="$nextpar"
                    hash_rom="$nextrom"
                  fi
                fi
  
                # Clear (+) from all game menus
                sed -i '/{ #MENU/s'"${DELIM}"'menu "(.*) '"${DELIM}"'menu "'"${DELIM}"'' $CFGGAMES
                # Scan $CFGGAMES, list game menu titles
                if [[ "$par" =~ ^-.*SUBDIR.* ]]; then
                  cat $CFGGAMES | grep "{ #MENU" | grep -v "#MENU1" | awk -F'#MENU_' '{print $2}' > /tmp/gamemenu_list
                else
                  if [ "$game_menu_dirs" = "1" ]; then
                    cat $CFGGAMES | grep "{ #MENU" | awk -F'" {' '{print $1}' | awk -F'menu "' '{print $2}' > /tmp/gamemenu_list
                  else
                    cat $CFGGAMES | grep "{ #MENU" | grep -v "#MENU1" | awk -F'" {' '{print $1}' | awk -F'menu "' '{print $2}' > /tmp/gamemenu_list
                  fi
                fi
                # Iterate over game menus, mark (+) if it contains a (+) marked game
                while read currentmenu
                do
                  if [[ "$par" =~ ^-.*SUBDIR.* ]]; then
                    currentmenu_grep="$DLM$currentmenu$DLM"
                  else
                    currentmenu_num=$( cat $CFGGAMES | grep "{ #MENU" | grep "$currentmenu" | awk -F'" { #' '{print $2}' )
                    currentmenu_grep="$currentmenu_num"
                  fi
                  games_marked_count=$( cat $CFGGAMES | grep "game { rom" | grep "$currentmenu_grep" | grep "$FAVMARK" | wc -l )
                  if [ "$games_marked_count" -gt 0 ]; then
                    if [[ "$par" =~ ^-.*SUBDIR.* ]]; then
                      sed -i '/{ #MENU_'"$currentmenu"'/s'"${DELIM}"'^menu "'"${DELIM}"'menu "'"$MENUMARK"''"${DELIM}"'' $CFGGAMES
                    else
                      sed -i '/'"$currentmenu"'.*{ #MENU/s'"${DELIM}"'^menu "'"${DELIM}"'menu "'"$MENUMARK"''"${DELIM}"'' $CFGGAMES
                    fi
                  fi
                done < /tmp/gamemenu_list
   
                ll_hash
                quickedit_changed=1
              else
                addfav_flag=1
                generate_game_menu
              fi
            fi
            cleanup_all
          ;;
  
          # Remove game from Fav. Menu
          favmenu_deselect )
            awk "/$quoterom/ {sub(\"-1FAV\",\"-0FAV\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
            if [ "$quickedit_mode" = "Y" ]; then
              if cat "$CFGGAMES" | grep "$quoterom" | grep \(-\) &> /dev/null; then
                sed -i -e 's:'$quoterom' title ="  (-) :'$quoterom' title =":' $CFGGAMES
                awk "/\"$rom\"/ {sub(\"-0FAV\",\"-1FAV\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
              else
                par=${par/-.FAV/-0FAV}
                sed -i -e 's:'$quoterom' title =":'$quoterom' title ="  (-) :' $CFGGAMES
                hash_mark=""
                if  [ -n "$nextline" ]; then
                  hash_title="$nexttitle"
                  hash_par="$nextpar"
                  hash_rom="$nextrom"
                fi
              fi
              ll_hash
              quickedit_changed=1
            else
              generate_game_menu
            fi
            cleanup_all
          ;;
  
          # Add game to Second Menu
          secondmenu_select )
            if grep -q "$quoterom.*-0TWO" $TEMPLATEFILE || grep -q "$quoterom.*$FAVMARK" $CFGGAMES; then
              awk "/$quoterom/ {sub(\"-0TWO\",\"-1TWO\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
              if [ "$quickedit_mode" = "Y" ]; then
                if cat "$CFGGAMES" | grep "$quoterom" | grep \(+\) &> /dev/null; then
                  sed -i -e 's:'$quoterom' title ="'"$FAVMARK"':'$quoterom' title =":' $CFGGAMES
                  awk "/\"$rom\"/ {sub(\"-1TWO\",\"-0TWO\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
                else
                  par=${par/-.TWO/-1TWO}
                  sed -i -e 's:'$quoterom' title =":'$quoterom' title ="'"$FAVMARK"':' $CFGGAMES
                  hash_mark=""
                  if  ! [[ "$hash_menu" =~ "$MENUMARK" ]]; then 
                    hash_menu="$MENUMARK$hash_menu"
                  fi
                  if  [ -n "$nextline" ]; then
                    hash_title="$nexttitle"
                    hash_par="$nextpar"
                    hash_rom="$nextrom"
                  fi
                fi
  
                # Clear (+) from all game menus. No need to bother about custom folders, 2nd Menu is not available with custom folders
                sed -i '/{ #MENU/s'"${DELIM}"'menu "(.*) '"${DELIM}"'menu "'"${DELIM}"'' $CFGGAMES
                # Scan $CFGGAMES, list game menu titles
                cat $CFGGAMES | grep "{ #MENU" | grep -v "#MENU2" | awk -F'" {' '{print $1}' | awk -F'menu "' '{print $2}' > /tmp/gamemenu_list
                # Iterate over game menus, mark (+) if it contains a (+) marked game
                while read currentmenu
                do
                  currentmenu_num=$( cat $CFGGAMES | grep "{ #MENU" | grep "$currentmenu" | awk -F'" { #' '{print $2}' )
                  currentmenu_grep="$currentmenu_num"
                  games_marked_count=$( cat $CFGGAMES | grep "game { rom" | grep "$currentmenu_grep" | grep "$FAVMARK" | wc -l )
                  if [ "$games_marked_count" -gt 0 ]; then
                    if [[ "$par" =~ ^-.*SUBDIR.* ]]; then
                      sed -i '/{ #MENU_'"$currentmenu"'/s'"${DELIM}"'^menu "'"${DELIM}"'menu "'"$MENUMARK"''"${DELIM}"'' $CFGGAMES
                    else
                      sed -i '/'"$currentmenu"'.*{ #MENU/s'"${DELIM}"'^menu "'"${DELIM}"'menu "'"$MENUMARK"''"${DELIM}"'' $CFGGAMES
                    fi
                  fi
                done < /tmp/gamemenu_list
  
                ll_hash
                quickedit_changed=1
              else
                addfav_flag=1
                generate_game_menu
              fi
            fi
            cleanup_all
          ;;
  
          # Remove game from Second Menu
          secondmenu_deselect )
            awk "/$quoterom/ {sub(\"-1TWO\",\"-0TWO\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
            if [ "$quickedit_mode" = "Y" ]; then
              if cat "$CFGGAMES" | grep "$quoterom" | grep \(-\) &> /dev/null; then
                sed -i -e 's:'$quoterom' title ="  (-) :'$quoterom' title =":' $CFGGAMES
                awk "/\"$rom\"/ {sub(\"-0TWO\",\"-1TWO\")}1" $TEMPLATEFILE > /tmp/temp.txt && mv /tmp/temp.txt $TEMPLATEFILE
              else
                par=${par/-.TWO/-0TWO}
                sed -i -e 's:'$quoterom' title =":'$quoterom' title ="  (-) :' $CFGGAMES
                hash_mark=""
                if  [ -n "$nextline" ]; then
                  hash_title="$nexttitle"
                  hash_par="$nextpar"
                  hash_rom="$nextrom"
                fi
              fi
              ll_hash
              quickedit_changed=1
            else
              generate_game_menu
            fi
            cleanup_all
          ;;
  
          # Set autostart game
          autostart_game )
            clear_gameselect_flags
            no_autostart_markers
            autostart_rom="$rom"
            if [[ "$par" =~ .*MENUSUBDIR.* ]]; then
              subdir=$( echo "$lemonresult" | awk -F"$DLM" '{print $2}')
              autostart_rom="$subdir/$rom"
            fi
            sed -i -e 's/.*autostart_rom=.*/autostart_rom=/' "$CONFIGFILE"
            sed -i -e "s${DELIM}^autostart_rom=${DELIM}autostart_rom=$autostart_rom${DELIM}" "$CONFIGFILE"
            ln -sf "/root/.lemonlauncherH/bg/backgroundH.png" /root/.lemonlauncherH/background.png
            ln -sf "/root/.lemonlauncherV/bg/backgroundV.png" /root/.lemonlauncherV/background.png
            sed -i -e "s/title =\".*$TEXT_AUTOSTART_GAME\"/title =\"\xB7$TEXT_AUTOSTART: \'$rom\'\"/" $CFGGAMES
            if [ "$input_idleexit_seconds" -ne 0 ]; then
              input_idleexit_seconds="0"
              sed -i -e "s/input_idleexit.*/input_idleexit 0/" $MAMECONFIG
              pikeyd165_start "anykey"
              joy2key_start "anykey"
              dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\nMAME \"idle exit\"\nis disabled now.\n\nYou can always re-enable it:\n\n>System Settings Menu\n  >Mame Settings\n    >Idle Exit\n" 0 0
              joy2key_stop
            fi
            mv $DEFAULT/splash.mp4 $DEFAULT/_splash.mp4 &> /dev/null
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_AUTOSTART: '$rom'"
            hash_par="autostart_game"
            hash_rom="pinhp"
            ll_hash
            autostart_last="N"
            sed -i "s/.*autostart_last=.*/autostart_last=$autostart_last/" "$CONFIGFILE"
            generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
          ;;
  
          # Add joystick 4-way parameter to game
          set_4_8_way )
            gameline=$( cat "$TEMPLATEFILE" | grep -m 1 "\"$rom"\" )
            gameline_title=$( echo "$gameline" | awk -F"\"" '{print $4}' )
            joy_par=$( echo "$gameline" | awk -F'joy ?= ?"' '{print $2}' | awk -F'"' '{print $1}' | grep -o ^[48]$ )
  
            display_title=$( cat "$CFGGAMES" | grep -m 1 "\"$rom"\" | awk -F"\"" '{print $4}' )
            if [[ "$display_title" =~ \(.\).* ]] || [ -z "$joy_par" ]; then

            case "$joy_par" in
                4 )
                  joy_par=8
                  sed -i -e '/'"$quoterom"'/s/joy \?= \?\"."/joy ="8"/' $TEMPLATEFILE
                ;;
                8 )
                  joy_par="-"
                  sed -i -e '/'"$quoterom"'/s/ joy \?= \?\"."//g' $TEMPLATEFILE
                ;;
                * )
                  joy_par=4
                  sed -i -e '/'"$quoterom"'/s/ joy \?= \?\".\?"//g' $TEMPLATEFILE
                  sed -i -e '/'"$quoterom"'/s/.*orientation ="."/& joy ="4"/' $TEMPLATEFILE
                ;;
              esac
              sed -i -e '/'"$quoterom"'/s/title ="(.) /title ="/g' $CFGGAMES
              sed -i -e '/'"$quoterom"'/s/.*title ="/&('"$joy_par"') /g' $CFGGAMES
              
            else
              sed -i -e '/'"$quoterom"'/s/.*title ="/&('"$joy_par"') /g' $CFGGAMES
            fi
  
            title=$(cat "$CFGGAMES" | grep -m1 "$quoterom" | awk -F"\"" '{print $4}' )
            hash_title="$title"
            hash_par="$par"
            hash_rom="$rom"
            ll_hash
            quickedit_changed=1
            cleanup_all
          ;;
  
          # Finally, prepare ro run MAME game
          * )
            if [ "$status_messages" = "Y" ]; then
              echo "... $rom"
              sleep 1
            fi
            bash "$SCRIPTS/killomx.sh" & 

            # Check if game was just deleted - ask to restore
            if [[ "$title" =~ "$TEXT_DELETED" ]] && [ -e "$ROMS_UNUSED/$rom.zip" ]; then

              pikeyd165_start "yesno"
              joy2key_start "yesno"
              dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nRestore $rom.zip?\n\n" 0 0
              response=$?
              joy2key_stop
              clear
              if [ "$response" = "0" ]; then
                mv $ROMS_UNUSED/$rom.zip $ROMS_ADVM
                rm $ROMS_ADVM/_last_deleted &> /dev/null
                if [[ "$par" =~ ^-.*SUBDIR.* ]] && [ "$favmenu_deselect_flag" != "1" ]; then
                  par_menu=$( echo "$par" | grep -o "MENU.*$DLM.*$DLM" )
                  par_menu_dir=$( echo "$par_menu" | awk -F$DLM '{print $2}' )
                  currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#MENU_$par_menu_dir" )
                  currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                  currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                  hash_menu="$currentmenu"
                else
                  par_menu=$( echo "$par" | grep -o "MENU." )
                  currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#$par_menu" )
                  currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                  currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                  hash_menu="$currentmenu"
                fi        
                hash_menu="$currentmenu"
                hash_mark=""
                hash_rom="$rom"
                hash_title=$( echo "$title" | awk -F"$TEXT_DELETED" '{print $2}' )
                hash_par="$par"
                ll_hash
                sed -i "s/rom =\"$rom\" title =\"$TEXT_DELETED/rom =\"$rom\" title =\"/g" "$CFGGAMES"
              fi

            # No, not just deleted
            else
  
              advmrom_symlink=$( readlink -f $ADVMHOME/rom )
              if [[ "$par" =~ .*MENUSUBDIR.* ]]; then
                subdir=$( echo "$lemonresult" | awk -F"$DLM" '{print $2}')
                if [ "$advmrom_symlink" != "$ROMS_ADVM/$subdir" ]; then
                  ln -sfn "$ROMS_ADVM/$subdir" $ADVMHOME/rom
                fi
              else
                if [ "$advmrom_symlink" != "$ROMS_ADVM" ]; then
                  ln -sfn "$ROMS_ADVM" $ADVMHOME/rom
                fi
              fi
  
              customscript_autostart_flag="N"
              run_mame

              # After auto screen rotation, keep cursor at game just played
              if [ "$SCREEN_ROTATED" = "Y" ]; then
                SCREEN_ROTATED="N"
                [ "$GENERATFLAG" = "1" ] && generate_game_menu 
                if [[ "$par" =~ ^-.*SUBDIR.* ]]; then
                  par_menu=$( echo "$par" | grep -o "MENU.*$DLM.*$DLM" )
                  par_menu_dir=$( echo "$par_menu" | awk -F$DLM '{print $2}' )
                  par_gamelinegrep="$par_menu_dir"
                  currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#MENU_$par_menu_dir" )
                  currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                  currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                else
                  par_menu=$( echo "$par" | grep -o "MENU." )
                  par_gamelinegrep="$par_menu"
                  currentmenu_tmp1=$( cat $CFGGAMES | grep -F "#$par_menu" )
                  currentmenu_tmp2=$( echo "$currentmenu_tmp1" | awk -F"menu \"" '{print $2'} )
                  currentmenu=$( echo "$currentmenu_tmp2" | awk -F"\" {" '{print $1'} )
                fi        
                gameline=$( cat "$CFGGAMES" | grep "$par_gamelinegrep" | grep -m 1 "\"$rom"\" )
                gameline_title=$( echo "$gameline" | awk -F"\"" '{print $4}' )
                gameline_par=$( echo "$gameline" | awk -F"\"" '{print $6}' )
                hash_mark=""
                hash_menu="$currentmenu"
                hash_rom="$rom"
                hash_title="$gameline_title"
                hash_par="$gameline_par"
                ll_hash
              fi

            fi
          ;;

        esac
        sync
      ;;

### Game has been selected END ###

### Generate settings sub menus BEGIN ###

      enter_game_settings_menu )
        hash_menu="$TEXT_GAME_MENU_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_game_settings_menu.sh"
      ;;

      enter_options_settings_menu )
        hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_options_settings_menu.sh"
      ;;

      enter_language_settings_menu )
        hash_menu="$TEXT_LANGUAGE_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_language_settings_menu.sh"
      ;;

      enter_backup_restore_menu )
        hash_menu="$TEXT_BACKUP_RESTORE"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_backup_restore_menu.sh"
      ;;

      enter_mame_settings_menu )
        hash_menu="$TEXT_MAME_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      enter_control_settings_menu )
        hash_menu="$TEXT_CONTROL_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
      ;;

      enter_filter_settings_menu )
        hash_menu="$TEXT_FILTER_MENU_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_filter_settings_menu.sh"
      ;;

      enter_screen_settings_menu )
        hash_menu="$TEXT_SCREEN_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
      ;;

      enter_system_settings_menu )
        hash_menu="$TEXT_SYSTEM_SETTINGS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
      ;;

      enter_online_tools_menu )
        hash_menu="$TEXT_ONLINE_TOOLS"
        hash_mark=""
        hash_title="---"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      enter_exit_into_shell_menu )
        hash_menu="$TEXT_EXIT_INTO_SHELL"
        hash_mark=""
        hash_title="$TEXT_BACK"
        hash_par="exit_settings_menu"
        hash_rom="back"
        ll_hash
        generate_submenu "$SCRIPTS/generate_exit_into_shell_menu.sh"
      ;;

      exit_settings_menu )
        settings_menu_back
      ;;

### Generate settings sub menus END ###

### Filter games menu BEGIN ###
      
      # Generate filter sub mneu
      filter_games )
        SYSTEMMENU=1
        GENERATFLAG=0
        clear_gameselect_flags
        set_screen_theme
        generate_filter_menu
        ln -sf $CFGFILTER /root/.lemonlauncherH/games.conf
        ln -sf $CFGFILTER /root/.lemonlauncherV/games.conf
        hash_menu="$TEXT_FILTER_GAMES"
        hash_mark=""
        hash_title="---"
        hash_par="filter_back"
        hash_rom="back"
        ll_hash
      ;;

      # Exit filter sub menu
      filter_back )
        filter_menu_back
      ;;

      filter_clearall )
        for item in "${FILTER_ARRAY_CHOICE[@]}"
        do
          var_filter="filter_${item}"
          var_index="filter_${item}_index"
          declare $var_filter=""
          declare $var_index=0
        done
        filter_horizontal="N"
        filter_vertical="N"
        save_game_filters
        unset FILTER_ARRAY_GENRE_EXCLUDE
        unset FILTER_ARRAY_MANUFACTURER_EXCLUDE
        unset FILTER_ARRAY_SYSTEM_EXCLUDE
        rm $SETTINGS/filter_genre_exclude &> /dev/null
        rm $SETTINGS/filter_manufacturer_exclude &> /dev/null
        rm $SETTINGS/filter_system_exclude &> /dev/null
        GENERATFLAG=1
        filter_menu_back
      ;;

      filter_genre_include )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list

        for line in "${FILTER_ARRAY_GENRE[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_GENRE[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_genre_include_index" --menu "\nGame genre\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_GENRE[$indexnum]}
          if [ "$indexnum" -ne 0 ]; then
            filter_genre_include="$gamefilter"
            unset FILTER_ARRAY_GENRE_EXCLUDE
            rm $SETTINGS/filter_genre_exclude &> /dev/null
          else
            filter_genre_include=""
          fi
          filter_genre_include_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_GENRE_FILTER_INCLUDE"
          hash_par="filter_genre_include"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_genre_exclude )
        unset menu_array
        declare -a menu_array
        i=0 # Array index
        j=0 # Visible menu item number to be displayed in menu list

        for line in "${FILTER_ARRAY_GENRE[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          if [ -e "$SETTINGS/filter_genre_exclude" ]; then
            if grep -q "$line$" $SETTINGS/filter_genre_exclude; then
              line="(-) $line"
            fi
          fi
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_GENRE[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --menu "\nGame genre\n" 0 28 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -ne 0 ]; then
            gamefilter=${FILTER_ARRAY_GENRE[$indexnum]}
            unset FILTER_ARRAY_GENRE_EXCLUDE
            declare -a FILTER_ARRAY_GENRE_EXCLUDE
            add_item="Y"
            if [ -e "$SETTINGS/filter_genre_exclude" ]; then
              add=$((indexnum+1))
              itemnum=$((indexnum+add))
              if [[ "${menu_array[$itemnum]}" =~ \(-\) ]]; then
                sed -i "s/${FILTER_ARRAY_GENRE[$indexnum]}$//" $SETTINGS/filter_genre_exclude
                add_item="N"
              fi
              cat $SETTINGS/filter_genre_exclude | grep -v "#" > /tmp/filterlist
              # Remove Windows carriage returns
              sed -i 's/\r//g' /tmp/filterlist
              # Remove blank lines
              sed -i '/^[[:space:]]*$/d' /tmp/filterlist
              while read line
              do
                FILTER_ARRAY_GENRE_EXCLUDE+=("$line")
              done < /tmp/filterlist
            fi
            
            if [ "$add_item" = "Y" ]; then
              FILTER_ARRAY_GENRE_EXCLUDE+=("$gamefilter")
              joy2key_start "anykey"
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nExclude genre:\n\n'$gamefilter'\n\n" 0 0
              joy2key_stop
            fi
            printf "%s\n" "${FILTER_ARRAY_GENRE_EXCLUDE[@]}" > $SETTINGS/filter_genre_exclude

            filter_genre_include=""
            filter_genre_include_index=0
            save_game_filters
          else
            unset FILTER_ARRAY_GENRE_EXCLUDE
            rm $SETTINGS/filter_genre_exclude &> /dev/null
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nFilter cleared\n\n" 0 0
            joy2key_stop
          fi
          hash_menu="$TEXT_FILTER_GAMES"
          [ "${#FILTER_ARRAY_GENRE_EXCLUDE[@]}" -gt 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_GENRE_FILTER_EXCLUDE"
          hash_par="filter_genre_exclude"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_manufacturer_include )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list

        for line in "${FILTER_ARRAY_MANUFACTURER[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_MANUFACTURER[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_manufacturer_include_index" --menu "\nGame manufacturer\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_MANUFACTURER[$indexnum]}
          if [ "$indexnum" -ne 0 ]; then
            filter_manufacturer_include="$gamefilter"
            unset FILTER_ARRAY_MANUFACTURER_EXCLUDE
            rm $SETTINGS/filter_manufacturer_exclude &> /dev/null
          else
            filter_manufacturer_include=""
          fi
          filter_manufacturer_include_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_MANUFACTURER_FILTER_INCLUDE"
          hash_par="filter_manufacturer_include"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_manufacturer_exclude )
        unset menu_array
        declare -a menu_array
        i=0 # Array index
        j=0 # Visible menu item number to be displayed in menu list

        for line in "${FILTER_ARRAY_MANUFACTURER[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          if [ -e "$SETTINGS/filter_manufacturer_exclude" ]; then
            if grep -q "$line$" $SETTINGS/filter_manufacturer_exclude; then
              line="(-) $line"
            fi
          fi
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_MANUFACTURER[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --menu "\nGame manufacturer\n" 0 28 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -ne 0 ]; then
            gamefilter=${FILTER_ARRAY_MANUFACTURER[$indexnum]}
            unset FILTER_ARRAY_MANUFACTURER_EXCLUDE
            declare -a FILTER_ARRAY_MANUFACTURER_EXCLUDE
            add_item="Y"
            if [ -e "$SETTINGS/filter_manufacturer_exclude" ]; then
              add=$((indexnum+1))
              itemnum=$((indexnum+add))
              if [[ "${menu_array[$itemnum]}" =~ \(-\) ]]; then
                sed -i "s/${FILTER_ARRAY_MANUFACTURER[$indexnum]}$//" $SETTINGS/filter_manufacturer_exclude
                add_item="N"
              fi
              cat $SETTINGS/filter_manufacturer_exclude | grep -v "#" > /tmp/filterlist
              # Remove Windows carriage returns
              sed -i 's/\r//g' /tmp/filterlist
              # Remove blank lines
              sed -i '/^[[:space:]]*$/d' /tmp/filterlist
              while read line
              do
                FILTER_ARRAY_MANUFACTURER_EXCLUDE+=("$line")
              done < /tmp/filterlist
            fi
            
            if [ "$add_item" = "Y" ]; then
              FILTER_ARRAY_MANUFACTURER_EXCLUDE+=("$gamefilter")
              joy2key_start "anykey"
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nExclude manufacturer:\n\n'$gamefilter'\n\n" 0 0
              joy2key_stop
            fi
            printf "%s\n" "${FILTER_ARRAY_MANUFACTURER_EXCLUDE[@]}" > $SETTINGS/filter_manufacturer_exclude

            filter_manufacturer_include=""
            filter_manufacturer_include_index=0
            save_game_filters
          else
            unset FILTER_ARRAY_MANUFACTURER_EXCLUDE
            rm $SETTINGS/filter_manufacturer_exclude &> /dev/null
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nFilter cleared\n\n" 0 0
            joy2key_stop
          fi
          hash_menu="$TEXT_FILTER_GAMES"
          [ "${#FILTER_ARRAY_MANUFACTURER_EXCLUDE[@]}" -gt 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_MANUFACTURER_FILTER_EXCLUDE"
          hash_par="filter_manufacturer_exclude"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_system_include )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list

        for line in "${FILTER_ARRAY_SYSTEM[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_SYSTEM[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_system_include_index" --menu "\nGame system\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_SYSTEM[$indexnum]}
          [ "$indexnum" -ne 0 ] && filter_system_include="$gamefilter" || filter_system_include=""
          if [ "$indexnum" -ne 0 ]; then
            filter_system_include="$gamefilter"
            unset FILTER_ARRAY_SYSTEM_EXCLUDE
            rm $SETTINGS/filter_system_exclude &> /dev/null
          else
            filter_system_include=""
          fi
          filter_system_include_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_SYSTEM_FILTER_INCLUDE"
          hash_par="filter_system_include"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_system_exclude )
        unset menu_array
        declare -a menu_array
        i=0 # Array index
        j=0 # Visible menu item number to be displayed in menu list

        for line in "${FILTER_ARRAY_SYSTEM[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          if [ -e "$SETTINGS/filter_system_exclude" ]; then
            if grep -q "$line$" $SETTINGS/filter_system_exclude; then
              line="(-) $line"
            fi
          fi
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_SYSTEM[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --menu "\nGame system\n" 0 28 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -ne 0 ]; then
            gamefilter=${FILTER_ARRAY_SYSTEM[$indexnum]}
            unset FILTER_ARRAY_SYSTEM_EXCLUDE
            declare -a FILTER_ARRAY_SYSTEM_EXCLUDE
            add_item="Y"
            if [ -e "$SETTINGS/filter_system_exclude" ]; then
              add=$((indexnum+1))
              itemnum=$((indexnum+add))
              if [[ "${menu_array[$itemnum]}" =~ \(-\) ]]; then
                sed -i "s/${FILTER_ARRAY_SYSTEM[$indexnum]}$//" $SETTINGS/filter_system_exclude
                add_item="N"
              fi
              cat $SETTINGS/filter_system_exclude | grep -v "#" > /tmp/filterlist
              # Remove Windows carriage returns
              sed -i 's/\r//g' /tmp/filterlist
              # Remove blank lines
              sed -i '/^[[:space:]]*$/d' /tmp/filterlist
              while read line
              do
                FILTER_ARRAY_SYSTEM_EXCLUDE+=("$line")
              done < /tmp/filterlist
            fi
            
            if [ "$add_item" = "Y" ]; then
              FILTER_ARRAY_SYSTEM_EXCLUDE+=("$gamefilter")
              joy2key_start "anykey"
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nExclude system:\n\n'$gamefilter'\n\n" 0 0
              joy2key_stop
            fi
            printf "%s\n" "${FILTER_ARRAY_SYSTEM_EXCLUDE[@]}" > $SETTINGS/filter_system_exclude

            filter_system_include=""
            filter_system_include_index=0
            save_game_filters
          else
            unset FILTER_ARRAY_SYSTEM_EXCLUDE
            rm $SETTINGS/filter_system_exclude &> /dev/null
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nFilter cleared\n\n" 0 0
            joy2key_stop
          fi
          hash_menu="$TEXT_FILTER_GAMES"
          [ "${#FILTER_ARRAY_SYSTEM_EXCLUDE[@]}" -gt 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_SYSTEM_FILTER_EXCLUDE"
          hash_par="filter_system_exclude"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_buttons )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_BUTTONS[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_BUTTONS[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_buttons_index" --menu "\nMax. buttons required\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_BUTTONS[$indexnum]}
          [ "$indexnum" -ne 0 ] && filter_buttons="$indexnum" || filter_buttons=""
          [ "$indexnum" -ne 0 ] && filter_buttons_mark="\xB7" || filter_buttons_mark=""
          filter_buttons_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_BUTTONS_FILTER"
          hash_par="filter_buttons"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_clone )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_CLONE[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_CLONE[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_clone_index" --menu "\nGame clones\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_CLONE[$indexnum]}
          case $indexnum in
            1 )
              clone="yes"
            ;;
            2 )
              clone="no"
            ;;
          esac
          [ "$indexnum" -ne 0 ] && filter_clone="$clone" || filter_clone=""
          filter_clone_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_CLONE_FILTER"
          hash_par="filter_clone"
          hash_rom="pinhp"
          ll_hash
          generate_filter_menu
          GENERATFLAG=1
        fi
      ;;

      filter_decade )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_DECADE[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_DECADE[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_decade_index" --menu "\nGame decade\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_DECADE[$indexnum]}
          [ "$indexnum" -ne 0 ] && filter_decade="$gamefilter" || filter_decade=""
          filter_decade_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_DECADE_FILTER"
          hash_par="filter_decade"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_manufacturer )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_MANUFACTURER[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_MANUFACTURER[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_manufacturer_index" --menu "\nGame manufacturer\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_MANUFACTURER[$indexnum]}
          [ "$indexnum" -ne 0 ] && filter_manufacturer="$gamefilter" || filter_manufacturer=""
          filter_manufacturer_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_MANUFACTURER_FILTER"
          hash_par="filter_manufacturer"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_mature )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_MATURE[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_MATURE[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_mature_index" --menu "\nMature games\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          case $indexnum in
            1 )
              gamefilter="YES"
            ;;
            2 )
              gamefilter="NO"
            ;;
          esac
          [ "$indexnum" -ne 0 ] && filter_mature="$gamefilter" || filter_mature=""
          filter_mature_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_MATURE_FILTER"
          hash_par="filter_mature"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_players )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_PLAYERS[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_PLAYERS[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_players_index" --menu "\nNumber of players\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_PLAYERS[$indexnum]}
          [ "$indexnum" -ne 0 ] && filter_players="$gamefilter" || filter_players=""
          filter_players_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_PLAYERS_FILTER"
          hash_par="filter_players"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_recommended )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_RECOMMENDED[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_RECOMMENDED[@]}
        height=$((length+1))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_recommended_index" --menu "\nRecommended games\n(based on AKNF)\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          case $indexnum in
            1 )
              gamefilter="true"
            ;;
            2 )
              gamefilter="false"
            ;;
          esac
          [ "$indexnum" -ne 0 ] && filter_recommended="$gamefilter" || filter_recommended=""
          filter_recommended_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_RECOMMENDED_FILTER"
          hash_par="filter_recommended"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_slow )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_SLOW[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_SLOW[@]}
        height=$((length+1))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_slow_index" --menu "\nGames known to run\nslow on RPi3\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          case $indexnum in
            1 )
              gamefilter="YES"
            ;;
            2 )
              gamefilter=""
            ;;
          esac
          [ "$indexnum" -ne 0 ] && filter_slow="$gamefilter" || filter_slow=""
          filter_slow_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_SLOW_FILTER"
          hash_par="filter_slow"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_system )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_SYSTEM[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_SYSTEM[@]}
        height=$length
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_system_index" --menu "\nGame system\n" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          gamefilter=${FILTER_ARRAY_SYSTEM[$indexnum]}
          [ "$indexnum" -ne 0 ] && filter_system="$gamefilter" || filter_system=""
          filter_system_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_SYSTEM_FILTER"
          hash_par="filter_system"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

      filter_horizontal_only )
        [ "$filter_horizontal" = "Y" ] && filter_horizontal="N" || filter_horizontal="Y"
        filter_vertical="N"
        save_game_filters
        hash_menu="$TEXT_FILTER_GAMES"
        [ "$filter_horizontal" = "Y" ] && hash_mark="B7" || hash_mark=""
        hash_title="$TEXT_HORIZONTAL_FILTER"
        hash_par="filter_horizontal_only"
        hash_rom="pinhp"
        ll_hash
        generate_filter_menu
        GENERATFLAG=1
      ;;

      filter_vertical_only )
        [ "$filter_vertical" = "Y" ] && filter_vertical="N" || filter_vertical="Y"
        filter_horizontal="N"
        save_game_filters
        hash_menu="$TEXT_FILTER_GAMES"
        [ "$filter_vertical" = "Y" ] && hash_mark="B7" || hash_mark=""
        hash_title="$TEXT_VERTICAL_FILTER"
        hash_par="filter_vertical_only"
        hash_rom="pinhp"
        ll_hash
        generate_filter_menu
        GENERATFLAG=1
      ;;

      filter_dial_control )
        unset menu_array
        declare -a menu_array
        i=2 # Array index
        j=0 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_DIAL[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#FILTER_ARRAY_DIAL[@]}
        height=$((length+1))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$filter_dial_index" --menu "\nDial control games\n(paddle/spinner)" 0 26 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          case $indexnum in
            1 )
              gamefilter="paddle"
            ;;
            2 )
              gamefilter="spinner"
            ;;
            3) 
              gamefilter="either"
            ;;
            4 )
              gamefilter="hide"
            ;;
          esac
          [ "$indexnum" -ne 0 ] && filter_dial="$gamefilter" || filter_dial=""
          filter_dial_index="$indexnum"
          save_game_filters
          hash_menu="$TEXT_FILTER_GAMES"
          [ "$indexnum" -ne 0 ] && hash_mark="B7" || hash_mark=""
          hash_title="$TEXT_DIAL_FILTER"
          hash_par="filter_dial_control"
          hash_rom="pinhp"
          ll_hash
          GENERATFLAG=1
          generate_filter_menu
        fi
      ;;

### Filter games menu END ###

### Group games menu BEGIN ###
      
      # Generate group sub mneu
      group_games )
        SYSTEMMENU=1
        GENERATFLAG=0
        clear_gameselect_flags
        set_screen_theme
        generate_group_menu 
        ln -sf $CFGGROUP /root/.lemonlauncherH/games.conf
        ln -sf $CFGGROUP /root/.lemonlauncherV/games.conf
        hash_menu="$TEXT_GROUP_GAMES"
        hash_mark=""
        hash_title="---"
        hash_par="group_back"
        hash_rom="back"
        ll_hash
      ;;

      # Exit group sub menu
      group_back )
        group_menu_back
      ;;

      group_games_system )
        hash_menu="$TEXT_GROUP_GAMES"
        hash_title="$TEXT_GROUP_GAMES_SYSTEM"
        hash_mark=""
        hash_par="$par"
        hash_rom="$rom"
        no_game_menu_markers
        if [ "$group_games" != "system" ]; then
          game_menu_dirs=7
          group_games="system"
          custom_folders="N"
          hash_mark="B7"
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=7/' "$CONFIGFILE"
        sync
        else
          group_games=""
          [ -e "$GAMEMENULAST" ] && source "$GAMEMENULAST" || game_menu_dirs=1
          sed -i -e "s/game_menu_dirs=./game_menu_dirs=$game_menu_dirs/" "$CONFIGFILE"
        fi
        ll_hash
        generate_group_menu
        save_game_filters
        GENERATFLAG=1
      ;;

      group_games_genre )
        hash_menu="$TEXT_GROUP_GAMES"
        hash_title="$TEXT_GROUP_GAMES_GENRE"
        hash_mark=""
        hash_par="$par"
        hash_rom="$rom"
        no_game_menu_markers
        if [ "$group_games" != "genre" ]; then
          game_menu_dirs=7
          group_games="genre"
          custom_folders="N"
          hash_mark="B7"
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=7/' "$CONFIGFILE"
        sync
        else
          group_games=""
          [ -e "$GAMEMENULAST" ] && source "$GAMEMENULAST" || game_menu_dirs=1
          sed -i -e "s/game_menu_dirs=./game_menu_dirs=$game_menu_dirs/" "$CONFIGFILE"
        fi
        ll_hash
        generate_group_menu
        save_game_filters
        GENERATFLAG=1
      ;;

      group_games_manufacturer )
        hash_menu="$TEXT_GROUP_GAMES"
        hash_title="$TEXT_GROUP_GAMES_MANUFACTURER"
        hash_mark=""
        hash_par="$par"
        hash_rom="$rom"
        no_game_menu_markers
        if [ "$group_games" != "manufacturer" ]; then
          game_menu_dirs=7
          group_games="manufacturer"
          custom_folders="N"
          hash_mark="B7"
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=7/' "$CONFIGFILE"
        sync
        else
          group_games=""
          [ -e "$GAMEMENULAST" ] && source "$GAMEMENULAST" || game_menu_dirs=1
          sed -i -e "s/game_menu_dirs=./game_menu_dirs=$game_menu_dirs/" "$CONFIGFILE"
        fi
        ll_hash
        generate_group_menu
        save_game_filters
        GENERATFLAG=1
      ;;

      group_games_year )
        hash_menu="$TEXT_GROUP_GAMES"
        hash_title="$TEXT_GROUP_GAMES_YEAR"
        hash_mark=""
        hash_par="$par"
        hash_rom="$rom"
        no_game_menu_markers
        if [ "$group_games" != "year" ]; then
          game_menu_dirs=7
          group_games="year"
          custom_folders="N"
          hash_mark="B7"
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=7/' "$CONFIGFILE"
        sync
        else
          group_games=""
          [ -e "$GAMEMENULAST" ] && source "$GAMEMENULAST" || game_menu_dirs=1
          sed -i -e "s/game_menu_dirs=./game_menu_dirs=$game_menu_dirs/" "$CONFIGFILE"
        fi
        ll_hash
        generate_group_menu
        save_game_filters
        GENERATFLAG=1
      ;;

      group_games_orientation )
        hash_menu="$TEXT_GROUP_GAMES"
        hash_title="$TEXT_GROUP_GAMES_ORIENTATION"
        hash_mark=""
        hash_par="$par"
        hash_rom="$rom"
        no_game_menu_markers
        if [ "$group_games" != "orientation" ]; then
          game_menu_dirs=7
          group_games="orientation"
          custom_folders="N"
          hash_mark="B7"
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=7/' "$CONFIGFILE"
        sync
        else
          group_games=""
          [ -e "$GAMEMENULAST" ] && source "$GAMEMENULAST" || game_menu_dirs=1
          sed -i -e "s/game_menu_dirs=./game_menu_dirs=$game_menu_dirs/" "$CONFIGFILE"
        fi
        ll_hash
        generate_group_menu
        save_game_filters
        GENERATFLAG=1
      ;;

      group_show_other )
        if [ "$group_show_other" = "Y" ]; then
          group_show_other="N"
          hash_menu="$TEXT_GROUP_GAMES"
          hash_mark=""
          hash_title="$TEXT_SHOW_OTHER"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/group_show_other=./group_show_other=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_SHOW_OTHER/title =\"$TEXT_SHOW_OTHER/" $CFGSETTINGS
        else
          group_show_other="Y"
          hash_menu="$TEXT_GROUP_GAMES"
          hash_mark="B7"
          hash_title="$TEXT_SHOW_OTHER"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/group_show_other=./group_show_other=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_SHOW_OTHER/title =\"\\xB7$TEXT_SHOW_OTHER/" $CFGSETTINGS
        fi
        generate_group_menu
        GENERATFLAG=1
      ;;

### Group games menu END ###

### Options (main menu) BEGIN ###

      toggle_servostik )
        bash "$SCRIPTS/toggle_servostik.sh" "$servostik_default"
        touch /tmp/servostik_toggled
      ;;

      screensaver )
        if [ "$status_messages" = "Y" ]; then
          echo "... Screensaver"
        fi
        screen_saver
      ;;
  
    	reboot )
        reboot_system
      ;;
  
    	shutdown )
        shutdown_system
      ;;
   
    	hiddenfeatures )
        if [ "$status_messages" = "Y" ]; then
          echo "... Prepare settings menu"
        fi
        if [ "$hidden_features" = "1" ] && [ ! -f "$HIDDENFEATURES" ]; then
          if [ "$SECONDS" -gt "$hidden_seconds" ]; then
            HIDDENCOUNT=0
            SECONDS=0
          fi
          if [ "$HIDDENCOUNT" = "0" ]; then
            SECONDS=0
          fi
    	    ((HIDDENCOUNT++))
          if [ "$HIDDENCOUNT" = "3" ]; then
            if [ "$SECONDS" -lt "$hidden_seconds" ]; then
              touch "$HIDDENFEATURES"
                if [ "$status_messages" = "Y" ]; then
                echo "... count "$HIDDENCOUNT
                echo "... Activating"
              else
                counter=1
                echo -n "    "
                until [ $counter -gt $HIDDENCOUNT ]
                do
                  echo -n "."
                  ((counter++))
                done
              fi
              sleep 1
              generate_game_menu
              get_uptime
              hash_menu="$menu_options"
              hash_mark=""
              hash_rom="pinhp"
              hash_title="$TEXT_UPTIME$uptime"
              hash_par="uptime"
              ll_hash
            else
              SECONDS=0
              HIDDENCOUNT=1
              if [ "$status_messages" = "Y" ]; then
                echo "... count "$HIDDENCOUNT
              else
                counter=1
                echo -n "    "
                until [ $counter -gt $HIDDENCOUNT ]
                do
                  echo -n "."
                  ((counter++))
                done
              fi
            fi
          else
            if [ "$status_messages" = "Y" ]; then
              echo "... count "$HIDDENCOUNT
            else
              counter=1
              echo -n "    "
              until [ $counter -gt $HIDDENCOUNT ];
              do
                echo -n "."
                ((counter++))
              done
            fi
            sleep 0.5
          fi
        fi
      ;;

      no_hidden_menu )
        if [ "$status_messages" = "Y" ]; then
          echo "... Hide settings menu"
        fi
        if [ -e "$HIDDENFEATURES" ]; then
          rm "$HIDDENFEATURES"
        fi
        clear_gameselect_flags
        generate_game_menu
      ;;

      uptime )
        get_uptime
        hash_menu="$menu_options"
        hash_mark=""
        hash_rom="pinhp"
        hash_title="$TEXT_UPTIME$uptime"
        hash_par="uptime"
        ll_hash
        ll_last="uptime"
      ;;

      about )
        case $pi2scartmode_current in
          Y )
            HARDWARE_MODE="Pi2SCART"
          ;;
          N )
            HARDWARE_MODE="Pi2Jamma"
          ;;
        esac
        
        ABOUTDIALOG="$ABOUTDIALOG_DATE | $HARDWARE_MODE$ABOUTDIALOG_TEXT"
        pikeyd165_start "anykey"
        joy2key_start "anykey"
        dialog --timeout 15 --begin 6 5 --title "pinHP Arcade Classics" --msgbox "$ABOUTDIALOG" 18 30
        joy2key_stop
      ;;
      
      debug )
        mkdir /tmp/debug &> /dev/null

        cp $CONFIGFILE /tmp/debug/configfile_before
        cp $LANGUAGEFILE /tmp/debug/languagefile_before
        cp $CFGGAMES /tmp/debug/gamesconf_before
        cp $CFGSYSTEM /tmp/debug/systemconf_before
        cp $MAMECONFIG /tmp/debug/advmame_rc_before
        cp $LLCONFH /tmp/debug/llconfh_before
        cp $LLCONFV /tmp/debug/llconfv_before
        cp /root/.lemonlauncher/theme.conf /tmp/debug/ll_theme_conf_before
        declare -p > /tmp/debug/variables_before

        source "$SCRIPTS/filter_arrays.sh"
        cleanup_all
        checksum_compare
        read_configfile
        check_pi2scart
        clear_gameselect_flags
        generate_game_menu

        cp $CONFIGFILE /tmp/debug/configfile_after
        cp $LANGUAGEFILE /tmp/debug/languagefile_after
        cp $CFGGAMES /tmp/debug/gamesconf_after
        cp $CFGSYSTEM /tmp/debug/systemconf_after
        cp $MAMECONFIG /tmp/debug/advmame_rc_after
        cp $LLCONFH /tmp/debug/llconfh_after
        cp $LLCONFV /tmp/debug/llconfv_after
        cp /root/.lemonlauncher/theme.conf /tmp/debug/ll_theme_conf_after
        declare -p > /tmp/debug/variables_after

        diff -c /tmp/debug/configfile_before /tmp/debug/configfile_after > /tmp/debug/_configfile_DIFF
        diff -c /tmp/debug/languagefile_before /tmp/debug/languagefile_after > /tmp/debug/_languagefile_DIFF
        diff -c /tmp/debug/gamesconf_before /tmp/debug/gamesconf_after > /tmp/debug/_gamesconf_DIFF
        diff -c /tmp/debug/systemconf_before /tmp/debug/systemconf_after > /tmp/debug/_systemconf_DIFF
        diff -c /tmp/debug/advmame_rc_before /tmp/debug/advmame_rc_after > /tmp/debug/_advmame_rc_DIFF
        diff -c /tmp/debug/llconfh_before /tmp/debug/llconfh_after > /tmp/debug/_llconfh_DIFF
        diff -c /tmp/debug/llconfv_before /tmp/debug/llconfv_after > /tmp/debug/_llconfv_DIFF
        diff -c /tmp/debug/ll_theme_conf_before /tmp/debug/ll_theme_conf_after > /tmp/debug/_ll_theme_conf_DIFF
        diff -c /tmp/debug/variables_before /tmp/debug/variables_after > /tmp/debug/_variables_DIFF
      ;;

### Options (main menu) END ###

### Game Settings menu BEGIN ###

      hide_mature )
        if [ "$hide_mature" = "Y" ]; then
          hide_mature="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_HIDE_MATURE"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/hide_mature=./hide_mature=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_HIDE_MATURE/title =\"$TEXT_HIDE_MATURE/" $CFGSETTINGS
        else
          hide_mature="Y"
          filter_mature=""
          filter_mature_index=0
          save_game_filters
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_HIDE_MATURE"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/hide_mature=./hide_mature=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_HIDE_MATURE/title =\"\\xB7$TEXT_HIDE_MATURE/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      game_menu_dirs_1 )
        if [ "$game_menu_dirs" != "1" ]; then
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_1_LINE_GAME_MENU"
          hash_par="$par"
          hash_rom="menu_1"
          ll_hash
          no_game_menu_markers
          game_menu_dirs=1
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=1/' "$CONFIGFILE"
          echo "game_menu_dirs=\"$game_menu_dirs\"" > $GAMEMENULAST
          ESCAPED_TEXT=$(sed -e 's/[&\\/]/\\&/g; s/$/\\/' -e '$s/\\$//' <<<"$TEXT_1_LINE_GAME_MENU")
            sed -i -e "s/title =\".*$ESCAPED_TEXT\"/title =\"\\xB7$ESCAPED_TEXT\"/" $CFGSETTINGS
          GENERATFLAG=1
          group_games=""
          save_game_filters
        fi
      ;;
  
      game_menu_dirs_2 )
        if [ "$game_menu_dirs" != "2" ]; then
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_2_LINE_GAME_MENU"
          hash_par="$par"
          hash_rom="menu_2"
          ll_hash
          no_game_menu_markers
          game_menu_dirs=2
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=2/' "$CONFIGFILE"
          echo "game_menu_dirs=\"$game_menu_dirs\"" > $GAMEMENULAST
          ESCAPED_TEXT=$(sed -e 's/[&\\/]/\\&/g; s/$/\\/' -e '$s/\\$//' <<<"$TEXT_2_LINE_GAME_MENU")
            sed -i -e "s/title =\".*$ESCAPED_TEXT\"/title =\"\\xB7$ESCAPED_TEXT\"/" $CFGSETTINGS
          GENERATFLAG=1
          group_games=""
          save_game_filters
        fi
      ;;
  
      game_menu_dirs_3 )
        if [ "$game_menu_dirs" != "3" ]; then
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_3_LINE_GAME_MENU"
          hash_par="$par"
          hash_rom="menu_3"
          ll_hash
          no_game_menu_markers
          game_menu_dirs=3
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=3/' "$CONFIGFILE"
          echo "game_menu_dirs=\"$game_menu_dirs\"" > $GAMEMENULAST
          ESCAPED_TEXT=$(sed -e 's/[&\\/]/\\&/g; s/$/\\/' -e '$s/\\$//' <<<"$TEXT_3_LINE_GAME_MENU")
            sed -i -e "s/title =\".*$ESCAPED_TEXT\"/title =\"\\xB7$ESCAPED_TEXT\"/" $CFGSETTINGS
          GENERATFLAG=1
          group_games=""
          save_game_filters
        fi
      ;;
  
      game_menu_dirs_9 )
        if [ "$game_menu_dirs" != "9" ]; then
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_FAV_GAMES_MENU_ONLY"
          hash_par="$par"
          hash_rom="menu_9"
          ll_hash
          no_game_menu_markers
          game_menu_dirs=9
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=9/' "$CONFIGFILE"
          echo "game_menu_dirs=\"$game_menu_dirs\"" > $GAMEMENULAST
          ESCAPED_TEXT=$(sed -e 's/[&\\/]/\\&/g; s/$/\\/' -e '$s/\\$//' <<<"$TEXT_FAV_GAMES_MENU_ONLY")
            sed -i -e "s/title =\".*$ESCAPED_TEXT\"/title =\"\\xB7$ESCAPED_TEXT\"/" $CFGSETTINGS
          GENERATFLAG=1
          group_games=""
          save_game_filters
        fi
      ;;
  
      game_menu_dirs_8 )
        if [ "$game_menu_dirs" != "8" ]; then
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_FAV_AND_SECOND_MENU_ONLY"
          hash_par="$par"
          hash_rom="menu_8"
          ll_hash
          no_game_menu_markers
          game_menu_dirs=8
          sed -i -e 's/game_menu_dirs=./game_menu_dirs=8/' "$CONFIGFILE"
          echo "game_menu_dirs=\"$game_menu_dirs\"" > $GAMEMENULAST
          ESCAPED_TEXT=$(sed -e 's/[&\\/]/\\&/g; s/$/\\/' -e '$s/\\$//' <<<"$TEXT_FAV_AND_SECOND_MENU_ONLY")
            sed -i -e "s/title =\".*$ESCAPED_TEXT\"/title =\"\\xB7$ESCAPED_TEXT\"/" $CFGSETTINGS
          GENERATFLAG=1
          group_games=""
          save_game_filters
        fi
      ;;

      custom_folders )
        # Reset game menu dirs
        [ -e "$GAMEMENULAST" ] && source "$GAMEMENULAST" || game_menu_dirs=1
        sed -i "s/game_menu_dirs=./game_menu_dirs=$game_menu_dirs/" "$CONFIGFILE"
        if [ "$custom_folders" = "Y" ]; then
          custom_folders="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_CUSTOM_FOLDERS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/custom_folders=./custom_folders=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_CUSTOM_FOLDERS/title =\"$TEXT_CUSTOM_FOLDERS/" $CFGSETTINGS
        else
          custom_folders="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_CUSTOM_FOLDERS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/custom_folders=./custom_folders=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_CUSTOM_FOLDERS/title =\"\\xB7$TEXT_CUSTOM_FOLDERS/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
        group_games=""
        save_game_filters
        generate_submenu "$SCRIPTS/generate_game_settings_menu.sh"
      ;;

      custom_favmenu )
        [ "$rom" = "group" ] && hash_menu="$TEXT_GROUP_GAMES" || hash_menu="$TEXT_GAME_MENU_SETTINGS"
        hash_title="$TEXT_CUSTOM_FAVMENU"
        hash_par="$par"
        hash_rom="$rom"
        if [ "$custom_favmenu" = "Y" ]; then
          custom_favmenu="N"
          hash_mark=""
          hash_mark_escaped=""
        else
          custom_favmenu="Y"
          hash_mark="B7"
          hash_mark_escaped="\\xB7"
        fi
        sed -i -e "s/custom_favmenu=./custom_favmenu=$custom_favmenu/" "$CONFIGFILE"
        sed -i -e "s/title =\".*$TEXT_CUSTOM_FAVMENU/title =\"${hash_mark_escaped}${TEXT_CUSTOM_FAVMENU}/" $CFGSETTINGS
        sed -i -e "s/title =\".*$TEXT_CUSTOM_FAVMENU/title =\"${hash_mark_escaped}${TEXT_CUSTOM_FAVMENU}/" $CFGGROUP
        ll_hash
        sync
        GENERATFLAG=1
      ;;

      show_deleted_games )
        if [ "$show_deleted_games" = "Y" ] || [ "$custom_folders" = "Y" ]; then
          show_deleted_games="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_DELETED_GAMES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e "s/title =\".*$TEXT_DELETED_GAMES/title =\"$TEXT_DELETED_GAMES/" $CFGSETTINGS
        else
          clear_gameselect_flags
          show_deleted_games="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_DELETED_GAMES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e "s/title =\".*$TEXT_DELETED_GAMES/title =\"\\xB7$TEXT_DELETED_GAMES/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      favmenu_select )
        exit_systemmenu
        clear_gameselect_flags
        favmenu_select_flag=1
        ln -sf "/root/.lemonlauncherH/bg/backgroundH_select.png" /root/.lemonlauncherH/background.png
        ln -sf "/root/.lemonlauncherV/bg/backgroundV_select.png" /root/.lemonlauncherV/background.png
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        if [ "$quickedit_mode" = "Y" ]; then
          menu_mark_quickedit
        fi
      ;;

      favmenu_deselect )
        exit_systemmenu
        clear_gameselect_flags
        favmenu_deselect_flag=1
        hash_menu="$MENUTITLE1"
        hash_mark=""
        hash_title=" ### $TEXT_APPLY_CHANGES ### "
        hash_par="quickedit_apply"
        hash_rom="quickeditmode_menu1"
        ll_hash
        ln -sf "/root/.lemonlauncherH/bg/backgroundH_deselect.png" /root/.lemonlauncherH/background.png
        ln -sf "/root/.lemonlauncherV/bg/backgroundV_deselect.png" /root/.lemonlauncherV/background.png
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        if [ "$quickedit_mode" = "Y" ]; then
          menu_mark_quickedit
        fi
        case "$game_menu_dirs" in
          # All Games Menu - display game count as unknown
          1 )
            sed -i '/{ #MENU/s/([0-9]*)"/(?)"/' $CFGGAMES
          ;;            
          # Group menus
          7 )
            if [ "$custom_favmenu" != "Y" ]; then
              sed -i '/{ #MENU/s/([0-9]*)"/(?)"/' $CFGGAMES
            else
              sed -i '/{ #MENU[^1]/s/menu "/menu "./' $CFGGAMES
            fi
          ;;
          # Fav. Games Menu exists - hide all other menus
          * )
            sed -i '/{ #MENU[^1]/s/menu "/menu "./' $CFGGAMES
          ;;
        esac
        # Hide all non Fav. Games
        sed -i '/-0FAV/s/title ="/title ="./' $CFGGAMES
        quickedit_changed=1
      ;;
   
      secondmenu_select )
        exit_systemmenu
        clear_gameselect_flags
        secondmenu_select_flag=1
        ln -sf "/root/.lemonlauncherH/bg/backgroundH_2nd_menu_select.png" /root/.lemonlauncherH/background.png
        ln -sf "/root/.lemonlauncherV/bg/backgroundV_2nd_menu_select.png" /root/.lemonlauncherV/background.png
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        if [ "$quickedit_mode" = "Y" ]; then
          menu_mark_quickedit
        fi
      ;;

      secondmenu_deselect )
        exit_systemmenu
        clear_gameselect_flags
        secondmenu_deselect_flag=1
        hash_menu="$MENUTITLE2"
        hash_mark=""
        hash_title=" ### $TEXT_APPLY_CHANGES ### "
        hash_par="quickedit_apply"
        hash_rom="quickeditmode_menu2"
        ll_hash
        ln -sf "/root/.lemonlauncherH/bg/backgroundH_2nd_menu_deselect.png" /root/.lemonlauncherH/background.png
        ln -sf "/root/.lemonlauncherV/bg/backgroundV_2nd_menu_deselect.png" /root/.lemonlauncherV/background.png
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        if [ "$quickedit_mode" = "Y" ]; then
          menu_mark_quickedit
        fi
        case "$game_menu_dirs" in
          # 2nd Menu exists - hide all other menus
          3 | 8 )
            sed -i '/{ #MENU[^2]/s/menu "/menu "./' $CFGGAMES
          ;;
          # Hide all menus except MENU2 (All Games), display game count as unknown
          2 )
            sed -i '/{ #MENU[^2]/s/menu "/menu "./' $CFGGAMES
            sed -i '/{ #MENU/s/([0-9]*)"/(?)"/' $CFGGAMES
          ;;            
          # Display game count as unknown
          * )
            sed -i '/{ #MENU/s/([0-9]*)"/(?)"/' $CFGGAMES
          ;;
        esac
        # Hide all non 2nd. Menu Games
        sed -i '/-0TWO/s/title ="/title ="./' $CFGGAMES
        quickedit_changed=1
      ;;
  
      preview_images )
        if [ "$preview_images" = "Y" ]; then
          preview_images="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_GAME_PREVIEW_IMAGES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_images=./preview_images=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_IMAGES/title =\"$TEXT_GAME_PREVIEW_IMAGES/" $CFGSETTINGS
        else
          preview_images="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_GAME_PREVIEW_IMAGES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_images=./preview_images=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_IMAGES/title =\"\\xB7$TEXT_GAME_PREVIEW_IMAGES/" $CFGSETTINGS
        fi
        save_orientation_settings        
        sync
      ;;

      preview_videos )
        if [ "$preview_videos" = "Y" ]; then
          preview_videos="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_GAME_PREVIEW_VIDEOS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_videos=./preview_videos=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_VIDEOS/title =\"$TEXT_GAME_PREVIEW_VIDEOS/" $CFGSETTINGS
        else
          preview_videos="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_GAME_PREVIEW_VIDEOS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_videos=./preview_videos=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_VIDEOS/title =\"\\xB7$TEXT_GAME_PREVIEW_VIDEOS/" $CFGSETTINGS
        fi
        set_video_options
        save_orientation_settings        
        sync
      ;;

      preview_videos_loop )
        if [ "$preview_videos_loop" = "Y" ]; then
          preview_videos_loop="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_VIDEO_LOOP"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_videos_loop=./preview_videos_loop=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_VIDEO_LOOP/title =\"$TEXT_VIDEO_LOOP/" $CFGSETTINGS
        else
          preview_videos_loop="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_VIDEO_LOOP"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_videos_loop=./preview_videos_loop=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_VIDEO_LOOP/title =\"\\xB7$TEXT_VIDEO_LOOP/" $CFGSETTINGS
        fi
      ;;

      video_volume )

        case $video_volume in

          $VIDEO_VOL_OFF )
            video_volume=$VIDEO_VOL_LOW
            hash_menu="$TEXT_GAME_MENU_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_VIDEO_VOLUME$TEXT_LOW"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          ;;

          $VIDEO_VOL_LOW )
            video_volume=$VIDEO_VOL_MID
            hash_menu="$TEXT_GAME_MENU_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_VIDEO_VOLUME$TEXT_MID"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          ;;

          $VIDEO_VOL_MID )
            video_volume=$VIDEO_VOL_HIGH
            hash_menu="$TEXT_GAME_MENU_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_VIDEO_VOLUME$TEXT_HIGH"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          ;;

          $VIDEO_VOL_HIGH )
            video_volume=$VIDEO_VOL_OFF
            hash_menu="$TEXT_GAME_MENU_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_VIDEO_VOLUME$TEXT_OFF"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          ;;

          * )
            video_volume=$VIDEO_VOL_OFF
            hash_menu="$TEXT_GAME_MENU_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_VIDEO_VOLUME$TEXT_OFF"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          ;;

        esac
        set_video_options
        generate_submenu "$SCRIPTS/generate_game_settings_menu.sh"
      ;;
  
      preview_marquees )
        if [ "$preview_marquees" = "Y" ]; then
          preview_marquees="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_GAME_PREVIEW_MARQUEES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_marquees=./preview_marquees=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_MARQUEES/title =\"$TEXT_GAME_PREVIEW_MARQUEES/" $CFGSETTINGS
        else
          preview_marquees="Y"
          if [ "$ORIENTATION" != "H" ] || [ "$screen_theme" != "2" ]; then
            preview_logos="N"
            sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_LOGOS/title =\"$TEXT_GAME_PREVIEW_LOGOS/" $CFGSETTINGS
          fi
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_GAME_PREVIEW_MARQUEES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_marquees=./preview_marquees=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_MARQUEES/title =\"\\xB7$TEXT_GAME_PREVIEW_MARQUEES/" $CFGSETTINGS
        fi
        if [ "$preview_marquees" = "Y" ]; then
          ln -sfn "$RPI2JAMMA/marquees" /root/.lemonlauncher_common/lemonmarquees
        else
          ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        fi
        if [ "$preview_logos" = "Y" ]; then
          ln -sfn "$RPI2JAMMA/logos" /root/.lemonlauncher_common/lemonlogos
        else
          ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        fi
        save_orientation_settings        
        sync
      ;;    
  
      preview_logos )
        if [ "$preview_logos" = "Y" ]; then
          preview_logos="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_GAME_PREVIEW_LOGOS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_logos=./preview_logos=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_LOGOS/title =\"$TEXT_GAME_PREVIEW_LOGOS/" $CFGSETTINGS
        else
          preview_logos="Y"
          if [ "$ORIENTATION" != "H" ] || [ "$screen_theme" != "2" ]; then
            preview_marquees="N"
            sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_MARQUEES/title =\"$TEXT_GAME_PREVIEW_MARQUEES/" $CFGSETTINGS
          fi
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_GAME_PREVIEW_LOGOS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/preview_logos=./preview_logos=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_PREVIEW_LOGOS/title =\"\\xB7$TEXT_GAME_PREVIEW_LOGOS/" $CFGSETTINGS
        fi
        if [ "$preview_logos" = "Y" ]; then
          ln -sfn "$RPI2JAMMA/logos" /root/.lemonlauncher_common/lemonlogos
        else
          ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        fi
        if [ "$preview_marquees" = "Y" ]; then
          ln -sfn "$RPI2JAMMA/marquees" /root/.lemonlauncher_common/lemonmarquees
        else
          ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        fi
        save_orientation_settings        
        sync
      ;;    

      gamecount )
        if [ "$game_count" = "Y" ]; then
          game_count="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_GAME_COUNT"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/game_count=./game_count=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_COUNT/title =\"$TEXT_GAME_COUNT/" $CFGSETTINGS
        else
          game_count="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_GAME_COUNT"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/game_count=./game_count=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GAME_COUNT/title =\"\\xB7$TEXT_GAME_COUNT/" $CFGSETTINGS
        fi
        save_orientation_settings
        sync
        GENERATFLAG=1
      ;;
  
      friendlynames )
        if [ "$friendly_names" = "Y" ]; then
          friendly_names="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_DISPLAY_FRIENDLY_NAMES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/friendly_names=./friendly_names=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_DISPLAY_FRIENDLY_NAMES/title =\"$TEXT_DISPLAY_FRIENDLY_NAMES/" $CFGSETTINGS
        else
          friendly_names="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_DISPLAY_FRIENDLY_NAMES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/friendly_names=./friendly_names=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_DISPLAY_FRIENDLY_NAMES/title =\"\\xB7$TEXT_DISPLAY_FRIENDLY_NAMES/" $CFGSETTINGS
        fi
        save_orientation_settings
        sync
        GENERATFLAG=1
      ;;
    
      orientationfilter )
        if [ "$orientation_filter" = "N" ]; then
          orientation_filter="Y"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_ORIENTATIONFILTER$TEXT_ON"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/orientation_filter=./orientation_filter=Y/' "$CONFIGFILE"
          sed -i -e 's/^orientationfilter=.*/orientationfilter="h"/' $LLCONFH
          sed -i -e 's/^orientationfilter=.*/orientationfilter="v"/' $LLCONFV
          sed -i -e "s/title =\".*$TEXT_ORIENTATIONFILTER$TEXT_OFF\"/title =\"\\xB7$TEXT_ORIENTATIONFILTER$TEXT_ON\"/" $CFGSETTINGS
        else
          orientation_filter="N"
          hash_menu="$TEXT_GAME_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_ORIENTATIONFILTER$TEXT_OFF"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/orientation_filter=./orientation_filter=N/' "$CONFIGFILE"
          sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFH
          sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFV
          sed -i -e "s/title =\".*$TEXT_ORIENTATIONFILTER$TEXT_ON\"/title =\"$TEXT_ORIENTATIONFILTER$TEXT_OFF\"/" $CFGSETTINGS
        fi
        sync
        save_orientation_settings
        GENERATFLAG=1
      ;;

      # Obsolete, not in use anymore      
      quickedit )
        if [ "$quickedit_mode" = "Y" ]; then
          if [ "$status_messages" = "Y" ]; then
            echo "... Normal edit mode"
          fi
          quickedit_mode="N"
          hash_menu="$menu_options"
          hash_mark=""
          hash_title="$TEXT_QUICK_EDIT_MODE"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/quickedit_mode=./quickedit_mode=N/' "$CONFIGFILE"
          quickedit_changed=1
          clear_gameselect_flags
        else
          if [ "$status_messages" = "Y" ]; then
            echo "... Quick edit mode"
          fi
          quickedit_mode="Y"
          hash_menu="$menu_options"
          hash_mark="B7"
          hash_title="$TEXT_QUICK_EDIT_MODE"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/quickedit_mode=./quickedit_mode=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_QUICK_EDIT_MODE\"/title =\"\xB7$TEXT_QUICK_EDIT_MODE\"/" $CFGGAMES
          if [ "$favmenu_select_flag" = "1" ] || [ "$secondmenu_select_flag" = "1" ] || [ "$favmenu_deelect_flag" = "1" ] || [ "$secondmenu_deselect_flag" = "1" ] || [ "$set_4_8_way_flag" = "1" ]; then
            menu_mark_quickedit
          fi
        fi
      ;;

      # "Apply Changes" menu item
      quickedit_apply )
        quickedit_changed=1
        clear_gameselect_flags
      ;;

### Game Settings menu END ###

### Options Settings menu BEGIN ###

      toggleservostikoption )
        if [ "$toggle_servostik_option" = "Y" ]; then
          toggle_servostik_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_TOGGLE_SERVOSTIK_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/toggle_servostik_option=./toggle_servostik_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_TOGGLE_SERVOSTIK_OPTION/title =\"$TEXT_TOGGLE_SERVOSTIK_OPTION/" $CFGSETTINGS
        else
          toggle_servostik_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_TOGGLE_SERVOSTIK_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/toggle_servostik_option=./toggle_servostik_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_TOGGLE_SERVOSTIK_OPTION/title =\"\\xB7$TEXT_TOGGLE_SERVOSTIK_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      filtergamesoption )
        if [ "$filter_games_option" = "Y" ]; then
          filter_games_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_FILTER_GAMES_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/filter_games_option=./filter_games_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_FILTER_GAMES_OPTION/title =\"$TEXT_FILTER_GAMES_OPTION/" $CFGSETTINGS
        else
          filter_games_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_FILTER_GAMES_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/filter_games_option=./filter_games_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_FILTER_GAMES_OPTION/title =\"\\xB7$TEXT_FILTER_GAMES_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      groupgamesoption )
        if [ "$group_games_option" = "Y" ]; then
          group_games_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_GROUP_GAMES_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/group_games_option=./group_games_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GROUP_GAMES_OPTION/title =\"$TEXT_GROUP_GAMES_OPTION/" $CFGSETTINGS
        else
          group_games_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_GROUP_GAMES_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/group_games_option=./group_games_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_GROUP_GAMES_OPTION/title =\"\\xB7$TEXT_GROUP_GAMES_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      screensaveroption )
        if [ "$screensaver_option" = "Y" ]; then
          screensaver_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_SCREENSAVER_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/screensaver_option=./screensaver_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_SCREENSAVER_OPTION/title =\"$TEXT_SCREENSAVER_OPTION/" $CFGSETTINGS
        else
          screensaver_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_SCREENSAVER_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/screensaver_option=./screensaver_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_SCREENSAVER_OPTION/title =\"\\xB7$TEXT_SCREENSAVER_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      rebootoption )
        if [ "$reboot_option" = "Y" ]; then
          reboot_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_REBOOT_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/reboot_option=./reboot_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_REBOOT_OPTION/title =\"$TEXT_REBOOT_OPTION/" $CFGSETTINGS
        else
          reboot_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_REBOOT_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/reboot_option=./reboot_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_REBOOT_OPTION/title =\"\\xB7$TEXT_REBOOT_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      shutdownoption )
        if [ "$shutdown_option" = "Y" ]; then
          shutdown_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_SHUTDOWN_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/shutdown_option=./shutdown_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_SHUTDOWN_OPTION/title =\"$TEXT_SHUTDOWN_OPTION/" $CFGSETTINGS
        else
          shutdown_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_SHUTDOWN_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/shutdown_option=./shutdown_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_SHUTDOWN_OPTION/title =\"\\xB7$TEXT_SHUTDOWN_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      backupoption )
        if [ "$backup_option" != "Y" ]; then
          backup_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_BACKUP_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/backup_option=./backup_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_BACKUP_OPTION/title =\"\\xB7$TEXT_BACKUP_OPTION/" $CFGSETTINGS
        else
          backup_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_BACKUP_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/backup_option=./backup_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_BACKUP_OPTION/title =\"$TEXT_BACKUP_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

      restoreoption )
        if [ "$restore_option" != "Y" ]; then
          restore_option="Y"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_RESTORE_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/restore_option=./restore_option=Y/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_RESTORE_OPTION/title =\"\\xB7$TEXT_RESTORE_OPTION/" $CFGSETTINGS
        else
          restore_option="N"
          hash_menu="$TEXT_OPTIONS_MENU_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_RESTORE_OPTION"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/restore_option=./restore_option=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_RESTORE_OPTION/title =\"$TEXT_RESTORE_OPTION/" $CFGSETTINGS
        fi
        sync
        GENERATFLAG=1
      ;;

### Options Settings menu END ###

### Mame Settings menu BEGIN ###

      mame_current_config )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        selection=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$current_mameconfig" --menu "\nSelect MAME config" 11 25 1 1 "Config #1" 2 "Config #2" 3 "Config #3" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [ ! -z $selection ]; then
            cp "$MAMECONFIG" "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"$hardwaremode_current" &>/dev/null
            current_mameconfig="$selection"
            if [ -e "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"$hardwaremode_current" ]; then
              cp "$ADVMHOME/advmame.rc"_"$current_mameconfig"_"$hardwaremode_current" "$MAMECONFIG" &>/dev/null
            fi
            echo "$current_mameconfig" > "$ADVMHOME/advmame_current_config.txt"
            if ! grep -q "DO NOT EDIT THIS LINE" "$MAMECONFIG"; then
              sed -i '1 i\#\n' "$MAMECONFIG"
              case "$pi2scartmode_current" in
                Y )
                  sed -i '1 i\# Pi2Scart mode --- DO NOT EDIT THIS LINE ---' "$MAMECONFIG"
                ;;
                N )
                  sed -i '1 i\# Pi2Jamma mode --- DO NOT EDIT THIS LINE ---' "$MAMECONFIG"
                ;;
              esac
            fi 
            if ! grep -q "^# mameconfig=." "$MAMECONFIG"; then
              sed -i -e "/--- DO NOT EDIT THIS LINE ---/a # mameconfig=$current_mameconfig" $MAMECONFIG
            else
              sed -i -e "s/mameconfig=./mameconfig=$current_mameconfig/" $MAMECONFIG
            fi
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_ACTIVE_MAME_CONFIG$current_mameconfig/$MAX_MAMECONFIG"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
        fi
        clear
      ;;

      mame_button_layout )
        if [ "$mame_buttons" = "Y" ]; then
          mame_buttons="N"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_DISPLAY_BUTTON_LAYOUT"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*mame_buttons=.*/mame_buttons=N/' "$CONFIGFILE"
        else
          mame_buttons="Y"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_DISPLAY_BUTTON_LAYOUT"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*mame_buttons=.*/mame_buttons=Y/' "$CONFIGFILE"
        fi
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      mame_artwork_backdrop )
        if [ "$display_artwork_backdrop" = "no" ]; then
          display_artwork_backdrop="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_ARTWORK_BACKDROP"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_artwork_backdrop.*/display_artwork_backdrop yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_ARTWORK_BACKDROP/title =\"\\xB7$TEXT_ARTWORK_BACKDROP/" $CFGSETTINGS
        else
          display_artwork_backdrop="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_ARTWORK_BACKDROP"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_artwork_backdrop.*/display_artwork_backdrop no/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_ARTWORK_BACKDROP/title =\"$TEXT_ARTWORK_BACKDROP/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_artwork_overlay )
        if [ "$display_artwork_overlay" = "no" ]; then
          display_artwork_overlay="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_ARTWORK_OVERLAY"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_artwork_overlay.*/display_artwork_overlay yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_ARTWORK_OVERLAY/title =\"\\xB7$TEXT_ARTWORK_OVERLAY/" $CFGSETTINGS
        else
          display_artwork_overlay="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_ARTWORK_OVERLAY"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_artwork_overlay.*/display_artwork_overlay no/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_ARTWORK_OVERLAY/title =\"$TEXT_ARTWORK_OVERLAY/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_brightness )

        case $display_brightness in

          0.5 )
            display_brightness="1.0"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_BRIGHTNESS$display_brightness"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/display_brightness.*/display_brightness 1.0/' $MAMECONFIG
          ;;

          1.0 )
            display_brightness="1.5"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_BRIGHTNESS$display_brightness"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/display_brightness.*/display_brightness 1.5/' $MAMECONFIG
          ;;

          1.5 )
            display_brightness="0.5"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_BRIGHTNESS$display_brightness"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/display_brightness.*/display_brightness 0.5/' $MAMECONFIG
          ;;

          * )
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_BRIGHTNESS$display_brightness"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          ;;            

        esac
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      mame_gamma_custom )
        display_gamma=$custom_display_gamma
        hash_menu="$TEXT_MAME_SETTINGS"
        hash_mark="B7"
        hash_title="$TEXT_GAMMA$custom_display_gamma"
        hash_par="$par"
        hash_rom="pinhp"
        ll_hash
        sed -i -e "s/display_gamma.*/display_gamma $custom_display_gamma/" $MAMECONFIG
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      mame_gamma )
        case $display_gamma in

          0.5 )
            display_gamma="1.0"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_GAMMA$display_gamma"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/display_gamma.*/display_gamma 1.0/' $MAMECONFIG
          ;;

          1.0 )
            display_gamma="1.5"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_GAMMA$display_gamma"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/display_gamma.*/display_gamma 1.5/' $MAMECONFIG
          ;;

          1.5 )
            display_gamma="0.5"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_GAMMA$display_gamma"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/display_gamma.*/display_gamma 0.5/' $MAMECONFIG
          ;;

          * )
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_GAMMA$display_gamma"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash

          ;;            
        esac
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      mame_antialias )
        if [ "$display_antialias" = "no" ]; then
          display_antialias="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_VECTOR_ANTIALIAS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_antialias.*/display_antialias yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_VECTOR_ANTIALIAS/title =\"\\xB7$TEXT_VECTOR_ANTIALIAS/" $CFGSETTINGS
        else
          display_antialias="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_VECTOR_ANTIALIAS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_antialias.*/display_antialias no/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_VECTOR_ANTIALIAS/title =\"$TEXT_VECTOR_ANTIALIAS/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_vsync )
        if [ "$display_vsync" = "no" ]; then
          display_vsync="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_VSYNC"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_vsync.*/display_vsync yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_VSYNC/title =\"\\xB7$TEXT_VSYNC/" $CFGSETTINGS
        else
          display_vsync="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_VSYNC"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_vsync.*/display_vsync no/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_VSYNC/title =\"$TEXT_VSYNC/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_cheats )
        if [ "$misc_cheat" = "no" ]; then
          misc_cheat="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_ENABLE_CHEATS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/misc_cheat.*/misc_cheat yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_ENABLE_CHEATS/title =\"\\xB7$TEXT_ENABLE_CHEATS/" $CFGSETTINGS
        else
          misc_cheat="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_ENABLE_CHEATS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/misc_cheat.*/misc_cheat no/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_ENABLE_CHEATS/title =\"$TEXT_ENABLE_CHEATS/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_freeplay )
        if [ "$misc_freeplay" = "no" ]; then
          misc_freeplay="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_FREE_PLAY"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/misc_freeplay.*/misc_freeplay yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_FREE_PLAY/title =\"\\xB7$TEXT_FREE_PLAY/" $CFGSETTINGS
        else
          misc_freeplay="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_FREE_PLAY"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/misc_freeplay.*/misc_freeplay no/' $MAMECONFIG
          sed -i '/.*dipswitch.*free_play.*/d' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_FREE_PLAY/title =\"$TEXT_FREE_PLAY/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_cocktail )
        if [ "$misc_cocktail" = "no" ]; then
          misc_cocktail="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_COCKTAIL"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/misc_cocktail.*/misc_cocktail yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_COCKTAIL/title =\"\\xB7$TEXT_COCKTAIL/" $CFGSETTINGS
        else
          misc_cocktail="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_COCKTAIL"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/misc_cocktail.*/misc_cocktail no/' $MAMECONFIG
          sed -i '/.*dipswitch.*cocktail.*/d' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_COCKTAIL/title =\"$TEXT_COCKTAIL/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_idleexit )
      
        case $input_idleexit_seconds in
        
          0 )
            input_idleexit_seconds="60"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_IDLE_EXIT$TEXT_1_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e "s/input_idleexit.*/input_idleexit $input_idleexit_seconds/" $MAMECONFIG
          ;;
        
          60 )
            input_idleexit_seconds="300"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_IDLE_EXIT$TEXT_5_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e "s/input_idleexit.*/input_idleexit $input_idleexit_seconds/" $MAMECONFIG
          ;;
        
          300 )
            input_idleexit_seconds="600"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_IDLE_EXIT$TEXT_10_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e "s/input_idleexit.*/input_idleexit $input_idleexit_seconds/" $MAMECONFIG
          ;;
        
          600 )
            input_idleexit_seconds="1200"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_IDLE_EXIT$TEXT_20_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e "s/input_idleexit.*/input_idleexit $input_idleexit_seconds/" $MAMECONFIG
          ;;
        
          1200 )
            input_idleexit_seconds="0"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_IDLE_EXIT$TEXT_OFF"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e "s/input_idleexit.*/input_idleexit 0/" $MAMECONFIG
          ;;
        
          * )
            input_idleexit_seconds="0"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_IDLE_EXIT$TEXT_OFF"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e "s/input_idleexit.*/input_idleexit 0/" $MAMECONFIG
          ;;

        esac
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      set_custom_idleexit_seconds )
        pikeyd165_start "yesno"
        joy2key_start "yesno"
        setterm -cursor on
        input=$(dialog --inputbox "Enter seconds" 8 21 "$input_idleexit_seconds" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [ -n "$input" ] && [ "$input" -eq "$input" ] && [ "$input" -ge 10 ] &> /dev/null; then
          # Strip leading zeros
          # The $(()) sets up an arithmetic context and the 10# converts the number from base 10 to base 10 causing any leading zeros to be dropped
          input_idleexit_seconds=$((10#$input))
          sed -i -e "s/input_idleexit.*/input_idleexit $input_idleexit_seconds/" $MAMECONFIG
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_CUSTOM_IDLE_EXIT_TIME"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
        fi
        setterm -cursor off
      ;;

      mame_pausebrightness )
        if [ "$display_pausebrightness" = "1.0" ]; then
          display_pausebrightness="0.5"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_PAUSE_DIM_SCREEN"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_pausebrightness.*/display_pausebrightness 0.5/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_PAUSE_DIM_SCREEN/title =\"\\xB7$TEXT_PAUSE_DIM_SCREEN/" $CFGSETTINGS
        else
          display_pausebrightness="1.0"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_PAUSE_DIM_SCREEN"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/display_pausebrightness.*/display_pausebrightness 1.0/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_PAUSE_DIM_SCREEN/title =\"$TEXT_PAUSE_DIM_SCREEN/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_sound_normalize )
        if [ "$sound_normalize" = "no" ]; then
          sound_normalize="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_SOUND_NORMALIZE"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/sound_normalize.*/sound_normalize yes/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_SOUND_NORMALIZE/title =\"\\xB7$TEXT_SOUND_NORMALIZE/" $CFGSETTINGS
        else
          sound_normalize="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_SOUND_NORMALIZE"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/sound_normalize.*/sound_normalize no/' $MAMECONFIG
          sed -i -e "s/title =\".*$TEXT_SOUND_NORMALIZE/title =\"$TEXT_SOUND_NORMALIZE/" $CFGSETTINGS
        fi
        sync
      ;;

      mame_sound_mode )

        case $sound_mode in

          auto )
            sound_mode="mono"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_MONO_STEREO$TEXT_MONO"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/sound_mode.*/sound_mode mono/' $MAMECONFIG
          ;;

          mono )
            sound_mode="stereo"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_MONO_STEREO$TEXT_STEREO"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/sound_mode.*/sound_mode stereo/' $MAMECONFIG
          ;;

          stereo )
            sound_mode="surround"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_MONO_STEREO$TEXT_SURROUND"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/sound_mode.*/sound_mode surround/' $MAMECONFIG
          ;;

          surround )
            sound_mode="auto"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_MONO_STEREO$TEXT_AUTO"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/sound_mode.*/sound_mode auto/' $MAMECONFIG
          ;;

        esac
        generate_submenu "$SCRIPTS/generate_mame_settings_menu.sh"
      ;;

      mame_horizontal_display_rol )
        if [ "$horizontal_display_rol" = "no" ]; then
          horizontal_display_rol="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_H_GAMES_ROTATE_L"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's:^horizontal/display_rol.*:horizontal/display_rol yes:' $MAMECONFIG
          sed -i -e "s:title =\".*$TEXT_H_GAMES_ROTATE_L:title =\"\\xB7$TEXT_H_GAMES_ROTATE_L:" $CFGSETTINGS
        else
          horizontal_display_rol="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title=" $TEXT_H_GAMES_ROTATE_L"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's:^horizontal/display_rol.*:horizontal/display_rol no:' $MAMECONFIG
          sed -i -e "s:title =\".*$TEXT_H_GAMES_ROTATE_L:title =\" $TEXT_H_GAMES_ROTATE_L:" $CFGSETTINGS
        fi
        cleanup_all
      ;;

      mame_vertical_display_rol )
        if [ "$vertical_display_rol" = "no" ]; then
          vertical_display_rol="yes"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_V_GAMES_ROTATE_L"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's:^vertical/display_rol.*:vertical/display_rol yes:' $MAMECONFIG
          sed -i -e "s:title =\".*$TEXT_V_GAMES_ROTATE_L:title =\"\\xB7$TEXT_V_GAMES_ROTATE_L:" $CFGSETTINGS
        else
          vertical_display_rol="no"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title=" $TEXT_V_GAMES_ROTATE_L"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's:^vertical/display_rol.*:vertical/display_rol no:' $MAMECONFIG
          sed -i -e "s:title =\".*$TEXT_V_GAMES_ROTATE_L:title =\" $TEXT_V_GAMES_ROTATE_L:" $CFGSETTINGS
        fi
        cleanup_all
      ;;
      
      clear_all_hiscores )
        pikeyd165_start "yesno"
        joy2key_start "yesno"
        if [ "$CLEARED_HISCORES_FLAG" = "0" ]; then
          dialog --timeout 15 --begin 10 8 --title "pinHP Arcade Classics" --defaultno --yesno "\nClear Hiscores:\n\nAre you sure?" 9 22
        else
          dialog --timeout 15 --begin 10 8 --title "pinHP Arcade Classics" --defaultno --yesno "\nRestore Hiscores:\n\nAre you sure?" 9 22
        fi
        response=$?
        joy2key_stop
        clear
        if [ "$response" = "0" ]; then
          if [ "$CLEARED_HISCORES_FLAG" = "0" ]; then
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_UNDO_CLEAR_ALL_HISCORES"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            CLEARED_HISCORES_FLAG=1
            clear_hiscores
            sed -i -e "s/title =\"$TEXT_CLEAR_ALL_HISCORES/title =\"$TEXT_UNDO_CLEAR_ALL_HISCORES/" $CFGSETTINGS
            pikeyd165_start "anykey"
            joy2key_start "anykey"
            dialog --timeout 3 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n\nHiscores cleared" 9 22
            joy2key_stop
          else
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_CLEAR_ALL_HISCORES"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            CLEARED_HISCORES_FLAG=0
            restore_hiscores
            sed -i -e "s/title =\"$TEXT_UNDO_CLEAR_ALL_HISCORES/title =\"$TEXT_CLEAR_ALL_HISCORES/" $CFGSETTINGS
            pikeyd165_start "anykey"
            joy2key_start "anykey"
            dialog --timeout 3 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n\nHiscores restored" 9 22
            joy2key_stop
          fi
          sync
        fi
      ;;

      mame_auto_insert_coin )
        if [ "$auto_insert_coin" = "N" ]; then
          if ! grep -q "script_start1" $MAMECONFIG; then
            auto_insert_coin="Y"
            hash_menu="$TEXT_MAME_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_AUTO_INSERT_COIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i '/dir_rom/e cat /root/default/mame_auto_coin.txt' "$MAMECONFIG"
            sed -i -e 's/.*auto_insert_coin=.*/auto_insert_coin=Y/' "$CONFIGFILE"
            sed -i -e "s/title =\".*$TEXT_AUTO_INSERT_COIN/title =\"\\xB7$TEXT_AUTO_INSERT_COIN/" $CFGSETTINGS
          fi
        else
          if grep -q "# pinHP auto insert coin START #" $MAMECONFIG; then
            sed -i '/# pinHP auto insert coin START #/,/# pinHP auto insert coin END #/d' $MAMECONFIG
          fi
          auto_insert_coin="N"
          hash_menu="$TEXT_MAME_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_AUTO_INSERT_COIN"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*auto_insert_coin=.*/auto_insert_coin=N/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_AUTO_INSERT_COIN/title =\"$TEXT_AUTO_INSERT_COIN/" $CFGSETTINGS
        fi
        sync
      ;;

### Mame Settings menu END ###

### Control Settings menu BEGIN ###

      hardwaremode )
        check_hardwaremode
      ;;

      select_usb_gamepad )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        case $gamepad_current in
          $GAMEPAD_1 )
            gamepad_current_num=1
          ;;
          $GAMEPAD_2 )
            gamepad_current_num=2
          ;;
          $GAMEPAD_3 )
            gamepad_current_num=3
          ;;
          $GAMEPAD_4 )
            gamepad_current_num=4
          ;;
          $GAMEPAD_5 )
            gamepad_current_num=5
          ;;
          $GAMEPAD_6 )
            gamepad_current_num=6
          ;;
        esac
        gamepad_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$gamepad_current_num" --menu "\nSelect USB gamepad" 14 26 4 1 "$GAMEPAD_1" 2 "$GAMEPAD_2" 3 "$GAMEPAD_3" 4 "$GAMEPAD_4" 5 "$GAMEPAD_5" 6 "$GAMEPAD_6" 3>&1 1>&2 2>&3)
        if [ ! -z $gamepad_num ]; then
          gamepad_tmp="GAMEPAD_"$gamepad_num
          eval gamepad_current=\$$gamepad_tmp
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_USB_GAMEPAD$gamepad_current"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          cat /root/.lemonlauncher_common/gamepad_$gamepad_num.cfg /root/.lemonlauncherH/ll_conf.template > /root/.lemonlauncherH/lemonlauncher.conf
          cat /root/.lemonlauncher_common/gamepad_$gamepad_num.cfg /root/.lemonlauncherV/ll_conf.template > /root/.lemonlauncherV/lemonlauncher.conf
          generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
          clear
        fi
        joy2key_stop
      ;;

      enable_servostik )
        if [ -e /tmp/servostik_toggled ]; then
          rm /tmp/servostik_toggled
        fi
        if [ -e /tmp/servostik_state ]; then
          rm /tmp/servostik_state
        fi
        if [ "$servostik" = "Y" ]; then
          servostik="N"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_ENABLE_SERVOSTIK"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*servostik=.*/servostik=N/' "$CONFIGFILE"
        else
          servostik="Y"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_ENABLE_SERVOSTIK"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*servostik=.*/servostik=Y/' "$CONFIGFILE"
          bash "$SCRIPTS/toggle_servostik.sh" "$servostik_default"
        fi
        generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
        GENERATFLAG=1
      ;;

      servostik_default )
        if [ -e /tmp/servostik_toggled ]; then
          rm /tmp/servostik_toggled
        fi
        if [ -e /tmp/servostik_state ]; then
          rm /tmp/servostik_state
        fi
        case $servostik_default in
          4)
            servostik_default=8
            sed -i -e 's/.*servostik_default=.*/servostik_default=8/' "$CONFIGFILE"
          ;;
          8 )
            servostik_default=4
            sed -i -e 's/.*servostik_default=.*/servostik_default=4/' "$CONFIGFILE"
          ;;
        esac
        bash "$SCRIPTS/toggle_servostik.sh" "$servostik_default"
        hash_menu="$TEXT_CONTROL_SETTINGS"
        hash_mark="B7"
        hash_title="$TEXT_SERVOSTIK_DEFAULT$servostik_default"
        hash_par="$par"
        hash_rom="pinhp"
        ll_hash
        generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
      ;;

      set_4_8_way_games )
        exit_systemmenu
        clear_gameselect_flags
        set_4_8_way_flag=1
        generate_game_menu
        if [ "$quickedit_mode" = "Y" ]; then
          menu_mark_quickedit
        fi
        sed -i -e '/joy \?= \?"4"/s/title ="/title ="(4) /g' $CFGGAMES
        sed -i -e '/joy \?= \?"8"/s/title ="/title ="(8) /g' $CFGGAMES
        sed -i 's/sorted = true/sorted = false/g' $CFGGAMES
        # Remove anything (custom parameters) after the orientation parameter, Lemonlancher will crash otherwise
        sed -i 's/\(orientation =\"[vha]\" *\).*\(}\)/\1\2/' $CFGGAMES
        # Change menu text color to indicate this is not the regular game menu
        sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$MENUMARKCOLOR"' #pinHP_mark&/' /root/.lemonlauncherH/theme.conf
        sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$MENUMARKCOLOR"' #pinHP_mark&/' /root/.lemonlauncherV/theme.conf
        quickedit_changed=1
      ;;

      favbutton_behaviour )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"

        if [ "$servostik" = "Y" ]; then
          favbutton_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$favbutton" --menu "\nP2-Start button behaviour:\n" 15 34 1 1 "Add game to favourites" 2 "Change screen orientation" 3 "Activate screensaver" 4 "Delete Game" 5 "Toggle ServoStik" 6 "System Shutdown" 7 "Quick Menu" 3>&1 1>&2 2>&3)
        else
          favbutton_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$favbutton" --menu "\nP2-Start button behaviour:\n" 14 34 1 1 "Add game to favourites" 2 "Change screen orientation" 3 "Activate screensaver" 4 "Delete Game" 6 "System Shutdown" 7 "Quick Menu" 3>&1 1>&2 2>&3)
        fi
        if [ ! -z $favbutton_num ]; then
          favbutton=$favbutton_num
          sed -i -e "s/.*favbutton=.*/favbutton=$favbutton/g" "$CONFIGFILE"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_FAVBUTTON_BEHAVIOUR"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
        fi

        joy2key_stop
      ;;

      buttons_456 )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        buttons_456_tmp=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$buttons_456" --menu "\nNon-standard Jamma buttons" 13 31 3 0 "Buttons 4/5/6 disabled" - "----------------------" 4 "Enable Button 4" 5 "Enable Button 4/5" 6 "Enable Button 4/5/6" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [ ! -z $buttons_456_tmp ] && [ "$buttons_456_tmp" != "-" ]; then
          buttons_456=$buttons_456_tmp
          sed -i -e "s/.*buttons_456=.*/buttons_456=$buttons_456_tmp/g" "$CONFIGFILE"
        fi
        hash_menu="$TEXT_CONTROL_SETTINGS"
        hash_title="$TEXT_BUTTONS_456"
        hash_par="$par"
        hash_rom="pinhp"
        [ "$buttons_456" != "0" ] && hash_mark="B7" || hash_mark=""
        ll_hash
        generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
        pikeyd165_start "force"
      ;;

      clone_joysticks )
        if [ "$clone_joysticks" = "Y" ]; then
          clone_joysticks="N"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_CLONE_JOYSTICKS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*clone_joysticks=.*/clone_joysticks=N/' "$CONFIGFILE"
        else
          clone_joysticks="Y"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_CLONE_JOYSTICKS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*clone_joysticks=.*/clone_joysticks=Y/' "$CONFIGFILE"
        fi
        generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
        pikeyd165_start "force"
      ;;

      clone_buttons )
        if [ "$clone_buttons" = "Y" ]; then
          clone_buttons="N"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_CLONE_BUTTONS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*clone_buttons=.*/clone_buttons=N/' "$CONFIGFILE"
        else
          clone_buttons="Y"
          hash_menu="$TEXT_CONTROL_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_CLONE_BUTTONS"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*clone_buttons=.*/clone_buttons=Y/' "$CONFIGFILE"
        fi
        generate_submenu "$SCRIPTS/generate_control_settings_menu.sh"
        pikeyd165_start "force"
      ;;

      jamma_switch_test )
        pikeyd165_start "switchtest" "0.5"
        SWITCHREPORT="/tmp/switchreport"
        SWITCHTEST_LOG="$RPI2JAMMA/switchtest.log"
        bash $SCRIPTS/jamma_switchtest.sh "$SWITCHREPORT" "$SWITCHTEST_LOG"
        switchreport=$( sed -z 's/\n/\\n/g' "$SWITCHREPORT" )
        pikeyd165_stop
        cp /root/default/dialogrc_switchtest /tmp/.dialogrc
        export DIALOGRC=/tmp/.dialogrc
        dialog --no-cancel --ok-label "OK" --title "pinHP Arcade Classics" --pause "\n$switchreport\nReport saved to:\n  rpi2jamma/switchtest.log\n\n" 0 0 9
        unset DIALOGRC
        pikeyd165_start "anykey" 0.5
        setterm -cursor off
        dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n$switchreport\nReport saved to:\n  rpi2jamma/switchtest.log\n\n\n\n" 0 0
      ;;

### Control Settings menu END ###

### Filter Settings menu BEGIN ###

      filter_reset_lists )
        joy2key_start "yesno"
        pikeyd165_start "yesno" "2"
        dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nReset to default:\n\nAre you sure?\n\n" 0 0
        response=$?
        joy2key_stop
        clear
        if [ "$response" = "0" ]; then  
          rm $SETTINGS/filter_genre &> /dev/null
          rm $SETTINGS/filter_manufacturer &> /dev/null
          rm $SETTINGS/filter_system &> /dev/null
          source $SCRIPTS/filter_arrays.sh
          dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nFilter lists:\n\nReset OK\n\n" 0 0
          GENERATFLAG=1
        fi
      ;;

      filter_genre_add )
        unset menu_array
        declare -a menu_array
        menu_array[0]="0"
        menu_array[1]="ADD ALL"
        i=3 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        for line in "${ALL_GENRE[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          if [ -e "$SETTINGS/filter_genre" ]; then
            if grep -q "$line$" $SETTINGS/filter_genre; then
              line="(+) $line"
            fi
          fi
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#menu_array[@]}
        height=$((length / 2))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nAll available genres" 0 31 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -eq 0 ]; then
            IFS=$'\n' sorted_array=($(sort <<<"${ALL_GENRE[*]}"))
            unset IFS
            unset FILTER_ARRAY_GENRE
            FILTER_ARRAY_GENRE[0]="No filter"
            for item in "${sorted_array[@]}"
            do
              FILTER_ARRAY_GENRE+=("$item")
            done
            printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_genre
            unset sorted_array
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAdded all\n\n" 0 0
            joy2key_stop
          else
            ((indexnum--))
            selected_genre="${ALL_GENRE[indexnum]}"
            genre_exists="N"
            for item in "${FILTER_ARRAY_GENRE[@]}"
              do
                [ "$item" = "$selected_genre" ] && genre_exists="Y"
              done
            if [ "$genre_exists" = "N" ]; then
              FILTER_ARRAY_GENRE+=("$selected_genre")
              FILTER_ARRAY_GENRE[0]=""
              IFS=$'\n' sorted_array=($(sort <<<"${FILTER_ARRAY_GENRE[*]}"))
              unset IFS
              unset FILTER_ARRAY_GENRE
              FILTER_ARRAY_GENRE[0]="No filter"
              for item in "${sorted_array[@]}"
              do
                FILTER_ARRAY_GENRE+=("$item")
              done
              printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_genre
              unset sorted_array
              joy2key_start "anykey"
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAdded genre:\n\n'$selected_genre'\n\n" 0 0
            else
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAlready exists:\n\n'$selected_genre'\n\n" 0 0
            fi
            joy2key_stop
          fi
          GENERATFLAG=1       
        fi
      ;;

      filter_genre_remove )
        unset menu_array
        declare -a menu_array
        menu_array[0]="0"
        menu_array[1]="RESET TO DEFAULT"
        i=3 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_GENRE[@]}"
        do     
          if [ "$line" != "No filter" ]; then
            menu_array[ $i ]=$j
            (( j++ ))
            menu_array[ ($i + 1) ]=$line
            (( i=($i+2) ))
          fi
        done
        length=${#menu_array[@]}
        height=$((length / 2))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nRemove genre from list" 0 31 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -eq 0 ]; then
            rm $SETTINGS/filter_genre &> /dev/null
            source $SCRIPTS/filter_arrays.sh
          else
            selected_genre="${FILTER_ARRAY_GENRE[indexnum]}"
            FILTER_ARRAY_GENRE[0]=""
            FILTER_ARRAY_GENRE[$indexnum]=""
            IFS=$'\n' sorted_array=($(sort <<<"${FILTER_ARRAY_GENRE[*]}"))
            unset IFS
            unset FILTER_ARRAY_GENRE
            FILTER_ARRAY_GENRE[0]="No filter"
            for item in "${sorted_array[@]}"
            do
              FILTER_ARRAY_GENRE+=("$item")
            done
            printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_genre
            unset sorted_array
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nRemoved genre:\n\n'$selected_genre'\n\n" 0 0
          fi
          joy2key_stop
          GENERATFLAG=1       
        fi
      ;;

      filter_manufacturer_add )
        unset menu_array
        declare -a menu_array
        menu_array[0]="0"
        menu_array[1]="ADD ALL"
        i=3 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        for line in "${ALL_MANUFACTURER[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          if [ -e "$SETTINGS/filter_manufacturer" ]; then
            if grep -q "$line$" $SETTINGS/filter_manufacturer; then
              line="(+) $line"
            fi
          fi
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#menu_array[@]}
        height=$((length / 2))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nAll available manufacturers" 0 38 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -eq 0 ]; then
            display_dots="Y"
            IFS=$'\n' sorted_array=($(sort <<<"${ALL_MANUFACTURER[*]}"))
            unset IFS
            unset FILTER_ARRAY_MANUFACTURER
            FILTER_ARRAY_MANUFACTURER[0]="No filter"
            for item in "${sorted_array[@]}"
            do
              FILTER_ARRAY_MANUFACTURER+=("$item")
            done
            printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_manufacturer
            unset sorted_array
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAdded all\n\n" 0 0
            joy2key_stop
          else
            ((indexnum--))
            selected_manufacturer="${ALL_MANUFACTURER[indexnum]}"
            manufacturer_exists="N"
            for item in "${FILTER_ARRAY_MANUFACTURER[@]}"
              do
                [ "$item" = "$selected_manufacturer" ] && manufacturer_exists="Y"
              done
            if [ "$manufacturer_exists" = "N" ]; then
              FILTER_ARRAY_MANUFACTURER+=("$selected_manufacturer")
              FILTER_ARRAY_MANUFACTURER[0]=""
              IFS=$'\n' sorted_array=($(sort <<<"${FILTER_ARRAY_MANUFACTURER[*]}"))
              unset IFS
              unset FILTER_ARRAY_MANUFACTURER
              FILTER_ARRAY_MANUFACTURER[0]="No filter"
              for item in "${sorted_array[@]}"
              do
                FILTER_ARRAY_MANUFACTURER+=("$item")
              done
              printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_manufacturer
              unset sorted_array
              joy2key_start "anykey"
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAdded manufacturer:\n\n'$selected_manufacturer'\n\n" 0 0
            else
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAlready exists:\n\n'$selected_manufacturer'\n\n" 0 0
            fi
            joy2key_stop
          fi
          GENERATFLAG=1       
        fi
      ;;

      filter_manufacturer_remove )
        unset menu_array
        declare -a menu_array
        menu_array[0]="0"
        menu_array[1]="RESET TO DEFAULT"
        i=3 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_MANUFACTURER[@]}"
        do     
          if [ "$line" != "No filter" ]; then
            menu_array[ $i ]=$j
            (( j++ ))
            menu_array[ ($i + 1) ]=$line
            (( i=($i+2) ))
          fi
        done
        length=${#menu_array[@]}
        height=$((length / 2))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nRemove manufacturer from list" 0 38 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -eq 0 ]; then
            rm $SETTINGS/filter_manufacturer &> /dev/null
            source $SCRIPTS/filter_arrays.sh
          else
            selected_manufacturer="${FILTER_ARRAY_MANUFACTURER[indexnum]}"
            FILTER_ARRAY_MANUFACTURER[0]=""
            FILTER_ARRAY_MANUFACTURER[$indexnum]=""
            IFS=$'\n' sorted_array=($(sort <<<"${FILTER_ARRAY_MANUFACTURER[*]}"))
            unset IFS
            unset FILTER_ARRAY_MANUFACTURER
            FILTER_ARRAY_MANUFACTURER[0]="No filter"
            for item in "${sorted_array[@]}"
            do
              FILTER_ARRAY_MANUFACTURER+=("$item")
            done
            printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_manufacturer
            unset sorted_array
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nRemoved manufacturer:\n\n'$selected_manufacturer'\n\n" 0 0
          fi
          joy2key_stop
          GENERATFLAG=1       
        fi
      ;;

      filter_system_add )
        unset menu_array
        declare -a menu_array
        menu_array[0]="0"
        menu_array[1]="ADD ALL"
        i=3 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        for line in "${ALL_SYSTEM[@]}"
        do     
          menu_array[ $i ]=$j
          (( j++ ))
          if [ -e "$SETTINGS/filter_system" ]; then
            if grep -q "$line$" $SETTINGS/filter_system; then
              line="(+) $line"
            fi
          fi
          menu_array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done
        length=${#menu_array[@]}
        height=$((length / 2))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nAll available game systems" 0 38 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -eq 0 ]; then
            IFS=$'\n' sorted_array=($(sort <<<"${ALL_SYSTEM[*]}"))
            unset IFS
            unset FILTER_ARRAY_SYSTEM
            FILTER_ARRAY_SYSTEM[0]="No filter"
            for item in "${sorted_array[@]}"
            do
              FILTER_ARRAY_SYSTEM+=("$item")
            done
            printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_system
            unset sorted_array
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAdded all\n\n" 0 0
            joy2key_stop
          else
            ((indexnum--))
            selected_system="${ALL_SYSTEM[indexnum]}"
            system_exists="N"
            for item in "${FILTER_ARRAY_SYSTEM[@]}"
              do
                [ "$item" = "$selected_system" ] && system_exists="Y"
              done
            if [ "$system_exists" = "N" ]; then
              FILTER_ARRAY_SYSTEM+=("$selected_system")
              FILTER_ARRAY_SYSTEM[0]=""
              IFS=$'\n' sorted_array=($(sort <<<"${FILTER_ARRAY_SYSTEM[*]}"))
              unset IFS
              unset FILTER_ARRAY_SYSTEM
              FILTER_ARRAY_SYSTEM[0]="No filter"
              for item in "${sorted_array[@]}"
              do
                FILTER_ARRAY_SYSTEM+=("$item")
              done
              printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_system
              unset sorted_array
              joy2key_start "anykey"
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAdded system:\n\n'$selected_system'\n\n" 0 0
            else
              dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nAlready exists:\n\n'$selected_system'\n\n" 0 0
            fi
            joy2key_stop
          fi
          GENERATFLAG=1       
        fi
      ;;

      filter_system_remove )
        unset menu_array
        declare -a menu_array
        menu_array[0]="0"
        menu_array[1]="RESET TO DEFAULT"
        i=3 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        for line in "${FILTER_ARRAY_SYSTEM[@]}"
        do     
          if [ "$line" != "No filter" ]; then
            menu_array[ $i ]=$j
            (( j++ ))
            menu_array[ ($i + 1) ]=$line
            (( i=($i+2) ))
          fi
        done
        length=${#menu_array[@]}
        height=$((length / 2))
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.5"
        indexnum=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nRemove game system from list" 0 38 $height "${menu_array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $indexnum ]; then
          if [ "$indexnum" -eq 0 ]; then
            rm $SETTINGS/filter_system &> /dev/null
            source $SCRIPTS/filter_arrays.sh
          else
            selected_system="${FILTER_ARRAY_SYSTEM[indexnum]}"
            FILTER_ARRAY_SYSTEM[0]=""
            FILTER_ARRAY_SYSTEM[$indexnum]=""
            IFS=$'\n' sorted_array=($(sort <<<"${FILTER_ARRAY_SYSTEM[*]}"))
            unset IFS
            unset FILTER_ARRAY_SYSTEM
            FILTER_ARRAY_SYSTEM[0]="No filter"
            for item in "${sorted_array[@]}"
            do
              FILTER_ARRAY_SYSTEM+=("$item")
            done
            printf "%s\n" "${sorted_array[@]}" > $SETTINGS/filter_system
            unset sorted_array
            joy2key_start "anykey"
            dialog --timeout 3 --title "pinHP Arcade Classics" --msgbox "\nRemoved system:\n\n'$selected_system'\n\n" 0 0
          fi
          joy2key_stop
          GENERATFLAG=1       
        fi
      ;;

### Filter Settings menu END ###

### Screen Settings menu BEGIN ###

      screen_orientation_H )
        if [ "$screen_orientation" != "H" ] || [ "$favbutton_flag" = "Y" ]; then
          previous_orientation=$screen_orientation
          screen_orientation="H"
          sed -i -e 's/screen_orientation=./screen_orientation=H/' "$CONFIGFILE"
          sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_ORIENTATION_H/title =\"\xB7$TEXT_ORIENTATION_H/" $CFGSETTINGS
          ORIENTATION="H"
          sync
          if [ "$previous_orientation" = "A" ] || [ "$game_count" = "Y" ]; then
            GENERATFLAG=1
          fi
          game_count_flag=N
          game_count_before=$game_count
          orientation_filter_flag=N
          read_orientation_settings
          if [ "$game_count" != "$game_count_before" ]; then
            game_count_flag=Y
          fi
          if [ "$orientation_filter" = "Y" ] && [ "$game_count" = "Y" ]; then
            orientation_filter_flag=Y
          fi
          if  [ "$game_count_flag" = "Y" ] || [ "$orientation_filter_flag" = "Y" ] && [ "$favbutton_flag" = "Y" ] && [ "$SYSTEMMENU" != "1" ]; then
            generate_game_menu
          elif [ "$favbutton_flag" != "Y" ]; then
            hash_menu="$TEXT_SCREEN_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_ORIENTATION_H"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          fi
          bash "$SCRIPTS/auto_rotate_monitor.sh" "$screen_orientation" "$autorotate_gpio"
          generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
        fi
      ;;
  
      screen_orientation_V )
        if [ "$screen_orientation" != "V" ] || [ "$favbutton_flag" = "Y" ]; then
          previous_orientation=$screen_orientation
          screen_orientation="V"
          sed -i -e 's/screen_orientation=./screen_orientation=V/' "$CONFIGFILE"
          sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_ORIENTATION_V/title =\"\xB7$TEXT_ORIENTATION_V/" $CFGSETTINGS
          ORIENTATION="V"
          sync
          if [ "$previous_orientation" = "A" ] || [ "$game_count" = "Y" ]; then
            GENERATFLAG=1
          fi
          game_count_flag=N
          game_count_before=$game_count
          orientation_filter_flag=N
          read_orientation_settings
          if [ "$game_count" != "$game_count_before" ]; then
            game_count_flag=Y
          fi
          if [ "$orientation_filter" = "Y" ] && [ "$game_count" = "Y" ]; then
            orientation_filter_flag=Y
          fi
          if  [ "$game_count_flag" = "Y" ] || [ "$orientation_filter_flag" = "Y" ] && [ "$favbutton_flag" = "Y" ] && [ "$SYSTEMMENU" != "1" ]; then
            generate_game_menu
          elif [ "$favbutton_flag" != "Y" ]; then
            hash_menu="$TEXT_SCREEN_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_ORIENTATION_V"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
          fi
          bash "$SCRIPTS/auto_rotate_monitor.sh" "$screen_orientation" "$autorotate_gpio"
          generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
        fi
      ;;
  
      screen_orientation_A )
        if [ "$screen_orientation" != "A" ] || [ "$favbutton" = "2" ]; then
          screen_orientation="A"
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_ORIENTATION_A"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/screen_orientation=./screen_orientation=A/' "$CONFIGFILE"
          sed -i -e 's/title =".*Orientation/title =" Orientation/g' $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_ORIENTATION_A/title =\"\xB7$TEXT_ORIENTATION_A/" $CFGSETTINGS
          orientation_filter="N"
          sed -i -e 's/orientation_filter=./orientation_filter=N/' "$CONFIGFILE"
          sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFH
          sed -i -e 's/^orientationfilter=.*/orientationfilter=""/' $LLCONFV
          GENERATFLAG=1
          generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
        fi
      ;;
  
      screen_theme_1 )
        if [ "$screen_theme" != "1" ]; then
          screen_theme=1
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_MENU_SIZE$TEXT_MIDI"
          hash_par="$par"
          hash_rom="screen_theme_1"
          ll_hash
          sed -i -e 's/screen_theme=./screen_theme=1/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_MENU_SIZE$TEXT_MIDI/title =\"\xB7$TEXT_MENU_SIZE$TEXT_MIDI/g" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_MENU_SIZE$TEXT_MAXI/title =\" $TEXT_MENU_SIZE$TEXT_MAXI/" $CFGSETTINGS
          set_screen_theme
          set_video_options
          save_orientation_settings
          sync
        fi
      ;;
  
      screen_theme_2 )
        if [ "$screen_theme" != "2" ]; then
          screen_theme=2
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_MENU_SIZE$TEXT_MAXI"
          hash_par="$par"
          hash_rom="screen_theme_2"
          ll_hash
          sed -i -e 's/screen_theme=./screen_theme=2/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_MENU_SIZE$TEXT_MIDI/title =\" $TEXT_MENU_SIZE$TEXT_MIDI/g" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_MENU_SIZE$TEXT_MAXI/title =\"\xB7$TEXT_MENU_SIZE$TEXT_MAXI/" $CFGSETTINGS
          set_screen_theme
          set_video_options
          save_orientation_settings
          sync
        fi
      ;;

      color_mode_1 )
        if [ "$color_mode" != "1" ]; then
          color_mode=1
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_COLOR$TEXT_YELLOW"
          hash_par="$par"
          hash_rom="color_mode_1"
          ll_hash
          sed -i -e 's/color_mode=.*/color_mode=1/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_YELLOW/title =\"\xB7$TEXT_COLOR$TEXT_YELLOW/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_SILVER/title =\" $TEXT_COLOR$TEXT_SILVER/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_RAINBOW/title =\" $TEXT_COLOR$TEXT_RAINBOW/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_VIVID/title =\" $TEXT_COLOR$TEXT_VIVID/" $CFGSETTINGS
          set_screen_theme
          set_video_options
          save_orientation_settings
          sync
        fi
      ;;

      color_mode_2 )
        if [ "$color_mode" != "2" ]; then
          color_mode=2
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_COLOR$TEXT_SILVER"
          hash_par="$par"
          hash_rom="color_mode_2"
          ll_hash
          sed -i -e 's/color_mode=./color_mode=2/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_YELLOW/title =\" $TEXT_COLOR$TEXT_YELLOW/g" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_SILVER/title =\"\xB7$TEXT_COLOR$TEXT_SILVER/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_RAINBOW/title =\" $TEXT_COLOR$TEXT_RAINBOW/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_VIVID/title =\" $TEXT_COLOR$TEXT_VIVID/" $CFGSETTINGS
          set_screen_theme
          set_video_options
          save_orientation_settings
          sync
        fi
      ;;

      color_mode_3 )
        if [ "$color_mode" != "3" ]; then
          color_mode=3
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_COLOR$TEXT_RAINBOW"
          hash_par="$par"
          hash_rom="color_mode_3"
          ll_hash
          sed -i -e 's/color_mode=./color_mode=3/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_YELLOW/title =\" $TEXT_COLOR$TEXT_YELLOW/g" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_SILVER/title =\" $TEXT_COLOR$TEXT_SILVER/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_RAINBOW/title =\"\xB7$TEXT_COLOR$TEXT_RAINBOW/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_VIVID/title =\" $TEXT_COLOR$TEXT_VIVID/" $CFGSETTINGS
          set_screen_theme
          set_video_options
          save_orientation_settings
          sync
        fi
      ;;

      color_mode_4 )
        if [ "$color_mode" != "4" ]; then
          color_mode=4
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_COLOR$TEXT_VIVID"
          hash_par="$par"
          hash_rom="color_mode_4"
          ll_hash
          sed -i -e 's/color_mode=./color_mode=4/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_YELLOW/title =\" $TEXT_COLOR$TEXT_YELLOW/g" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_SILVER/title =\" $TEXT_COLOR$TEXT_SILVER/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_RAINBOW/title =\" $TEXT_COLOR$TEXT_RAINBOW/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_COLOR$TEXT_VIVID/title =\"\xB7$TEXT_COLOR$TEXT_VIVID/" $CFGSETTINGS
          set_screen_theme
          set_video_options
          save_orientation_settings
          sync
        fi
      ;;

      set_menu_text_size )
        if [ "$menu_text_size" = "1" ]; then
          menu_text_size="2"
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_MENU_TEXT_SIZE$TEXT_SMALL"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/menu_text_size=./menu_text_size=2/' "$CONFIGFILE"
        else
          menu_text_size="1"
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_MENU_TEXT_SIZE$TEXT_NORMAL"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/menu_text_size=./menu_text_size=1/' "$CONFIGFILE"
        fi
        sync
        save_orientation_settings
        set_screen_theme
        generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
      ;;

      set_menu_text_justify )

        case $menu_text_justify in
          center )
            menu_text_justify="left"
            hash_menu="$TEXT_SCREEN_SETTINGS"
            hash_mark=""
            hash_title="${TEXT_MENU_TEXT_JUSTIFY}${menu_text_justify^}"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
              do
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
              done
            sync
          ;;
          left )
            menu_text_justify="right"
            hash_menu="$TEXT_SCREEN_SETTINGS"
            hash_mark=""
            hash_title="${TEXT_MENU_TEXT_JUSTIFY}${menu_text_justify^}"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
              do
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
              done
            sync
          ;;
          right )
            menu_text_justify="center"
            hash_menu="$TEXT_SCREEN_SETTINGS"
            hash_mark=""
            hash_title="${TEXT_MENU_TEXT_JUSTIFY}${menu_text_justify^}"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
              do
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
                sed -i '/^list/,/^}/s/\sjustify =.*/ justify = '"$menu_text_justify"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
              done
            sync
          ;;
        esac
        set_screen_theme
        save_orientation_settings
        generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
      ;;

      set_menu_text_color )
        pikeyd165_start "yesno"
        joy2key_start "yesno"
        menu_text_color=$( sed -n '/^list/,/^}/p' "/root/.lemonlauncher/theme.conf" | grep "\scolor =.*" | awk '{print $3}' )
        menu_text_color_plain=${menu_text_color##0x}
        setterm -cursor on
        input=$(dialog --max-input 6 --inputbox "\nEnter hex color code\n(white = ffffff)" 11 24 "$menu_text_color_plain" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [[ "$input" =~ ^[0-9A-Fa-f]{6}$ ]]; then
          menu_text_color="0x$input"
          for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
            do
              sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
              sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
              sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
              sed -i '/^list/,/^}/s/\scolor =.*/ color = '"$menu_text_color"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
            done
          sync
          set_screen_theme
          save_orientation_settings
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark=""
          hash_title="${TEXT_MENU_TEXT_COLOR}${menu_text_color}"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
        fi
        setterm -cursor off
      ;;

      set_menu_highlight_color )
        pikeyd165_start "yesno"
        joy2key_start "yesno"
        menu_highlight_color=$( sed -n '/^list/,/^}/p' "/root/.lemonlauncher/theme.conf" | grep "\shover_color =.*" | awk '{print $3}' )
        menu_highlight_color_plain=${menu_highlight_color##0x}
        setterm -cursor on
        input=$(dialog --max-input 6 --inputbox "\nEnter hex color code\n(default = 0b7cc1)" 11 24 "$menu_highlight_color_plain" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [[ "$input" =~ ^[0-9A-Fa-f]{6}$ ]]; then
          menu_highlight_color="0x$input"
          for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
            do
              sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherH/bg$theme/theme_main.conf"
              sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherV/bg$theme/theme_main.conf"
              sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherH/bg$theme/theme_system.conf"
              sed -i '/^list/,/^}/s/\shover_color =.*/ hover_color = '"$menu_highlight_color"'/' "/root/.lemonlauncherV/bg$theme/theme_system.conf"
            done
          sync
          set_screen_theme
          save_orientation_settings
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark=""
          hash_title="${TEXT_MENU_HIGHLIGHT_COLOR}${menu_highlight_color}"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          generate_submenu "$SCRIPTS/generate_screen_settings_menu.sh"
        fi
        setterm -cursor off
      ;;
  
      screen_orientation_flip )
        if [ "$ll_flip" != "Y" ]; then
          ll_flip="Y"
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_SCREEN_UPSIDE_DOWN"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e "s/title =\".*$TEXT_SCREEN_UPSIDE_DOWN/title =\"\xB7$TEXT_SCREEN_UPSIDE_DOWN/" $CFGSETTINGS
          if grep -q ^display_rotate "/boot/config.txt"; then
            sed -i -e 's/^display_rotate.*/display_rotate=2/' /boot/config.txt
          else
            echo >> /boot/config.txt
            echo "display_rotate=2" >> /boot/config.txt
          fi
        else
          ll_flip="N"
          hash_menu="$TEXT_SCREEN_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_SCREEN_UPSIDE_DOWN"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e "s/title =\".*$TEXT_SCREEN_UPSIDE_DOWN/title =\"$TEXT_SCREEN_UPSIDE_DOWN/" $CFGSETTINGS
          if grep -q ^display_rotate "/boot/config.txt"; then
            sed -i -e 's/^display_rotate.*/display_rotate=0/' /boot/config.txt
          else
            echo >> /boot/config.txt
            echo "display_rotate=0" >> /boot/config.txt
          fi
        fi

        # Make sure obsolete old flip settings are disabled (required due to new "screen upside down" handling, since version 31OCT24)
        sed -i -e 's/^display_flipx.*/display_flipx no/' $MAMECONFIG
        sed -i -e 's/^display_flipy.*/display_flipy no/' $MAMECONFIG
        sed -i -e 's/^rotate.*/rotate = none/' $LLCONFH
        sed -i -e 's/^rotate.*/rotate = right/' $LLCONFV
        for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
        do
          sed -i -e " /#video_position_normal/ s/.*#position =/   position =/" "/root/.lemonlauncherH/bg$theme/theme_main.conf"
          sed -i -e " /#video_position_flip/ s/.*position =/  #position =/" "/root/.lemonlauncherH/bg$theme/theme_main.conf"
        done
        for ((theme=1; theme <= $INTERNAL_THEMES; theme++))
        do
          sed -i -e " /#video_position_normal/ s/.*#position =/   position =/" "/root/.lemonlauncherV/bg$theme/theme_main.conf"
          sed -i -e " /#video_position_flip/ s/.*position =/  #position =/" "/root/.lemonlauncherV/bg$theme/theme_main.conf"
        done

        set_video_options
        save_orientation_settings

        pikeyd165_start "yesno"
        joy2key_start "yesno"
        dialog --timeout 15 --yes-label "Reboot" --no-label "Later" --title "pinHP Arcade Classics" --yesno "\nReboot required\n\n" 0 0
        response=$?
        joy2key_stop
        [ "$response" != 1 ] && reboot_system

      ;;

      testcard )
        pikeyd165_start "spacequit"
        joy2key_start "spacequit"
        testcard_files=""
        testcard_files=$( ls -d $DEFAULT/testcard/* )
        if [ "$ORIENTATION" = "V" ]; then
          testcard_files="$DEFAULT/testcard_V.png $testcard_files"
          fbv $testcard_files
        else
          testcard_files="$DEFAULT/testcard_H.png $testcard_files"
          fbv $testcard_files
        fi
        sync
        joy2key_stop
        FBVRUN="Y"
      ;;

### Screen Settings menu END ###

### System Settings menu BEGIN ###

      autostart_game )
        exit_systemmenu
        clear_gameselect_flags
        no_autostart_markers
        autostart_game_flag=1
        ln -sf "/root/.lemonlauncherH/bg/backgroundH_autostart.png" /root/.lemonlauncherH/background.png
        ln -sf "/root/.lemonlauncherV/bg/backgroundV_autostart.png" /root/.lemonlauncherV/background.png
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonmarquees
        ln -sfn "/dev/null" /root/.lemonlauncher_common/lemonlogos
        sed -i '/id01.*hiddenfeatures/s/title =" " params ="hiddenfeatures"/title ="# '"$TEXT_NO_AUTOSTART"' #" params ="no_autostart"/' $CFGGAMES
      ;;
 
      autostart_last_game )
        no_autostart_markers
        sed -i -e 's/.*autostart_rom=.*/autostart_rom=/' "$CONFIGFILE"
        if [ "$autostart_last" != "Y" ]; then
          autostart_last="Y"
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_AUTOSTART_LAST_GAME"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          if [ ! -z "$lastgame" ]; then
            sed -i "s/.*autostart_rom=.*/autostart_rom=$lastgame/" "$CONFIGFILE"
          fi
        else
          autostart_last="N"
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_AUTOSTART_LAST_GAME"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
        fi
        sed -i "s/.*autostart_last=.*/autostart_last=$autostart_last/" "$CONFIGFILE"
        generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
      ;;

      no_autostart )
        clear_gameselect_flags
        no_autostart_markers
        autostart_last="N"
        quickedit_changed=1
        hash_menu="$TEXT_SYSTEM_SETTINGS"
        hash_mark="B7"
        hash_title="$TEXT_NO_AUTOSTART"
        hash_par="$par"
        hash_rom="pinhp"
        ll_hash
        sed -i "s/.*autostart_last=.*/autostart_last=$autostart_last/" "$CONFIGFILE"
        sed -i -e 's/.*autostart_rom=.*/autostart_rom=/' "$CONFIGFILE"
        sed -i -e "s/title =\".*$TEXT_NO_AUTOSTART/title =\"\xB7$TEXT_NO_AUTOSTART/" $CFGSETTINGS
        sync
      ;;
  
      autostart_screensaver )
        clear_gameselect_flags
        no_autostart_markers
        autostart_rom=$(cat $CONFIGFILE | grep -m 1 ^autostart_rom= | awk -F= '{print $2}')
        autostart_last="N"
        sed -i "s/.*autostart_last=.*/autostart_last=$autostart_last/" "$CONFIGFILE"
        if [ "$autostart_rom" != "screensaver" ]; then
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_BOOT_INTO_SCREENSAVER"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          autostart_rom="screensaver"
          sed -i -e 's/.*autostart_rom=.*/autostart_rom=screensaver/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_BOOT_INTO_SCREENSAVER/title =\"\xB7$TEXT_BOOT_INTO_SCREENSAVER/" $CFGSETTINGS
        else
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_BOOT_INTO_SCREENSAVER"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          autostart_rom=""
          sed -i -e 's/.*autostart_rom=.*/autostart_rom=/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_NO_AUTOSTART/title =\"\xB7$TEXT_NO_AUTOSTART/" $CFGSETTINGS
        fi
        sync          
      ;;

      idle_screensaver )
      
        case $screensaver_seconds in
        
          0 )
            screensaver_seconds="60"
            input_idleexit="60"
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_SCREENSAVER$TEXT_1_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/.*screensaver_seconds=.*/screensaver_seconds=60/' "$CONFIGFILE"
          ;;
        
          60 )
            screensaver_seconds="300"
            input_idleexit="300"
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_SCREENSAVER$TEXT_5_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/.*screensaver_seconds=.*/screensaver_seconds=300/' "$CONFIGFILE"
          ;;
        
          300 )
            screensaver_seconds="600"
            input_idleexit="600"
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_SCREENSAVER$TEXT_10_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/.*screensaver_seconds=.*/screensaver_seconds=600/' "$CONFIGFILE"
          ;;
        
          600 )
            screensaver_seconds="1200"
            input_idleexit="1200"
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark="B7"
            hash_title="$TEXT_SCREENSAVER$TEXT_20_MIN"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/.*screensaver_seconds=.*/screensaver_seconds=1200/' "$CONFIGFILE"
          ;;
        
          1200 )
            screensaver_seconds="0"
            input_idleexit="0"
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_IDLE_SCREENSAVER$TEXT_OFF"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/.*screensaver_seconds=.*/screensaver_seconds=0/' "$CONFIGFILE"
          ;;
        
          * )
            screensaver_seconds="0"
            input_idleexit="0"
            hash_menu="$TEXT_SYSTEM_SETTINGS"
            hash_mark=""
            hash_title="$TEXT_IDLE_SCREENSAVER$TEXT_OFF"
            hash_par="$par"
            hash_rom="pinhp"
            ll_hash
            sed -i -e 's/.*screensaver_seconds=.*/screensaver_seconds=0/' "$CONFIGFILE"
          ;;

        esac
        generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
      ;;

      set_custom_idle_screensaver )
        pikeyd165_start "yesno"
        joy2key_start "yesno"
        setterm -cursor on
        input=$(dialog --inputbox "Enter seconds" 8 21 "$screensaver_seconds" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [ -n "$input" ] && [ "$input" -eq "$input" ] && [ "$input" -ge 10 ] &> /dev/null; then
          # Strip leading zeros
          # The $(()) sets up an arithmetic context and the 10# converts the number from base 10 to base 10 causing any leading zeros to be dropped
          screensaver_seconds=$((10#$input))
          sed -i -e "s/screensaver_seconds=.*/screensaver_seconds=$screensaver_seconds/g" "$CONFIGFILE"
          generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
        fi
        setterm -cursor off
      ;;

      idle_screensaver_type )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        screensaver_type_tmp=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$screensaver_type" --menu "\nSelect screensaver" 21 30 11 1 "Straight dots" 2 "Diagonal dots" 3 "Small dots" 4 "Line plus" 5 "Line slash" 6 "Dot zero" 7 "Zebra" 8 "Random game" 9 "Videos" 10 "Videos (silent)" 11 "Fav. Videos" 12 "Fav. Videos (silent)" 13 "Random fav. game" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [ ! -z $screensaver_type_tmp ]; then
          screensaver_type=$screensaver_type_tmp
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_SCREENSAVER_TYPE$screensaver_type_tmp/13"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e "s/.*screensaver_type=.*/screensaver_type=$screensaver_type_tmp/g" "$CONFIGFILE"
          generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
          clear
          screen_saver
        fi
      ;;

      status_messages )
        if [ "$status_messages" = "Y" ]; then
          echo "... Status messages: OFF"
          status_messages="N"
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_STATUS_MESSAGES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*status_messages=.*/status_messages=N/' "$CONFIGFILE"
        else
          echo "... Status messages: ON"
          status_messages="Y"
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_STATUS_MESSAGES"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*status_messages=.*/status_messages=Y/' "$CONFIGFILE"
        fi
        generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
      ;;

      system_volume )
        pikeyd165_start "updown" "0.5"
        joy2key_start "updown"
        alsamixer
        setterm -cursor off
        joy2key_stop
      ;;

      system_boot_date )
        pikeyd165_start "updowntabenter" "0.5"
        joy2key_start "updowntabenter"
        current_date=$( date )
        date_mode_sel=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$date_mode" --menu "\nCurrent date:\n$current_date\n\nBoot system into:" 0 0 1 1 "Image date" 2 "Custom date" 3 "Last shutdown date" 3>&1 1>&2 2>&3)
        if [ $? -eq 0 ]; then
          if [ "$date_mode_sel" = "2" ]; then
            if [ -f "$DEFAULT/custom_boot_date.txt" ]; then
              day=$( cut -c 7-8 "$DEFAULT/custom_boot_date.txt" )
              month=$( cut -c 5-6 "$DEFAULT/custom_boot_date.txt" )
              year=$( cut -c 1-4 "$DEFAULT/custom_boot_date.txt" )
            else
              echo $VERSION > /tmp/version.txt
              day=$( cut -c 7-8 /tmp/version.txt )
              month=$( cut -c 5-6 /tmp/version.txt )
              year=$( cut -c 1-4 /tmp/version.txt )
            fi
            dat=$(dialog --title "My Calendar" --calendar "Select a date:" 0 0 $day $month $year 3>&1 1>&2 2>&3)
            if [ $? -eq 0 ]; then
              custom_boot_date="$dat 12:34"
              day=$( echo "$dat" | awk -F/ '{print $1}' )
              month=$( echo "$dat" | awk -F/ '{print $2}' )
              year=$( echo "$dat" | awk -F/ '{print $3}' )
              echo "$year$month$day" > $DEFAULT/custom_boot_date.txt
              date -s "$year$month$day 12:34" > /dev/null
            else
              date_mode_sel=$date_mode
            fi
          fi
          date_mode=$date_mode_sel
          sed -i -e "s/.*date_mode=.*/date_mode=$date_mode/g" "$CONFIGFILE"
        fi
        joy2key_stop
      ;;

      boot_into_gamelist )
        if [ "$boot_into_gamelist" = "Y" ]; then
          boot_into_gamelist="N"
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_BOOT_INTO_GAMELIST"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*boot_into_gamelist=.*/boot_into_gamelist=N/' "$CONFIGFILE"
        else
          boot_into_gamelist="Y"
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_BOOT_INTO_GAMELIST"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*boot_into_gamelist=.*/boot_into_gamelist=Y/' "$CONFIGFILE"
        fi
        generate_submenu "$SCRIPTS/generate_system_settings_menu.sh"
      ;;

      set_time_zone )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        bash "$SCRIPTS/timezone.sh"
        joy2key_stop
        setterm -cursor off
      ;;

      resize_data_partition )
        pikeyd165_start "yesno" "0.5"
        joy2key_start "yesno"

        echo > /tmp/diskspacetemp
        clear
        echo
        echo
        echo "... Calculating data size "
        # Write dots as progress indicator
        echo

        filecount=$( ls /mnt/data/rpi2jamma/roms_advmame | grep \.zip | wc -l )
        echo -n "... $filecount roms "
        (
          data_size_roms=$(du -c /mnt/data/rpi2jamma/roms_advmame | grep "total" | awk '{print $1}')
          echo "data_size_roms=$data_size_roms" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_roms / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/bios_advmame | grep \.zip | wc -l )
        echo -n "... $filecount bios "
        (
          data_size_bios=$(du -c /mnt/data/rpi2jamma/bios_advmame | grep "total" | awk '{print $1}')
          echo "data_size_bios=$data_size_bios" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_bios / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/snaps | grep \.png | wc -l )
        echo -n "... $filecount snaps "
        (
          data_size_snaps=$(du -c /mnt/data/rpi2jamma/snaps | grep "total" | awk '{print $1}')
          echo "data_size_snaps=$data_size_snaps" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_snaps / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/marquees | grep \.png | wc -l )
        echo -n "... $filecount marquees "
        (
          data_size_marquees=$(du -c /mnt/data/rpi2jamma/marquees | grep "total" | awk '{print $1}')
          echo "data_size_marquees=$data_size_marquees" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_marquees / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/logos | grep \.png | wc -l )
        echo -n "... $filecount logos "
        (
          data_size_logos=$(du -c /mnt/data/rpi2jamma/logos | grep "total" | awk '{print $1}')
          echo "data_size_logos=$data_size_logos" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_logos / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/buttons | grep \.png | wc -l )
        echo -n "... $filecount buttons "
        (
          data_size_buttons=$(du -c /mnt/data/rpi2jamma/buttons | grep "total" | awk '{print $1}')
          echo "data_size_buttons=$data_size_buttons" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_buttons / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/videos | grep \.mp4 | wc -l )
        echo -n "... $filecount videos "
        (
          data_size_videos=$(du -c /mnt/data/rpi2jamma/videos | grep "total" | awk '{print $1}')
          echo "data_size_videos=$data_size_videos" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_videos / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/samples_advmame | grep \.zip | wc -l )
        echo -n "... $filecount samples "
        (
          data_size_samples=$(du -c /mnt/data/rpi2jamma/samples_advmame | grep "total" | awk '{print $1}')
          echo "data_size_samples=$data_size_samples" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_samples / 1024 )) MB"

        filecount=$( ls /mnt/data/rpi2jamma/artwork_advmame | grep \.zip | wc -l )
        echo -n "... $filecount artwork "
        (
          data_size_artwork=$(du -c /mnt/data/rpi2jamma/artwork_advmame | grep "total" | awk '{print $1}')
          echo "data_size_artwork=$data_size_artwork" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done
        source /tmp/diskspacetemp
        echo " $(( data_size_artwork / 1024 )) MB"

        echo -n "... various files "
        (          
          data_size_total=$(du -c -s /mnt/data/rpi2jamma | grep "total" | awk '{print $1}')
          data_size_other=$(( data_size_total - data_size_roms ))
          disk_size_free=$(df | grep "/dev/root" | awk '{print $4}')
          tmp_size_free=$(df | grep "/tmp" | awk '{print $4}')
          old_part_size=$( parted /dev/mmcblk0 unit GiB print | grep "^ 3" | awk '{print $4}' )
          free_part_size=$( parted /dev/mmcblk0 unit GiB print free | grep "Free Space" | tail -n1 | awk '{print $3}' )
          echo "data_size_total=$data_size_total" >> /tmp/diskspacetemp
          echo "data_size_other=$data_size_other" >> /tmp/diskspacetemp
          echo "disk_size_free=$disk_size_free" >> /tmp/diskspacetemp
          echo "tmp_size_free=$tmp_size_free" >> /tmp/diskspacetemp
          echo "old_part_size=$old_part_size" >> /tmp/diskspacetemp
          echo "free_part_size=$free_part_size" >> /tmp/diskspacetemp
        ) &
        pid=$!
        while ps -a | awk '{print $1}' | grep -q "${pid}"
        do
          sleep 1
          echo -n "."
          sleep 1.5
        done

        source /tmp/diskspacetemp
        various_size=$(( data_size_total - data_size_roms - data_size_bios - data_size_snaps - data_size_marquees - data_size_logos - data_size_buttons - data_size_videos - data_size_samples - data_size_artwork ))
        echo " $(( various_size / 1024 )) MB"
        echo
        echo "... Total size: $(( data_size_total / 1024 )) MB"

        sleep 3

        dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\nData partition size: $old_part_size\n\nFree disk space: $free_part_size\n\n" 0 0
        if [ "$free_part_size" = "0.00GiB" ]; then
          dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n*** Attention ***\n\nNo free disk space.\n\nAborting ...\n\n" 0 0
        elif [ $data_size_roms -gt $tmp_size_free ]  || [ $data_size_other -gt $disk_size_free ]; then
          dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR ***\n\nNot enough memory\nfor data backup.\n\nAborting ...\n\n" 0 0
        else
          dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\n*** WARNING ***\n\nPartition operations are\ndangerous. Make sure you\nhave a current backup\nof your data!\n\nProceed with resize?\n\n" 0 0
          response=$?
          clear
          if [ "$response" = "0" ]; then
            ram_flag=0
            if [ $tmp_size_free -gt $data_size_total ]; then
              ram_flag=1
            fi
            bash "$SCRIPTS/resize_partition.sh" "$ram_flag"
            new_part_size=$( parted /dev/mmcblk0 unit GiB print | grep "^ 3" | awk '{print $4}' )
            dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\nOld partition size: $old_part_size\n\nNew partition size: $new_part_size\n\n" 0 0
          fi
        fi
        joy2key_stop
      ;;

      copy_sd_games )
        pikeyd165_start "yesno" "0.5"
        joy2key_start "yesno"
        dialog --timeout 15 --begin 10 3 --title "pinHP Arcade Classics" --defaultno --yesno "\nCopy games from SD to USB\n\nNo files will be overwritten." 9 33
        response=$?
        joy2key_stop
        clear
        echo
        echo
        if [ "$response" = "0" ]; then

          echo > /tmp/diskspacetemp
          clear
          echo
          echo
          echo "... Calculating disk space "
          # Write dots as progress indicator
          echo

          filecount=$( ls /mnt/data/rpi2jamma/roms_advmame | grep \.zip | wc -l )
          echo -n "... $filecount roms "
          (
            data_size_roms=$(du -c /mnt/data/rpi2jamma/roms_advmame | grep "total" | awk '{print $1}')
            echo "data_size_roms=$data_size_roms" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_roms / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/bios_advmame | grep \.zip | wc -l )
          echo -n "... $filecount bios "
          (
            data_size_bios=$(du -c /mnt/data/rpi2jamma/bios_advmame | grep "total" | awk '{print $1}')
            echo "data_size_bios=$data_size_bios" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_bios / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/snaps | grep \.png | wc -l )
          echo -n "... $filecount snaps "
          (
            data_size_snaps=$(du -c /mnt/data/rpi2jamma/snaps | grep "total" | awk '{print $1}')
            echo "data_size_snaps=$data_size_snaps" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_snaps / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/marquees | grep \.png | wc -l )
          echo -n "... $filecount marquees "
          (
            data_size_marquees=$(du -c /mnt/data/rpi2jamma/marquees | grep "total" | awk '{print $1}')
            echo "data_size_marquees=$data_size_marquees" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_marquees / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/logos | grep \.png | wc -l )
          echo -n "... $filecount logos "
          (
            data_size_logos=$(du -c /mnt/data/rpi2jamma/logos | grep "total" | awk '{print $1}')
            echo "data_size_logos=$data_size_logos" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_logos / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/buttons | grep \.png | wc -l )
          echo -n "... $filecount buttons "
          (
            data_size_buttons=$(du -c /mnt/data/rpi2jamma/buttons | grep "total" | awk '{print $1}')
            echo "data_size_buttons=$data_size_buttons" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_buttons / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/videos | grep \.mp4 | wc -l )
          echo -n "... $filecount videos "
          (
            data_size_videos=$(du -c /mnt/data/rpi2jamma/videos | grep "total" | awk '{print $1}')
            echo "data_size_videos=$data_size_videos" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_videos / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/samples_advmame | grep \.zip | wc -l )
          echo -n "... $filecount samples "
          (
            data_size_samples=$(du -c /mnt/data/rpi2jamma/samples_advmame | grep "total" | awk '{print $1}')
            echo "data_size_samples=$data_size_samples" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_samples / 1024 )) MB"

          filecount=$( ls /mnt/data/rpi2jamma/artwork_advmame | grep \.zip | wc -l )
          echo -n "... $filecount artwork "
          (
            data_size_artwork=$(du -c /mnt/data/rpi2jamma/artwork_advmame | grep "total" | awk '{print $1}')
            echo "data_size_artwork=$data_size_artwork" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_artwork / 1024 )) MB"

          data_size_sd=$(( data_size_roms + data_size_bios + data_size_snaps + data_size_marquees + data_size_logos + data_size_buttons + data_size_videos + data_size_samples + data_size_artwork ))
          # Add 100 MB overhead to be on the safe side
          data_size_sd=$(( data_size_sd + 102400 ))
          usb_size_free=$( df | grep "/mnt/usb" | awk '{print $4}' )
          data_size_sd_mb=$(( data_size_sd / 1024 ))
          usb_size_free_mb=$(( usb_size_free / 1024 ))
          echo
          echo
          echo "... Total copy: $data_size_sd_mb MB"
          sleep 1
          echo "... Free USB:  $usb_size_free_mb MB"
          sleep 2    

          if [ $usb_size_free -lt $data_size_sd ]; then
            dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR ***\n\nTotal: $data_size_sd_mb MB\nFree:  $usb_size_free_mb MB\n\nNot enough space on USB\n\nAborting ...\n\n" 0 0
            RPI2JAMMA="$DIR_SD/rpi2jamma"
          else
            echo "... ok"
            sleep 1

            mkdir -p /mnt/usb/rpi2jamma/roms_advmame
            mkdir -p /mnt/usb/rpi2jamma/bios_advmame
            mkdir -p /mnt/usb/rpi2jamma/snaps
            mkdir -p /mnt/usb/rpi2jamma/marquees
            mkdir -p /mnt/usb/rpi2jamma/logos
            mkdir -p /mnt/usb/rpi2jamma/buttons
            mkdir -p /mnt/usb/rpi2jamma/videos
            mkdir -p /mnt/usb/rpi2jamma/samples_advmame
            mkdir -p /mnt/usb/rpi2jamma/artwork_advmame
  
            ### roms ###
            copy_dirsource="/mnt/data/rpi2jamma/roms_advmame"
            copy_dirdest="/mnt/usb/rpi2jamma/roms_advmame"
            copy_info="Copy ROMs:"
            copy_filter="\.zip"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
  
            ### bios ###
            copy_dirsource="/mnt/data/rpi2jamma/bios_advmame"
            copy_dirdest="/mnt/usb/rpi2jamma/bios_advmame"
            copy_info="Copy BIOS:"
            copy_filter="\.zip"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### snaps ###
            copy_dirsource="/mnt/data/rpi2jamma/snaps"
            copy_dirdest="/mnt/usb/rpi2jamma/snaps"
            copy_info="Copy snaps:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### logos ###
            copy_dirsource="/mnt/data/rpi2jamma/logos"
            copy_dirdest="/mnt/usb/rpi2jamma/logos"
            copy_info="Copy logos:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### marquees ###
            copy_dirsource="/mnt/data/rpi2jamma/marquees"
            copy_dirdest="/mnt/usb/rpi2jamma/marquees"
            copy_info="Copy marquees:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### buttons ###
            copy_dirsource="/mnt/data/rpi2jamma/buttons"
            copy_dirdest="/mnt/usb/rpi2jamma/buttons"
            copy_info="Copy buttons:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### videos ###
            copy_dirsource="/mnt/data/rpi2jamma/videos"
            copy_dirdest="/mnt/usb/rpi2jamma/videos"
            copy_info="Copy videos:"
            copy_filter="\.mp4"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### samples ###
            copy_dirsource="/mnt/data/rpi2jamma/samples_advmame"
            copy_dirdest="/mnt/usb/rpi2jamma/samples_advmame"
            copy_info="Copy samples:"
            copy_filter="\.zip"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### artwork ###
            copy_dirsource="/mnt/data/rpi2jamma/artwork_advmame"
            copy_dirdest="/mnt/usb/rpi2jamma/artwork_advmame"
            copy_info="Copy artwork:"
            copy_filter="\.zip"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
          fi

        fi
        clear
        sync
      ;;

      copy_usb_games )
        pikeyd165_start "yesno" "0.5"
        joy2key_start "yesno"

        dialog --timeout 15 --begin 10 3 --title "pinHP Arcade Classics" --defaultno --yesno "\nCopy games from USB to SD\n\nNo files will be overwritten." 9 33
        response=$?
        if [ "$response" = "0" ] && [ -e "/mnt/usb/rpi2jamma" ]; then

          echo > /tmp/diskspacetemp
          clear
          echo
          echo
          echo "... Calculating disk space "
          # Write dots as progress indicator
          echo

          filecount=$( ls /mnt/usb/rpi2jamma/roms_advmame | grep \.zip | wc -l )
          echo -n "... $filecount roms "
          (
            data_size_roms=$(du -c /mnt/usb/rpi2jamma/roms_advmame | grep "total" | awk '{print $1}')
            echo "data_size_roms=$data_size_roms" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_roms / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/bios_advmame | grep \.zip | wc -l )
          echo -n "... $filecount bios "
          (
            data_size_bios=$(du -c /mnt/usb/rpi2jamma/bios_advmame | grep "total" | awk '{print $1}')
            echo "data_size_bios=$data_size_bios" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_bios / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/snaps | grep \.png | wc -l )
          echo -n "... $filecount snaps "
          (
            data_size_snaps=$(du -c /mnt/usb/rpi2jamma/snaps | grep "total" | awk '{print $1}')
            echo "data_size_snaps=$data_size_snaps" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_snaps / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/marquees | grep \.png | wc -l )
          echo -n "... $filecount marquees "
          (
            data_size_marquees=$(du -c /mnt/usb/rpi2jamma/marquees | grep "total" | awk '{print $1}')
            echo "data_size_marquees=$data_size_marquees" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_marquees / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/logos | grep \.png | wc -l )
          echo -n "... $filecount logos "
          (
            data_size_logos=$(du -c /mnt/usb/rpi2jamma/logos | grep "total" | awk '{print $1}')
            echo "data_size_logos=$data_size_logos" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_logos / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/buttons | grep \.png | wc -l )
          echo -n "... $filecount buttons "
          (
            data_size_buttons=$(du -c /mnt/usb/rpi2jamma/buttons | grep "total" | awk '{print $1}')
            echo "data_size_buttons=$data_size_buttons" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_buttons / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/videos | grep \.mp4 | wc -l )
          echo -n "... $filecount videos "
          (
            data_size_videos=$(du -c /mnt/usb/rpi2jamma/videos | grep "total" | awk '{print $1}')
            echo "data_size_videos=$data_size_videos" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_videos / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/samples_advmame | grep \.zip | wc -l )
          echo -n "... $filecount samples "
          (
            data_size_samples=$(du -c /mnt/usb/rpi2jamma/samples_advmame | grep "total" | awk '{print $1}')
            echo "data_size_samples=$data_size_samples" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_samples / 1024 )) MB"

          filecount=$( ls /mnt/usb/rpi2jamma/artwork_advmame | grep \.zip | wc -l )
          echo -n "... $filecount artwork "
          (
            data_size_artwork=$(du -c /mnt/usb/rpi2jamma/artwork_advmame | grep "total" | awk '{print $1}')
            echo "data_size_artwork=$data_size_artwork" >> /tmp/diskspacetemp
          ) &
          pid=$!
          while ps -a | awk '{print $1}' | grep -q "${pid}"
          do
            sleep 1
            echo -n "."
            sleep 1.5
          done
          source /tmp/diskspacetemp
          echo " $(( data_size_artwork / 1024 )) MB"

          data_size_total=$(( data_size_roms + data_size_bios + data_size_snaps + data_size_marquees + data_size_logos + data_size_buttons + data_size_videos + data_size_samples + data_size_artwork ))
          # Add 100 MB overhead to be on the safe side
          data_size_total=$(( data_size_total + 102400 ))
          disk_size_free=$(df | grep "/mnt/data" | awk '{print $4}')
          data_size_total_mb=$(( data_size_total / 1024 ))
          disk_size_free_mb=$(( disk_size_free / 1024 ))
          echo
          echo "... Total copy: $data_size_total_mb MB"
          sleep 1
          echo "... Free SD:  $disk_size_free_mb MB"
          sleep 2

          if [ $disk_size_free -lt $data_size_total ]; then
            dialog --timeout 15 --title "pinHP Arcade Classics" --msgbox "\n*** ERROR ***\n\nTotal: $data_size_total_mb MB\nFree:  $disk_size_free_mb MB\n\nNot enough space on SD card\n\nAborting ...\n\n" 0 0
          else

            echo "... ok"
            sleep 1
            mkdir -p /mnt/data/rpi2jamma/roms_advmame
            mkdir -p /mnt/data/rpi2jamma/bios_advmame
            mkdir -p /mnt/data/rpi2jamma/snaps
            mkdir -p /mnt/data/rpi2jamma/marquees
            mkdir -p /mnt/data/rpi2jamma/logos
            mkdir -p /mnt/data/rpi2jamma/buttons
            mkdir -p /mnt/data/rpi2jamma/videos
            mkdir -p /mnt/data/rpi2jamma/samples_advmame
            mkdir -p /mnt/data/rpi2jamma/artwork_advmame

            ### roms ###
            copy_dirsource="/mnt/usb/rpi2jamma/roms_advmame"
            copy_dirdest="/mnt/data/rpi2jamma/roms_advmame"
            copy_info="Copy ROMs:"
            copy_filter="\.zip"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"

            ### bios ###
            copy_dirsource="/mnt/usb/rpi2jamma/bios_advmame"
            copy_dirdest="/mnt/data/rpi2jamma/bios_advmame"
            copy_info="Copy BIOS:"
            copy_filter="\.zip"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### snaps ###
            copy_dirsource="/mnt/usb/rpi2jamma/snaps"
            copy_dirdest="/mnt/data/rpi2jamma/snaps"
            copy_info="Copy snaps:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### logos ###
            copy_dirsource="/mnt/usb/rpi2jamma/logos"
            copy_dirdest="/mnt/data/rpi2jamma/logos"
            copy_info="Copy logos:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### marquees ###
            copy_dirsource="/mnt/usb/rpi2jamma/marquees"
            copy_dirdest="/mnt/data/rpi2jamma/marquees"
            copy_info="Copy marquees:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### buttons ###
            copy_dirsource="/mnt/usb/rpi2jamma/buttons"
            copy_dirdest="/mnt/data/rpi2jamma/buttons"
            copy_info="Copy buttons:"
            copy_filter="\.png"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### videos ###
            copy_dirsource="/mnt/usb/rpi2jamma/videos"
            copy_dirdest="/mnt/data/rpi2jamma/videos"
            copy_info="Copy videos:"
            copy_filter="\.mp4"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### samples ###
            copy_dirsource="/mnt/usb/rpi2jamma/samples_advmame"
            copy_dirdest="/mnt/data/rpi2jamma/samples_advmame"
            copy_info="Copy samples:"
            copy_filter="\.mp4"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"
            
            ### artwork ###
            copy_dirsource="/mnt/usb/rpi2jamma/artwork_advmame"
            copy_dirdest="/mnt/data/rpi2jamma/artwork_advmame"
            copy_info="Copy artwork:"
            copy_filter="\.mp4"
            copy_gauge_dialog "$copy_dirsource" "$copy_dirdest" "$copy_info" "$copy_filter"

          fi
          sync
        clear
        fi
        joy2key_stop
      ;;

      run_external_file )
        ls $RPI2JAMMA -p | grep -v / > /tmp/rpi2jamma_files
        
        declare -a array
        i=2 # Array index
        j=1 # Visible menu item number to be displayed in menu list
        while read line
        do     
          array[ $i ]=$j
          (( j++ ))
          array[ ($i + 1) ]=$line
          (( i=($i+2) ))
        done < /tmp/rpi2jamma_files
        
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        num=$(dialog --timeout 30 --title "pinHP Arcade Classics" --menu "\nSelect file\nfrom 'rpi2jamma' directory" 0 0 0 "${array[@]}" 3>&1 1>&2 2>&3)
        joy2key_stop
        if [ ! -z $num ]; then
          joy2key_stop
          selected_file=$(sed "${num}q;d" /tmp/rpi2jamma_files)
          pikeyd165_start "yesno" "0.5"
          joy2key_start "yesno"
          dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nExecute file:\n$selected_file\n\nAre you sure?" 0 0
          response=$?
          joy2key_stop
          if [ "$response" = "0" ]; then
            cp $RPI2JAMMA/$selected_file /tmp/external_file
            chmod +x /tmp/external_file
            declare -p > /tmp/pinhp_variables
            clear
            echo
            echo
            (/tmp/external_file)
            cd /root
            setterm -cursor off
            rm /tmp/external_file
            rm /tmp/pinhp_variables
            if [ -e "/tmp/external_vars" ]; then
              source /tmp/external_vars
              rm /tmp/external_vars
            fi
            echo
            echo "... done"
            sleep 3
          fi
        fi
        rm /tmp/rpi2jamma_files
      ;;

      advmenu )
        advmenu_rc_dir_snap="dir_snap $RPI2JAMMA/snaps"
        if ! grep -Fxq "$advmenu_rc_dir_snap" $ADVMHOME/advmame.rc; then
          sed -i -e "s!^dir_snap.*!$advmenu_rc_dir_snap!" $ADVMHOME/advmame.rc
        fi
        pikeyd165_start "advmenu"
        /usr/bin/taskset -c 3 /root/local/bin/advmenu    
        if ! grep -Fxq "$advmame_rc_dir_snap" $ADVMHOME/advmame.rc; then
          sed -i -e "s!^dir_snap.*!$advmame_rc_dir_snap!" $ADVMHOME/advmame.rc
        fi
        pikeyd165_start "default"
      ;;
  
      autostart_advmenu )
        clear_gameselect_flags
        no_autostart_markers
        autostart_rom=$(cat $CONFIGFILE | grep -m 1 ^autostart_rom= | awk -F= '{print $2}')
        autostart_last="N"
        sed -i "s/.*autostart_last=.*/autostart_last=$autostart_last/" "$CONFIGFILE"
        if [ "$autostart_rom" != "advmenu" ]; then
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_AUTOSTART_ADVMENU"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          autostart_rom="advmenu"
          sed -i -e 's/.*autostart_rom=.*/autostart_rom=advmenu/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_AUTOSTART_ADVMENU/title =\"\xB7$TEXT_AUTOSTART_ADVMENU/" $CFGSETTINGS
        else
          hash_menu="$TEXT_SYSTEM_SETTINGS"
          hash_mark=""
          hash_title="$TEXT_AUTOSTART_ADVMENU"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          autostart_rom=""
          sed -i -e 's/.*autostart_rom=.*/autostart_rom=/' "$CONFIGFILE"
          sed -i -e "s/title =\".*$TEXT_AUTOSTART_ADVMENU/title =\"$TEXT_AUTOSTART_ADVMENU/" $CFGSETTINGS
          sed -i -e "s/title =\".*$TEXT_NO_AUTOSTART/title =\"\xB7$TEXT_NO_AUTOSTART/" $CFGSETTINGS
        fi
        sync          
      ;;

### System Settings menu END ###

### Language Settings menu BEGIN ###

      keyboard_layout )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"

        case $current_keyboard_layout in
          $keymap_1 )
            keymap_current_num=1
          ;;
          $keymap_2 )
            keymap_current_num=2
          ;;
          $keymap_3 )
            keymap_current_num=3
          ;;
        esac

        keymap_num=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "$keymap_current_num" --menu "\nSelect keyboard layout\n\n(Reboot required)\n" 0 0 1 1 "$keymap_1" 2 "$keymap_2" 3 "$keymap_3" 3>&1 1>&2 2>&3)
        if [ ! -z $keymap_num ]; then
          case $keymap_num in
            1 )
              current_keyboard_layout="$keymap_1"
            ;;
            2 )
              current_keyboard_layout="$keymap_2"
            ;;
            3 )
              current_keyboard_layout="$keymap_3"
            ;;
          esac
          sed -i -e "s/.*current_keyboard_layout=.*/current_keyboard_layout=$current_keyboard_layout/g" "$CONFIGFILE"
          hash_menu="$TEXT_LANGUAGE_SETTINGS"
          hash_mark="B7"
          hash_title="$TEXT_KEYBOARD$current_keyboard_layout"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
        generate_submenu "$SCRIPTS/generate_language_settings_menu.sh"
        fi

        joy2key_stop
      ;;

      language_single_menu_title )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$single_menu_title"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}single_menu_title=.*${DELIM}single_menu_title=$input${DELIM}" "$CONFIGFILE"
          single_menu_title="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_title_1_of_2 )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_title_1_of_2"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_title_1_of_2=.*${DELIM}menu_title_1_of_2=$input${DELIM}" "$CONFIGFILE"
          menu_title_1_of_2="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_title_2_of_2 )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_title_2_of_2"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_title_2_of_2=.*${DELIM}menu_title_2_of_2=$input${DELIM}" "$CONFIGFILE"
          menu_title_2_of_2="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_title_1_of_3 )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_title_1_of_3"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_title_1_of_3=.*${DELIM}menu_title_1_of_3=$input${DELIM}" "$CONFIGFILE"
          menu_title_1_of_3="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_title_2_of_3 )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_title_2_of_3"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_title_2_of_3=.*${DELIM}menu_title_2_of_3=$input${DELIM}" "$CONFIGFILE"
          menu_title_2_of_3="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_title_3_of_3 )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_title_3_of_3"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_title_3_of_3=.*${DELIM}menu_title_3_of_3=$input${DELIM}" "$CONFIGFILE"
          menu_title_3_of_3="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_options )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_options"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_options=.*${DELIM}menu_options=$input${DELIM}" "$CONFIGFILE"
          menu_options="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_back )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_back"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_back=.*${DELIM}menu_back=$input${DELIM}" "$CONFIGFILE"
          menu_back="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_screensaver )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_screensaver"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_screensaver=.*${DELIM}menu_screensaver=$input${DELIM}" "$CONFIGFILE"
          menu_screensaver="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_reboot )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_reboot"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_reboot=.*${DELIM}menu_reboot=$input${DELIM}" "$CONFIGFILE"
          menu_reboot="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_shutdown )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_shutdown"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_shutdown=.*${DELIM}menu_shutdown=$input${DELIM}" "$CONFIGFILE"
          menu_shutdown="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_backup )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_backup"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_backup=.*${DELIM}menu_backup=$input${DELIM}" "$CONFIGFILE"
          menu_backup="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_restore )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_restore"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_restore=.*${DELIM}menu_restore=$input${DELIM}" "$CONFIGFILE"
          menu_restore="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

      language_menu_about )
        loadkeys "$current_keyboard_layout"
        dialog_convert_utf8 "$menu_about"
        if ! [[ -z "${input// }" ]]; then
          sed -i -e "s${DELIM}menu_about=.*${DELIM}menu_about=$input${DELIM}" "$CONFIGFILE"
          menu_about="$input"
          escape_menu_titles
          GENERATFLAG=1
        fi
        loadkeys "us"
      ;;

### Language Settings menu END ###

### Backup/Restore menu BEGIN ###
  
    	backup )
  	    backup_advmame
      ;;
   
    	restore )
  	    restore_advmame
      ;;

      favgames_backup )
        pikeyd165_start "yesno" "0.5"
        joy2key_start "yesno"
        dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nBackup fav. settings\n\nto rpi2jamma/backup\n\n" 0 0
        response=$?
        clear
        if [ "$response" = "0" ]; then
          favcount=$( grep -E "(1ONE|1TWO|1TRE|0ALL|1FAV)" $TEMPLATEFILE | grep -v "_DUMMY" | wc -l )
          mkdir -p $RPI2JAMMA/backup/rpi2jamma/roms_advmame      
          cp  $ROMS_ADVM/_games.template $RPI2JAMMA/backup/rpi2jamma/roms_advmame/
         
        counter=0
        (
        # Set while loop until 100 %, simulation copy progress 
        while :
        do
cat <<EOF
XXX
$counter
\nBackup count:\n\n$favcount game definitions
XXX
EOF
        (( counter+=10 ))
        [ $counter -gt 100 ] && break
        sleep 0.05
        done
        ) |
        dialog --title "pinHP Arcade Classics" --gauge "Please wait" 10 26
        setterm -cursor off
        sleep 2         
          
        fi
        joy2key_stop
      ;;

      favgames_restore )
        pikeyd165_start "yesno" "0.5"
        joy2key_start "yesno"
        FAVGAMES="/tmp/favgames.template"

        dialog --timeout 15 --title "pinHP Arcade Classics" --defaultno --yesno "\nRestore fav. settings\n\nfrom rpi2jamma/backup" 10 26
        response=$?
        clear
        if [ "$response" = "0" ]; then
          if [ -e "$RPI2JAMMA/backup/rpi2jamma/roms_advmame/_games.template" ]; then
            grep -E "(1ONE|1TWO|1TRE|0ALL|1FAV)" "$RPI2JAMMA/backup/rpi2jamma/roms_advmame/_games.template" | grep -v "_DUMMY" > "$FAVGAMES"
            favlines=$(cat "$FAVGAMES" | wc -l)
          fi

          if [ -e "$FAVGAMES" ] && [ "$favlines" -ne 0 ]; then
            default_params="-0ONE-0TWO-0TRE-1ALL-0FAV"
            cat $TEMPLATEFILE | grep -v \"_DUMMY\" | sed -i "s/params =\".*FAV\"/params =\"$default_params\"/g"
            dialog --title "pinHP Arcade Classics" --gauge "\n Restoring: $current_rom\n\n 0 / $favlines " 10 26 < <(
    
            i=0
            while read favline
            do
            # Calculate progress
            percent=$(( 100*(++i)/favlines ))

# Update dialog box 
cat <<EOF
XXX
$percent
\n Restoring: $current_rom\n\n $i / $favlines
XXX
EOF

            current_rom=$( echo "$favline" | awk -F'"' '{print $2}' )
            backup_params=$( cat "$FAVGAMES" | grep "rom =\"$current_rom\"" | awk -F'"' '{print $6}' )
            sed -i "/rom =\"$current_rom\"/s/params =\".*FAV\"/params =\"$backup_params\"/" $TEMPLATEFILE 
            done < $FAVGAMES
    
            )
            setterm -cursor off
            sleep 2
          else
            dialog --timeout 5 --title "pinHP Arcade Classics" --msgbox "\n\nNo backup found\n\n" 0 0
          fi
          rm $FAVGAMES &> /dev/null
        
        fi
        joy2key_stop
      ;;

### Backup/Restore menu END ###

### Online Tools menu BEGIN ###

      wifi_menu )
        pikeyd165_start "updowntabenter"
        joy2key_start "updowntabenter"
        setterm -cursor on
        wifi-menu
        response=$?
        if [ "$response" = "0" ]; then
          netctl disable "$last_wifi_profile"
          autoconnect_wifi=          
        fi
        joy2key_stop
        setterm -cursor off
        SECONDS=0
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      quick_connect )
        get_active_wifi_profile
        get_last_wifi_profile
        if [ "$last_wifi_profile" != "n/a" ] && [ "$active_wifi_profile" = "n/a" ]; then
          netctl start "$last_wifi_profile"
        fi
        if [ "$active_wifi_profile" != "n/a" ]; then
          hash_menu="$TEXT_ONLINE_TOOLS"
          hash_mark="B7"
          hash_title="$TEXT_ACTIVE_PROFILE$active_wifi_profile"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
        fi
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      auto_connect )
        get_last_wifi_profile
        if [ "$last_wifi_profile" != "n/a" ]; then
          if [ -n "$autoconnect_wifi" ]; then
            netctl disable "$last_wifi_profile" > /dev/null
            autoconnect_wifi=
            hash_mark=""
          else
            netctl start "$last_wifi_profile"
            netctl enable "$last_wifi_profile" > /dev/null
            autoconnect_wifi="Y"
            hash_mark="B7"
          fi
          hash_menu="$TEXT_ONLINE_TOOLS"
          hash_title="$TEXT_AUTO_CONNECT$last_wifi_profile"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
        fi
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      show_ip )
        current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
        if [ $SECONDS -lt 20 ]; then
          response=0
          pikeyd165_start "yesno" "0.5"
          joy2key_start "yesno"
          while [ "$current_ip" = "" ] && [ "$response" = "0" ]
          do
            current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
            dialog --timeout 15 --begin 9 9 --title "pinHP Arcade Classics" --yes-label "Retry" --no-label "Cancel" --yesno "\nIP address:\n\n* No network *\n\nIP assignment might take some seconds." 12 23
            response=$?
            clear
            sleep 0.5
          done
          joy2key_stop
        else
          current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
          if [ "$current_ip" = "" ]; then
            dialog_no_network
          fi
        fi
        clear
        if [ "$current_ip" != "" ]; then
          dialog_current_ip
        fi
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      disconnect_wifi )
        netctl list | grep "\* " > /tmp/netlist.tmp
        if grep "\* " "/tmp/netlist.tmp"; then
          netlist=$(cat /tmp/netlist.tmp)  
          pikeyd165_start "yesno" "0.5"
          joy2key_start "yesno"
          dialog --timeout 15 --begin 10 6 --title "pinHP Arcade Classics" --defaultno --yesno "\nDisconnecting:\n\n$netlist\n\nAre you sure?" 0 0
          response=$?
          joy2key_stop
          if [ "$response" = "0" ]; then
            netctl stop-all
          fi
        fi
        current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
        if [ "$current_ip" = "" ]; then
          dialog_no_network
        else
          dialog_current_ip
        fi
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      remove_wifi_profiles )
        ls -p /etc/netctl | grep -v / >/tmp/netprofiles.txt
        netprofiles_count=$(ls -p /etc/netctl | grep -v / | wc -l)
        netprofiles=$(sed 's/$/\\n/' "/tmp/netprofiles.txt" | tr -d '\n')
        if [ "$netprofiles_count" -eq 0 ]; then
          pikeyd165_start "anykey" "0.5"
          joy2key_start "anykey"
          dialog --timeout 3 --begin 10 8 --title "pinHP Arcade Classics" --msgbox "\n\nNo profile found" 9 22
          joy2key_stop
        else
          pikeyd165_start "yesno" "0.5"
          joy2key_start "yesno"
          if [ "$netprofiles_count" -gt 1 ]; then
            dialog --timeout 15 --begin 9 5 --title "pinHP Arcade Classics" --defaultno --yesno "\nRemove $netprofiles_count Wi-Fi profiles:\n\n$netprofiles\nAre you sure?\n\n" 0 0
          else
            dialog --timeout 15 --begin 9 5 --title "pinHP Arcade Classics" --defaultno --yesno "\nRemove Wi-Fi profile:\n\n$netprofiles\nAre you sure?\n\n" 0 0
          fi
          response=$?
          joy2key_stop
          if [ "$response" = "0" ]; then
            netctl stop-all
            netctl disable "$last_wifi_profile" > /dev/null
            autoconnect_wifi=
            rm /etc/netctl/* &> /dev/null
            rm $DEFAULT/last_wifi_profile &> /dev/null
          fi
        fi
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      mail_alarm )
        if [ "$mail_alarm" = "Y" ]; then
          mail_alarm="N"
          hash_menu="$TEXT_ONLINE_TOOLS"
          hash_mark=""
          hash_title="$TEXT_MAIL_ALARM"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*mail_alarm=.*/mail_alarm=N/' "$CONFIGFILE"
          LOGLEVEL=0
          LOGLEVEL=$(cat "$MAIL_DIR/config.ini" | grep -v "#" | grep -m 1 LOGLEVEL= | awk -F= '{print $2}' | grep -o "[0123]")
          currentdate=$(date)
          echo "$currentdate Disabled" >> $MAIL_TEMPLOG
          if [ "$LOGLEVEL" -ge 1 ]; then
            echo "$currentdate Disabled" >> $MAIL_PERMLOG
          fi
        else
          mail_alarm="Y"
          hash_menu="$TEXT_ONLINE_TOOLS"
          hash_mark="B7"
          hash_title="$TEXT_MAIL_ALARM"
          hash_par="$par"
          hash_rom="pinhp"
          ll_hash
          sed -i -e 's/.*mail_alarm=.*/mail_alarm=Y/' "$CONFIGFILE"
        fi
        rm /tmp/alarmscript_run &> /dev/null
        generate_submenu "$SCRIPTS/generate_online_tools_menu.sh"
      ;;

      test_alarm_mail )
        current_ip=$(ip route list | grep default | awk '{print $9 " [" $5 "]"}')
          if [ "$current_ip" = "" ]; then
            dialog_no_network
          else
            pikeyd165_start "enterkey" "0.5"
            joy2key_start "enterkey"
            LOGLEVEL=0
            LOGLEVEL=$(cat "$MAIL_DIR/config.ini" | grep -v "#" | grep -m 1 LOGLEVEL= | awk -F= '{print $2}' | grep -o "[0123]")
            currentdate=$(date)
            date >> $MAIL_TEMPLOG
            echo "[TEST] Sending ALARM mail ..." >> $MAIL_TEMPLOG
            if [ "$LOGLEVEL" -ge 1 ]; then
              date >> $MAIL_PERMLOG
              echo "[TEST] Sending ALARM mail ..." >> $MAIL_PERMLOG
            fi
            cat $MAIL_DIR/mail_alarm.txt > /tmp/mail_send.txt
            echo >> /tmp/mail_send.txt
            echo "Uptime: $uptime" >> /tmp/mail_send.txt
            echo "System time: $currentdate" >> /tmp/mail_send.txt
            if [ -e /tmp/ntp_error ]; then
              echo "NTP time sync: ERROR" >> /tmp/mail_send.txt
            else
              echo "NTP time sync: OK" >> /tmp/mail_send.txt
            fi
            clear
            if [ "$LOGLEVEL" -ge 2 ]; then
              (sendmail -t < /tmp/mail_send.txt -v 2>&1 | tee -a $MAIL_TEMPLOG $MAIL_PERMLOG)              
              echo >> $MAIL_TEMPLOG
              echo >> $MAIL_PERMLOG
            else              
              (sendmail -t < /tmp/mail_send.txt -v 2>&1 | tee -a $MAIL_TEMPLOG)
              echo >> $MAIL_TEMPLOG
            fi
            touch /tmp/testmail_sent
            maxwait=30
            for (( i = 1; i <= $maxwait; i++ ))
            do
                echo -n "."
                read -t 1
                retval=$?
                if [ ! "$retval" -gt "128" ]; then
                  break
                fi
            done
            joy2key_stop
            clear
          fi
      ;;

      online_update )
        joy2key_start "updowntabenter"
        pikeyd165_start "updowntabenter" "0.8"
        selection=$(dialog --timeout 15 --title "pinHP Arcade Classics" --default-item "1" --menu "\nAll updates will ask\nfor confirmation!\n\nCheck for updates:\n" 14 28 2 1 "System update" 2 "Game settings" 3 "Default resolutions" 3>&1 1>&2 2>&3)
        joy2key_stop
        clear
        if [ ! -z $selection ]; then
          case $selection in
            1 )
              online_system_update
            ;;
            2 )
              online_modeline_update
            ;;
            3)
              online_timings_replace
            ;;
          esac
        fi      
      ;;

### Online Tools menu END ###

### Exit into Shell menu BEGIN ###
      
      exit_arcade )
        echo "... Exit"
        pikeyd165_stop
        loadkeys "$current_keyboard_layout"
        sync
        sleep 1
        setterm -cursor on
        clear
        exit
      ;;

### Exit into Shell menu END ###

### Other selection BEGIN ###

      back )
        rm /tmp/ll_rememberlastselection_tmp_file.txt
        if ! [ "$SYSTEMMENU" = "1" ] && [ "$quickedit_menu_markers" != "Y" ]; then
          checksum_compare
          if [ "$GENERATFLAG" = "1" ]; then
            generate_game_menu
          fi
        fi            
      ;;
        
      back_nogames )
        rm /tmp/ll_rememberlastselection_tmp_file.txt            
      ;;

### Other selection END ###

    esac

### Handle selected Lemonlauncher item END ###
  
### No valid Lemonlauncher response - issue error message and shut down ###

	else
    echo "... Something went wrong :-("
    echo "... Log saved to"
    echo "... $RPI2JAMMA/error.log"
    echo
    echo "... Press any key to cancel" 
    echo 	
  	echo "... System shutdown"
    echo -n "    in 20 seconds "
    for (( i = 0; i <= 9; i++ ))
    do
      echo ""  >> $RPI2JAMMA/error.log
    done
    echo "### BEGIN" >> $RPI2JAMMA/error.log
    echo "... Something went wrong :-(" >> $RPI2JAMMA/error.log
    date >> $RPI2JAMMA/error.log
    echo "#" >> $RPI2JAMMA/error.log
    echo ""  >> $RPI2JAMMA/error.log
    declare -p >> $RPI2JAMMA/error.log
    echo ""  >> $RPI2JAMMA/error.log
    cat $CFGGAMES >> $RPI2JAMMA/error.log
    echo ""  >> $RPI2JAMMA/error.log
    echo "#" >> $RPI2JAMMA/error.log
    date >> $RPI2JAMMA/error.log
    echo "### END" >> $RPI2JAMMA/error.log
    setterm -cursor on
    cleanup_all
    pikeyd165_start "anykey" "0.5"
    joy2key_start "anykey"
    for (( i = 0; i <= 19; i++ ))
    do
      echo -n "."
      read -n 1 -t 1
      retval=$?
      if [ "$retval" -eq 0 ]; then
        pikeyd165_stop
        joy2key_stop
        echo
        echo
        sync
        exit 0
      fi
    done
    [ $MOUNTED_USB ] && umount $MOUNTED_USB >& /dev/null
    umount /dev/mmcblk0p3
    echo -n " exit"
    sync
    sleep 1
    systemctl poweroff
  	exit
  fi

### Lemonlauncher response END ###

# Back to loop, waiting for Lemonlauncher result
done

### Endless loop END ###

exit
